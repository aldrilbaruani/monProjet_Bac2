# utils/database.py - À créer si manquant

import mysql.connector
import sys
import os

# Ajouter le chemin parent pour trouver config.py
current_dir = os.path.dirname(os.path.abspath(__file__))
parent_dir = os.path.dirname(current_dir)
if parent_dir not in sys.path:
    sys.path.insert(0, parent_dir)

try:
    from config import Config
except ImportError:
    # Fallback si config.py n'est pas trouvé
    class Config:
        DB_HOST = 'localhost'
        DB_USER = 'root'
        DB_PASSWORD = ''
        DB_NAME = 'surveillance_ia_projet'


def get_connection():
    """
    Établit une connexion à la base de données MySQL.

    Returns:
        Objet connection MySQL ou None en cas d'erreur
    """
    try:
        connection = mysql.connector.connect(
            host=Config.DB_HOST,
            user=Config.DB_USER,
            password=Config.DB_PASSWORD,
            database=Config.DB_NAME
        )
        print(" Connexion à la base de données établie")
        return connection
    except mysql.connector.Error as err:
        print(f" Échec de connexion à la base de données: {err}")
        return None


def test_connection():
    """Teste la connexion à la base de données."""
    conn = get_connection()
    if conn:
        print(" Test de connexion réussi")
        conn.close()
        return True
    else:
        print(" Test de connexion échoué")
        return False


if __name__ == '__main__':
    test_connection()