# app/utils/security.py
import jwt
import bcrypt
import os
from datetime import datetime, timedelta
from functools import wraps
from flask import request, jsonify
from typing import Optional, Dict

# Configuration JWT
SECRET_KEY = os.environ.get('SECRET_KEY', 'votre-cle-secrete-tres-securisee-changez-en-production')
ALGORITHM = 'HS256'
EXPIRATION_HOURS = 24


def generate_token(employe_id: int, email: str, role: str) -> str:
    """Génère un token JWT pour un employé."""
    payload = {
        'id_employe': employe_id,
        'email': email,
        'role': role,
        'exp': datetime.utcnow() + timedelta(hours=EXPIRATION_HOURS),
        'iat': datetime.utcnow()
    }
    return jwt.encode(payload, SECRET_KEY, algorithm=ALGORITHM)


def decode_token(token: str) -> Optional[Dict]:
    """Décode et vérifie un token JWT."""
    try:
        payload = jwt.decode(token, SECRET_KEY, algorithms=[ALGORITHM])
        return payload
    except jwt.ExpiredSignatureError:
        print("Token expiré")
        return None
    except jwt.InvalidTokenError as e:
        print(f"Token invalide: {e}")
        return None


def get_token_from_header() -> Optional[str]:
    """Extrait le token du header Authorization."""
    auth_header = request.headers.get('Authorization')
    if not auth_header:
        return None

    parts = auth_header.split()
    if len(parts) != 2 or parts[0].lower() != 'bearer':
        return None

    return parts[1]


def get_current_user_id() -> int:
    """Récupère l'ID de l'utilisateur connecté depuis le token."""
    token = get_token_from_header()
    if not token:
        raise PermissionError("Token manquant")

    payload = decode_token(token)
    if not payload:
        raise PermissionError("Token invalide")

    return payload['id_employe']


def get_current_user_role() -> str:
    """Récupère le rôle de l'utilisateur connecté depuis le token."""
    token = get_token_from_header()
    if not token:
        raise PermissionError("Token manquant")

    payload = decode_token(token)
    if not payload:
        raise PermissionError("Token invalide")

    return payload['role']


def hash_password(password: str) -> str:
    """Hache un mot de passe avec bcrypt."""
    salt = bcrypt.gensalt()
    return bcrypt.hashpw(password.encode('utf-8'), salt).decode('utf-8')


def verify_password(password: str, hashed: str) -> bool:
    """Vérifie un mot de passe par rapport à son hash."""
    return bcrypt.checkpw(password.encode('utf-8'), hashed.encode('utf-8'))


def token_required(f):
    """Décorateur pour protéger les routes nécessitant un token."""

    @wraps(f)
    def decorated_function(*args, **kwargs):
        token = get_token_from_header()
        if not token:
            return jsonify({'success': False, 'message': 'Token manquant'}), 401

        payload = decode_token(token)
        if not payload:
            return jsonify({'success': False, 'message': 'Token invalide'}), 401

        return f(*args, **kwargs)

    return decorated_function


def admin_required(f):
    """Décorateur pour protéger les routes nécessitant un rôle admin."""

    @wraps(f)
    def decorated_function(*args, **kwargs):
        token = get_token_from_header()
        if not token:
            return jsonify({'success': False, 'message': 'Token manquant'}), 401

        payload = decode_token(token)
        if not payload:
            return jsonify({'success': False, 'message': 'Token invalide'}), 401

        role = payload.get('role')
        if role not in ['super_admin', 'admin']:
            return jsonify({'success': False, 'message': 'Accès non autorisé'}), 403

        return f(*args, **kwargs)

    return decorated_function


def super_admin_required(f):
    """Décorateur pour protéger les routes nécessitant le rôle super admin."""

    @wraps(f)
    def decorated_function(*args, **kwargs):
        token = get_token_from_header()
        if not token:
            return jsonify({'success': False, 'message': 'Token manquant'}), 401

        payload = decode_token(token)
        if not payload:
            return jsonify({'success': False, 'message': 'Token invalide'}), 401

        role = payload.get('role')
        if role != 'super_admin':
            return jsonify({'success': False, 'message': 'Accès non autorisé'}), 403

        return f(*args, **kwargs)

    return decorated_function