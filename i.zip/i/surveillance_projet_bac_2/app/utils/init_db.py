# init_db.py

import mysql.connector
from config import Config
import os


def init_database():
    """Initialise la base de données et crée les tables."""
    print("🔧 Initialisation de la base de données...")

    # Connexion sans base de données spécifique
    try:
        conn = mysql.connector.connect(
            host=Config.DB_HOST,
            user=Config.DB_USER,
            password=Config.DB_PASSWORD
        )
        cursor = conn.cursor()

        # Créer la base de données si elle n'existe pas
        cursor.execute(f"CREATE DATABASE IF NOT EXISTS {Config.DB_NAME}")
        print(f"✅ Base de données '{Config.DB_NAME}' créée/vérifiée")

        cursor.close()
        conn.close()

        # Maintenant se connecter à la base
        conn = mysql.connector.connect(
            host=Config.DB_HOST,
            user=Config.DB_USER,
            password=Config.DB_PASSWORD,
            database=Config.DB_NAME
        )
        cursor = conn.cursor()

        # Lire et exécuter le script SQL
        sql_file = os.path.join(os.path.dirname(__file__), 'schema.sql')

        if os.path.exists(sql_file):
            with open(sql_file, 'r', encoding='utf-8') as f:
                sql_script = f.read()

            # Exécuter les commandes SQL
            for statement in sql_script.split(';'):
                if statement.strip():
                    cursor.execute(statement)

            conn.commit()
            print(f"✅ Tables créées à partir de {sql_file}")
        else:
            print(f"⚠️ Fichier {sql_file} non trouvé - création manuelle nécessaire")

        cursor.close()
        conn.close()

        print("✅ Initialisation terminée avec succès!")

    except mysql.connector.Error as err:
        print(f"❌ Erreur MySQL: {err}")
    except Exception as e:
        print(f"❌ Erreur: {e}")


if __name__ == '__main__':
    init_database()