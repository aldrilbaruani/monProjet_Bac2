import logging
import os
from datetime import datetime

# Configuration du logging
LOG_LEVEL = os.environ.get('LOG_LEVEL', 'INFO')
LOG_FORMAT = '%(asctime)s - %(name)s - %(levelname)s - %(message)s'
LOG_FILE = f"logs/app_{datetime.now().strftime('%Y%m%d')}.log"

# Créer le dossier logs s'il n'existe pas
os.makedirs('logs', exist_ok=True)


def setup_logger(name):
    """Configure et retourne un logger."""
    logger = logging.getLogger(name)
    logger.setLevel(getattr(logging, LOG_LEVEL))

    # Handler pour fichier
    file_handler = logging.FileHandler(LOG_FILE)
    file_handler.setFormatter(logging.Formatter(LOG_FORMAT))
    logger.addHandler(file_handler)

    # Handler pour console
    console_handler = logging.StreamHandler()
    console_handler.setFormatter(logging.Formatter(LOG_FORMAT))
    logger.addHandler(console_handler)

    return logger


# Logger par défaut
logger = setup_logger('surveillance_ia')