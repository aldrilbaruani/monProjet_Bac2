# create_test_users.py
import sys
import os

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))

from app.services.auth_service import AuthService
from datetime import datetime


def create_test_users():
    """Crée les utilisateurs de test dans la base."""
    auth_service = AuthService()

    test_users = [
        {
            "nom": "Admin",
            "prenom": "Super",
            "poste": "Super Administrateur",
            "email": "superadmin@securite.com",
            "telephone": "0123456789",
            "date_embauche": datetime.now().strftime("%Y-%m-%d"),
            "role": "super_admin"
        },
        {
            "nom": "Admin",
            "prenom": "Simple",
            "poste": "Administrateur",
            "email": "admin@securite.com",
            "telephone": "0123456788",
            "date_embauche": datetime.now().strftime("%Y-%m-%d"),
            "role": "admin"
        },
        {
            "nom": "Dupont",
            "prenom": "Jean",
            "poste": "Agent de sécurité",
            "email": "jean.dupont@securite.com",
            "telephone": "0123456787",
            "date_embauche": datetime.now().strftime("%Y-%m-%d"),
            "role": "employe"
        }
    ]

    for user in test_users:
        try:
            existing = auth_service.employe_dao.get_by_email(user['email'])
            if existing:
                print(f"⚠️ {user['email']} existe déjà (ID: {existing.id_employe})")
                continue

            password = "admin123" if user['role'] != 'employe' else "employe123"
            employe = auth_service.register(user, password)
            print(f"✅ Utilisateur créé: {user['email']} (ID: {employe.id_employe}) - Mot de passe: {password}")

        except Exception as e:
            print(f"❌ Erreur pour {user['email']}: {e}")


if __name__ == "__main__":
    print("=" * 60)
    print("👥 CRÉATION DES UTILISATEURS DE TEST")
    print("=" * 60)
    create_test_users()
    print("\n✅ Terminé !")