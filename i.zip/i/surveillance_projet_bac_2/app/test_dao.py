# test_dao.py

import sys
import os
import random
from datetime import datetime, date, timedelta

# Ajouter le chemin du projet
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))

from app.dao.employe_dao import EmployeDAO
from app.dao.zone_dao import ZoneDAO
from app.dao.camera_dao import CameraDAO
from app.dao.deplacement_dao import DeplacementDAO
from app.dao.alerte_dao import AlerteDAO
from app.dao.evenement_dao import EvenementDAO
from app.dao.notification_dao import NotificationDAO
from app.dao.session_presence_dao import SessionPresenceDAO
from app.dao.chatbot_interaction_dao import ChatbotInteractionDAO
from app.dao.uniforme_dao import UniformeDAO
from app.dao.visage_dao import VisageDAO
from app.dao.reconnaissance_dao import ReconnaissanceDAO

from app.models.Employe import Employe
from app.models.Zone import Zone
from app.models.Camera import Camera
from app.models.DeplacementSigne import DeplacementSigne
from app.models.Alerte import Alerte
from app.models.Evenement import Evenement
from app.models.Notification import Notification
from app.models.SessionPresence import SessionPresence
from app.models.ChatbotInteraction import ChatbotInteraction
from app.models.Uniforme import Uniforme
from app.models.Visage import Visage
from app.models.Reconnaissance import Reconnaissance


def test_employe_dao():
    print("\n📌 TEST EmployeDAO")
    dao = EmployeDAO()

    # 1. Compter les employés existants
    tous = dao.get_all()
    print(f"   📊 Employés existants: {len(tous)}")

    # 2. Créer un employé de test
    email = f"test_{random.randint(1, 10000)}@test.com"
    employe = Employe(
        nom="Test",
        prenom="DAO",
        poste="Testeur",
        email=email,
        date_embauche=datetime.now(),
        telephone="0123456789",
        actif=True,
        role="employe"
    )
    employe.set_mot_de_passe("Test123!")
    print(f"🟢 Mot de passe défini: {employe.mot_de_passe is not None}")

    id_emp = dao.create(employe)
    print(f"   ✅ Employé créé avec ID: {id_emp}")

    if id_emp == 0:
        print("   ❌ Échec de création (ID=0)")
        return

    # 3. Récupérer par ID
    emp = dao.get_by_id(id_emp)
    assert emp is not None
    assert emp.email == email
    print(f"   ✅ Employé récupéré: {emp.nom} {emp.prenom}")

    # 4. Récupérer par email
    emp2 = dao.get_by_email(email)
    assert emp2 is not None
    print("   ✅ Récupération par email OK")

    # 5. Mettre à jour
    emp.nom = "TestUpdated"
    dao.update(emp)
    emp_updated = dao.get_by_id(id_emp)
    assert emp_updated.nom == "TestUpdated"
    print("   ✅ Mise à jour OK")

    # 6. Supprimer
    dao.delete(id_emp)
    emp_deleted = dao.get_by_id(id_emp)
    assert emp_deleted is None
    print("   ✅ Suppression OK")


def test_zone_dao():
    print("\n📌 TEST ZoneDAO")
    dao = ZoneDAO()

    zone = Zone(
        nom_zone="Zone Test DAO",
        type_zone="publique",
        description="Zone créée par test",
        niveau_acces=1
    )
    id_zone = dao.create(zone)
    print(f"   ✅ Zone créée avec ID: {id_zone}")

    if id_zone == 0:
        print("   ❌ Échec de création de zone (ID=0)")
        return

    zone_recup = dao.get_by_id(id_zone)
    assert zone_recup is not None
    assert zone_recup.nom_zone == "Zone Test DAO"
    print("   ✅ Zone récupérée")

    dao.delete(id_zone)
    print("   ✅ Zone supprimée")


def test_camera_dao():
    print("\n📌 TEST CameraDAO")
    zone_dao = ZoneDAO()

    # Créer une zone de base
    zone = Zone(nom_zone="Zone Cam Test", type_zone="publique")
    id_zone = zone_dao.create(zone)
    print(f"   📍 Zone créée: {id_zone}")

    if id_zone == 0:
        print("   ❌ Échec de création de zone")
        return

    dao = CameraDAO()
    camera = Camera(
        nom_camera="Cam Test",
        emplacement="Salle",
        flux_url="rtsp://test",
        id_zone=id_zone
    )
    id_cam = dao.create(camera)
    print(f"   ✅ Caméra créée avec ID: {id_cam}")

    if id_cam == 0:
        print("   ❌ Échec de création de caméra")
        zone_dao.delete(id_zone)
        return

    cam_recup = dao.get_by_id(id_cam)
    assert cam_recup is not None
    assert cam_recup.nom_camera == "Cam Test"
    print("   ✅ Caméra récupérée")

    # Nettoyage
    dao.delete(id_cam)
    zone_dao.delete(id_zone)
    print("   ✅ Caméra et zone supprimées")


def test_deplacement_dao():
    print("\n📌 TEST DeplacementDAO")
    employe_dao = EmployeDAO()
    zone_dao = ZoneDAO()

    # Créer les dépendances
    email = f"deplacement_{random.randint(1, 10000)}@test.com"
    emp = Employe(
        nom="TestDeplacement",
        prenom="DAO",
        poste="Testeur",
        email=email,
        date_embauche=datetime.now()
    )
    emp.set_mot_de_passe("Test123!")
    id_emp = employe_dao.create(emp)
    print(f"   📍 Employé créé: {id_emp}")

    zone = Zone(nom_zone="Zone Destination", type_zone="publique")
    id_zone = zone_dao.create(zone)
    print(f"   📍 Zone créée: {id_zone}")

    if id_emp == 0 or id_zone == 0:
        print("   ❌ Échec création dépendances")
        return

    dao = DeplacementDAO()
    deplacement = DeplacementSigne(
        date_depart=datetime.now(),
        motif="Test déplacement",
        id_employe=id_emp,
        id_zone_destination=id_zone,
        date_retour_prevue=datetime.now() + timedelta(hours=1)
    )
    id_dep = dao.create(deplacement)
    print(f"   ✅ Déplacement créé avec ID: {id_dep}")

    if id_dep == 0:
        print("   ❌ Échec création déplacement")
        return

    dep_recup = dao.get_by_id(id_dep)
    assert dep_recup is not None
    assert dep_recup.motif == "Test déplacement"
    print("   ✅ Déplacement récupéré")

    # Nettoyage
    dao.delete(id_dep)
    employe_dao.delete(id_emp)
    zone_dao.delete(id_zone)
    print("   ✅ Nettoyage OK")


def test_alerte_dao():
    print("\n📌 TEST AlerteDAO")
    dao = AlerteDAO()

    alerte = Alerte(
        type_alerte="intrusion",
        message="Alerte de test",
        niveau_urgence=3
    )
    id_alerte = dao.create(alerte)
    print(f"   ✅ Alerte créée avec ID: {id_alerte}")

    if id_alerte == 0:
        print("   ❌ Échec création alerte")
        return

    alerte_recup = dao.get_by_id(id_alerte)
    assert alerte_recup is not None
    assert alerte_recup.message == "Alerte de test"
    print("   ✅ Alerte récupérée")

    # Tester les alertes non traitées
    non_traitees = dao.get_non_traitees()
    print(f"   📊 Alertes non traitées: {len(non_traitees)}")

    dao.delete(id_alerte)
    print("   ✅ Alerte supprimée")


def test_evenement_dao():
    print("\n📌 TEST EvenementDAO")
    zone_dao = ZoneDAO()
    camera_dao = CameraDAO()

    # Créer zone et caméra
    zone = Zone(nom_zone="Zone Evenement", type_zone="publique")
    id_zone = zone_dao.create(zone)
    print(f"   📍 Zone créée: {id_zone}")

    if id_zone == 0:
        print("   ❌ Échec création zone")
        return

    camera = Camera(
        nom_camera="Cam Evenement",
        emplacement="Test",
        flux_url="rtsp://test",
        id_zone=id_zone
    )
    id_cam = camera_dao.create(camera)
    print(f"   📍 Caméra créée: {id_cam}")

    if id_cam == 0:
        print("   ❌ Échec création caméra")
        zone_dao.delete(id_zone)
        return

    dao = EvenementDAO()
    evenement = Evenement(
        date_heure=datetime.now(),
        type_evenement="detection",
        confiance=0.95,
        metadata={"test": True},
        id_camera=id_cam
    )
    id_evt = dao.create(evenement)
    print(f"   ✅ Événement créé avec ID: {id_evt}")

    if id_evt == 0:
        print("   ❌ Échec création événement")
        camera_dao.delete(id_cam)
        zone_dao.delete(id_zone)
        return

    evt_recup = dao.get_by_id(id_evt)
    print(f"   📍 Événement récupéré: {evt_recup}")

    if evt_recup is None:
        print("   ❌ Échec récupération événement")
        dao.delete(id_evt)
        camera_dao.delete(id_cam)
        zone_dao.delete(id_zone)
        return

    assert evt_recup.confiance == 0.95
    print("   ✅ Événement récupéré")

    # Nettoyage
    dao.delete(id_evt)
    camera_dao.delete(id_cam)
    zone_dao.delete(id_zone)
    print("   ✅ Nettoyage OK")


def test_notification_dao():
    print("\n📌 TEST NotificationDAO")
    alerte_dao = AlerteDAO()

    # Créer alerte de base avec type VALIDE
    alerte = Alerte(
        type_alerte="intrusion",
        message="Alerte pour notification",
        niveau_urgence=1
    )
    id_alerte = alerte_dao.create(alerte)
    print(f"   📍 Alerte créée: {id_alerte}")

    if id_alerte == 0:
        print("   ❌ Échec création alerte")
        return

    dao = NotificationDAO()
    notification = Notification(
        canal="EMAIL",
        destinataire="test@test.com",
        contenu="Notification de test",
        id_alerte=id_alerte
    )
    id_notif = dao.create(notification)
    print(f"   ✅ Notification créée avec ID: {id_notif}")

    if id_notif == 0:
        print("   ❌ Échec création notification")
        return

    notif_recup = dao.get_by_id(id_notif)
    assert notif_recup is not None
    assert notif_recup.destinataire == "test@test.com"
    print("   ✅ Notification récupérée")

    # Nettoyage
    dao.delete(id_notif)
    alerte_dao.delete(id_alerte)
    print("   ✅ Nettoyage OK")


def test_session_presence_dao():
    print("\n📌 TEST SessionPresenceDAO")
    employe_dao = EmployeDAO()

    # Créer un employé
    email = f"session_{random.randint(1, 10000)}@test.com"
    emp = Employe(
        nom="Session",
        prenom="Test",
        poste="Testeur",
        email=email,
        date_embauche=datetime.now()
    )
    emp.set_mot_de_passe("Test123!")
    id_emp = employe_dao.create(emp)
    print(f"   📍 Employé créé: {id_emp}")

    if id_emp == 0:
        print("   ❌ Échec création employé")
        return

    dao = SessionPresenceDAO()
    session = SessionPresence(
        debut=datetime.now(),
        id_employe=id_emp,
        type_session="bureau"
    )
    id_session = dao.create(session)
    print(f"   ✅ Session créée avec ID: {id_session}")

    if id_session == 0:
        print("   ❌ Échec création session")
        return

    session_recup = dao.get_by_id(id_session)
    assert session_recup is not None
    assert session_recup.est_active == True
    print("   ✅ Session récupérée")

    # Terminer la session
    dao.terminer(id_session)
    session_terminated = dao.get_by_id(id_session)
    assert session_terminated is not None
    assert session_terminated.fin is not None
    print("   ✅ Session terminée")

    # Nettoyage
    dao.delete(id_session)
    employe_dao.delete(id_emp)
    print("   ✅ Nettoyage OK")


def test_chatbot_interaction_dao():
    print("\n📌 TEST ChatbotInteractionDAO")
    employe_dao = EmployeDAO()

    # Créer un employé
    email = f"chatbot_{random.randint(1, 10000)}@test.com"
    emp = Employe(
        nom="Chatbot",
        prenom="Test",
        poste="Testeur",
        email=email,
        date_embauche=datetime.now()
    )
    emp.set_mot_de_passe("Test123!")
    id_emp = employe_dao.create(emp)
    print(f"   📍 Employé créé: {id_emp}")

    if id_emp == 0:
        print("   ❌ Échec création employé")
        return

    dao = ChatbotInteractionDAO()
    interaction = ChatbotInteraction(
        commande="Je vais en zone B",
        reponse="Déplacement enregistré",
        id_employe=id_emp
    )
    id_interaction = dao.create(interaction)
    print(f"   ✅ Interaction créée avec ID: {id_interaction}")

    if id_interaction == 0:
        print("   ❌ Échec création interaction")
        return

    interaction_recup = dao.get_by_id(id_interaction)
    assert interaction_recup is not None
    assert interaction_recup.commande == "Je vais en zone B"
    print("   ✅ Interaction récupérée")

    # Nettoyage
    dao.delete(id_interaction)
    employe_dao.delete(id_emp)
    print("   ✅ Nettoyage OK")


def test_uniforme_dao():
    print("\n📌 TEST UniformeDAO")
    employe_dao = EmployeDAO()

    # Créer un employé
    email = f"uniforme_{random.randint(1, 10000)}@test.com"
    emp = Employe(
        nom="Uniforme",
        prenom="Test",
        poste="Testeur",
        email=email,
        date_embauche=datetime.now()
    )
    emp.set_mot_de_passe("Test123!")
    id_emp = employe_dao.create(emp)
    print(f"   📍 Employé créé: {id_emp}")

    if id_emp == 0:
        print("   ❌ Échec création employé")
        return

    dao = UniformeDAO()
    uniforme = Uniforme(
        couleur_dominante="bleu",
        type_tenue="chemise",
        date_debut=date.today(),
        id_employe=id_emp
    )
    id_uniforme = dao.create(uniforme)
    print(f"   ✅ Uniforme créé avec ID: {id_uniforme}")

    if id_uniforme == 0:
        print("   ❌ Échec création uniforme")
        employe_dao.delete(id_emp)
        return

    uniforme_recup = dao.get_by_id(id_uniforme)
    assert uniforme_recup is not None
    assert uniforme_recup.couleur_dominante == "bleu"
    print("   ✅ Uniforme récupéré")

    # Tester la terminaison
    dao.terminer(id_uniforme)
    uniforme_termine = dao.get_by_id(id_uniforme)
    assert uniforme_termine is not None
    assert uniforme_termine.date_fin is not None
    print("   ✅ Uniforme terminé")

    # Nettoyage
    dao.delete(id_uniforme)
    employe_dao.delete(id_emp)
    print("   ✅ Nettoyage OK")


def test_visage_dao():
    print("\n📌 TEST VisageDAO")
    employe_dao = EmployeDAO()

    # Créer un employé
    email = f"visage_{random.randint(1, 10000)}@test.com"
    emp = Employe(
        nom="Visage",
        prenom="Test",
        poste="Testeur",
        email=email,
        date_embauche=datetime.now()
    )
    emp.set_mot_de_passe("Test123!")
    id_emp = employe_dao.create(emp)
    print(f"   📍 Employé créé: {id_emp}")

    if id_emp == 0:
        print("   ❌ Échec création employé")
        return

    dao = VisageDAO()
    visage = Visage(
        encodage={"vector": [0.1, 0.2, 0.3]},
        id_employe=id_emp,
        angle="face",
        qualite=0.85
    )
    id_visage = dao.create(visage)
    print(f"   ✅ Visage créé avec ID: {id_visage}")

    if id_visage == 0:
        print("   ❌ Échec création visage")
        return

    visage_recup = dao.get_by_id(id_visage)
    assert visage_recup is not None
    assert visage_recup.angle == "face"
    print("   ✅ Visage récupéré")

    # Nettoyage
    dao.delete(id_visage)
    employe_dao.delete(id_emp)
    print("   ✅ Nettoyage OK")


def test_reconnaissance_dao():
    print("\n📌 TEST ReconnaissanceDAO")
    employe_dao = EmployeDAO()
    zone_dao = ZoneDAO()
    camera_dao = CameraDAO()
    evenement_dao = EvenementDAO()

    # Créer un employé
    email = f"reco_{random.randint(1, 10000)}@test.com"
    emp = Employe(
        nom="Reconnaissance",
        prenom="Test",
        poste="Testeur",
        email=email,
        date_embauche=datetime.now()
    )
    emp.set_mot_de_passe("Test123!")
    id_emp = employe_dao.create(emp)
    print(f"   📍 Employé créé: {id_emp}")

    if id_emp == 0:
        print("   ❌ Échec création employé")
        return

    # Créer un événement
    zone = Zone(nom_zone="Zone Reco", type_zone="publique")
    id_zone = zone_dao.create(zone)
    print(f"   📍 Zone créée: {id_zone}")

    camera = Camera(
        nom_camera="Cam Reco",
        emplacement="Test",
        flux_url="rtsp://test",
        id_zone=id_zone
    )
    id_cam = camera_dao.create(camera)
    print(f"   📍 Caméra créée: {id_cam}")

    evenement = Evenement(
        date_heure=datetime.now(),
        type_evenement="detection",
        confiance=0.95,
        metadata={"test": True},
        id_camera=id_cam
    )
    id_evt = evenement_dao.create(evenement)
    print(f"   📍 Événement créé: {id_evt}")

    if id_zone == 0 or id_cam == 0 or id_evt == 0:
        print("   ❌ Échec création dépendances")
        return

    dao = ReconnaissanceDAO()
    reconnaissance = Reconnaissance(
        methode="faciale",
        score_confiance=0.85,
        id_evenement=id_evt,
        id_employe=id_emp
    )
    id_reco = dao.create(reconnaissance)
    print(f"   ✅ Reconnaissance créée avec ID: {id_reco}")

    if id_reco == 0:
        print("   ❌ Échec création reconnaissance")
        return

    reco_recup = dao.get_by_id(id_reco)
    assert reco_recup is not None
    assert reco_recup.methode == "faciale"
    print("   ✅ Reconnaissance récupérée")

    # Nettoyage
    dao.delete(id_reco)
    evenement_dao.delete(id_evt)
    camera_dao.delete(id_cam)
    zone_dao.delete(id_zone)
    employe_dao.delete(id_emp)
    print("   ✅ Nettoyage OK")


if __name__ == "__main__":
    print("=" * 60)
    print("🧪 TEST DES DAO (avec base de données réelle)")
    print("=" * 60)

    test_employe_dao()
    test_zone_dao()
    test_camera_dao()
    test_deplacement_dao()
    test_alerte_dao()
    test_evenement_dao()
    test_notification_dao()
    test_session_presence_dao()
    test_chatbot_interaction_dao()
    test_uniforme_dao()
    test_visage_dao()
    test_reconnaissance_dao()

    print("\n" + "=" * 60)
    print("✅ Tests des DAO terminés")