# app/services/employe_service.py

from dao.employe_dao import EmployeDAO
from dao.deplacement_dao import DeplacementDAO
from dao.session_presence_dao import SessionPresenceDAO
from models.Employe import Employe
from typing import List, Optional, Dict
import re
import random
import string


class EmployeService:
    """
    Service gérant la logique métier des employés.
    """

    def __init__(self):
        self.employe_dao = EmployeDAO()
        self.deplacement_dao = DeplacementDAO()
        self.session_dao = SessionPresenceDAO()

    # --- Méthodes de validation ---

    def _valider_email(self, email: str) -> bool:
        """
        Valide le format d'un email.
        """
        pattern = r'^[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,}$'
        return re.match(pattern, email) is not None

    def _valider_telephone(self, telephone: str) -> bool:
        """
        Valide le format d'un téléphone (simplifié).
        """
        if not telephone:
            return True
        pattern = r'^(\+?\d{1,3})?[\s-]?\d{1,4}[\s-]?\d{1,4}[\s-]?\d{1,4}$'
        return re.match(pattern, telephone.replace(' ', '')) is not None

    def _generer_mot_de_passe_defaut(self) -> str:
        """
        Génère un mot de passe par défaut.
        """
        chars = string.ascii_letters + string.digits
        return ''.join(random.choice(chars) for _ in range(10))

    # --- Méthodes métier ---

    def get_all_employes(self, actifs_only: bool = True) -> List[Employe]:
        """
        Récupère tous les employés.
        """
        if actifs_only:
            return self.employe_dao.get_actifs()
        return self.employe_dao.get_all()

    def get_employe_by_id(self, id_employe: int) -> Employe:
        """
        Récupère un employé par son ID.
        """
        employe = self.employe_dao.get_by_id(id_employe)
        if not employe:
            raise ValueError(f"Employé avec ID {id_employe} introuvable")
        return employe

    def get_employe_by_email(self, email: str) -> Optional[Employe]:
        """
        Récupère un employé par son email.
        """
        return self.employe_dao.get_by_email(email)

    def get_employes_by_role(self, role: str) -> List[Employe]:
        """
        Récupère les employés par rôle.
        """
        return self.employe_dao.get_by_role(role)

    def create_employe(self, employe_data: Dict) -> Employe:
        """
        Crée un nouvel employé.
        """
        # Validations
        if not employe_data.get('nom'):
            raise ValueError("Le nom est obligatoire")
        if not employe_data.get('prenom'):
            raise ValueError("Le prénom est obligatoire")
        if not employe_data.get('email'):
            raise ValueError("L'email est obligatoire")

        if not self._valider_email(employe_data['email']):
            raise ValueError("Format d'email invalide")

        existing = self.employe_dao.get_by_email(employe_data['email'])
        if existing:
            raise ValueError(f"Un employé avec l'email {employe_data['email']} existe déjà")

        if employe_data.get('telephone') and not self._valider_telephone(employe_data['telephone']):
            raise ValueError("Format de téléphone invalide")

        # Vérifier si un mot de passe est fourni, sinon en générer un par défaut
        if 'mot_de_passe' not in employe_data or not employe_data['mot_de_passe']:
            employe_data['mot_de_passe'] = self._generer_mot_de_passe_defaut()

        employe = Employe(**employe_data)

        if not employe.date_embauche:
            raise ValueError("La date d'embauche est obligatoire")

        # Définir le mot de passe hashé
        employe.set_mot_de_passe(employe_data['mot_de_passe'])

        id_employe = self.employe_dao.create(employe)
        employe.id_employe = id_employe

        return employe

    def update_employe(self, id_employe: int, employe_data: Dict) -> Employe:
        """
        Met à jour un employé existant.
        """
        existing = self.get_employe_by_id(id_employe)

        for key, value in employe_data.items():
            if hasattr(existing, key) and value is not None:
                setattr(existing, key, value)

        if 'email' in employe_data and employe_data['email'] != existing.email:
            if not self._valider_email(employe_data['email']):
                raise ValueError("Format d'email invalide")

            autre = self.employe_dao.get_by_email(employe_data['email'])
            if autre and autre.id_employe != id_employe:
                raise ValueError(f"L'email {employe_data['email']} est déjà utilisé")

        self.employe_dao.update(existing)
        return existing

    def delete_employe(self, id_employe: int, soft_delete: bool = True) -> Dict:
        """
        Supprime ou désactive un employé.
        """
        employe = self.get_employe_by_id(id_employe)

        if soft_delete:
            employe.actif = False
            self.employe_dao.update(employe)
            message = "Employé désactivé avec succès"
        else:
            deplacements = self.deplacement_dao.get_by_employe(id_employe)
            sessions = self.session_dao.get_by_employe(id_employe)

            if deplacements or sessions:
                raise ValueError("Impossible de supprimer : l'employé a des déplacements ou sessions associés")

            self.employe_dao.delete(id_employe)
            message = "Employé supprimé définitivement"

        return {
            "success": True,
            "message": message,
            "id_employe": id_employe
        }

    def search_employes(self, terme: str) -> List[Employe]:
        """
        Recherche des employés par nom, prénom ou email.
        """
        return self.employe_dao.search(terme)

    def get_statistiques(self) -> Dict:
        """
        Statistiques sur les employés.
        """
        tous = self.employe_dao.get_all()
        actifs = [e for e in tous if e.actif]

        return {
            "total": len(tous),
            "actifs": len(actifs),
            "inactifs": len(tous) - len(actifs),
            "par_role": {
                "super_admin": len([e for e in tous if e.role == 'super_admin']),
                "admin": len([e for e in tous if e.role == 'admin']),
                "employe": len([e for e in tous if e.role == 'employe'])
            }
        }