# app/services/uniforme_service.py

from dao.uniforme_dao import UniformeDAO
from dao.employe_dao import EmployeDAO
from models.Uniforme import Uniforme
from typing import List, Optional, Dict
from datetime import date

class UniformeService:
    """
    Service gérant les uniformes des employés.
    """

    def __init__(self):
        self.uniforme_dao = UniformeDAO()
        self.employe_dao = EmployeDAO()

    def get_uniforme_by_id(self, id_uniforme: int) -> Uniforme:
        """
        Récupère un uniforme par son ID.
        """
        uniforme = self.uniforme_dao.get_by_id(id_uniforme)
        if not uniforme:
            raise ValueError(f"Uniforme avec ID {id_uniforme} introuvable")
        return uniforme

    def get_uniformes_employe(self, id_employe: int) -> List[Uniforme]:
        """
        Récupère tous les uniformes d'un employé.
        """
        # Vérifier que l'employé existe
        employe = self.employe_dao.get_by_id(id_employe)
        if not employe:
            raise ValueError(f"Employé avec ID {id_employe} introuvable")

        return self.uniforme_dao.get_by_employe(id_employe)

    def get_uniforme_actuel(self, id_employe: int) -> Optional[Uniforme]:
        """
        Récupère l'uniforme actuel d'un employé.
        """
        return self.uniforme_dao.get_actif(id_employe)

    def get_uniformes_par_couleur(self, couleur: str) -> List[Uniforme]:
        """
        Récupère les uniformes par couleur.
        """
        return self.uniforme_dao.get_par_couleur(couleur)

    def create_uniforme(self, uniforme_data: Dict) -> Uniforme:
        """
        Crée un nouvel uniforme.
        """
        # Validations
        if not uniforme_data.get('couleur_dominante'):
            raise ValueError("La couleur dominante est obligatoire")

        if not uniforme_data.get('type_tenue'):
            raise ValueError("Le type de tenue est obligatoire")

        if not uniforme_data.get('id_employe'):
            raise ValueError("L'ID employé est obligatoire")

        # Vérifier que l'employé existe
        employe = self.employe_dao.get_by_id(uniforme_data['id_employe'])
        if not employe:
            raise ValueError(f"Employé avec ID {uniforme_data['id_employe']} introuvable")

        # Vérifier les dates
        if uniforme_data.get('date_fin') and uniforme_data.get('date_debut'):
            if uniforme_data['date_fin'] < uniforme_data['date_debut']:
                raise ValueError("La date de fin ne peut pas être antérieure à la date de début")

        # Création
        uniforme = Uniforme(**uniforme_data)

        if not uniforme.date_debut:
            uniforme.date_debut = date.today()

        id_uniforme = self.uniforme_dao.create(uniforme)
        uniforme.id_uniforme = id_uniforme

        return uniforme

    def update_uniforme(self, id_uniforme: int, uniforme_data: Dict) -> Uniforme:
        """
        Met à jour un uniforme.
        """
        uniforme = self.get_uniforme_by_id(id_uniforme)

        for key, value in uniforme_data.items():
            if hasattr(uniforme, key) and value is not None:
                setattr(uniforme, key, value)

        # Revalidation des dates
        if uniforme.date_fin and uniforme.date_debut:
            if uniforme.date_fin < uniforme.date_debut:
                raise ValueError("La date de fin ne peut pas être antérieure à la date de début")

        self.uniforme_dao.update(uniforme)

        return uniforme

    def terminer_uniforme(self, id_uniforme: int, date_fin: date = None) -> Uniforme:
        """
        Termine l'utilisation d'un uniforme.
        """
        uniforme = self.get_uniforme_by_id(id_uniforme)

        if uniforme.date_fin:
            raise ValueError(f"Cet uniforme est déjà terminé depuis le {uniforme.date_fin}")

        if not date_fin:
            date_fin = date.today()

        self.uniforme_dao.terminer(id_uniforme, date_fin)

        return self.get_uniforme_by_id(id_uniforme)

    def get_statistiques(self) -> Dict:
        """
        Statistiques sur les uniformes.
        """
        # À implémenter selon besoin
        return {
            "message": "Statistiques uniformes à implémenter"
        }