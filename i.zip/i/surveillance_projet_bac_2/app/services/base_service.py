from typing import Optional, Any
import logging

class BaseService:

    def __init__(self):
        self.logger = logging.getLogger(self.__class__.__name__)

    def _validate_id(self, id_value: Optional[int], entity_name: str = "Entité") -> None:

        if id_value is None:
            raise ValueError(f"{entity_name} ID manquant")
        if id_value <= 0:
            raise ValueError(f"{entity_name} ID invalide: {id_value}")

    def _handle_error(self, error: Exception, message: str) -> None:

        self.logger.error(f"{message}: {str(error)}")
        raise Exception(f"{message}: {str(error)}")