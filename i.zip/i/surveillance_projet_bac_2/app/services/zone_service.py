# app/services/zone_service.py

from dao.zone_dao import ZoneDAO
from dao.camera_dao import CameraDAO
from dao.deplacement_dao import DeplacementDAO
from models.Zone import Zone
from typing import List, Optional, Dict


class ZoneService:

    def __init__(self):
        self.zone_dao = ZoneDAO()
        self.camera_dao = CameraDAO()
        self.deplacement_dao = DeplacementDAO()

    def get_all_zones(self) -> List[Zone]:
        return self.zone_dao.get_all()

    def get_zone_by_id(self, id_zone: int) -> Zone:
        zone = self.zone_dao.get_by_id(id_zone)
        if not zone:
            raise ValueError(f"Zone avec ID {id_zone} introuvable")
        return zone

    def get_zones_by_type(self, type_zone: str) -> List[Zone]:
        return self.zone_dao.get_by_type(type_zone)

    def create_zone(self, zone_data: Dict) -> Zone:
        if not zone_data.get('nom_zone'):
            raise ValueError("Le nom de la zone est obligatoire")
        if not zone_data.get('type_zone'):
            raise ValueError("Le type de zone est obligatoire")

        zone = Zone(**zone_data)
        id_zone = self.zone_dao.create(zone)
        zone.id_zone = id_zone
        return zone

    def update_zone(self, id_zone: int, zone_data: Dict) -> Zone:
        zone = self.get_zone_by_id(id_zone)
        for key, value in zone_data.items():
            if hasattr(zone, key) and value is not None:
                setattr(zone, key, value)
        self.zone_dao.update(zone)
        return zone

    def delete_zone(self, id_zone: int) -> Dict:
        # Vérifier les dépendances
        cameras = self.camera_dao.get_by_zone(id_zone)
        deplacements = self.deplacement_dao.get_by_zone(id_zone)

        if cameras:
            raise ValueError(f"Impossible de supprimer : {len(cameras)} caméra(s) dans cette zone")

        if deplacements:
            raise ValueError(f"Impossible de supprimer : {len(deplacements)} déplacement(s) vers cette zone")

        self.zone_dao.delete(id_zone)

        return {
            "success": True,
            "message": "Zone supprimée avec succès",
            "id_zone": id_zone
        }

    def get_zones_avec_cameras(self) -> List[Dict]:
        zones = self.zone_dao.get_all()
        result = []
        for zone in zones:
            cameras = self.camera_dao.get_by_zone(zone.id_zone)
            result.append({
                "zone": zone.to_dict(),
                "cameras": [c.to_dict() for c in cameras],
                "nombre_cameras": len(cameras)
            })
        return result

    def verifier_acces(self, id_employe: int, id_zone: int) -> bool:
        # ✅ IMPORT CORRIGÉ
        from services.employe_service import EmployeService

        employe_service = EmployeService()
        employe = employe_service.get_employe_by_id(id_employe)
        zone = self.get_zone_by_id(id_zone)

        if employe.role == 'super_admin':
            return True

        if employe.role == 'admin':
            return zone.type_zone not in ['interdite']

        if employe.role == 'employe':
            return zone.type_zone in ['publique', 'restreinte']

        return False