# app/services/NotificationService.py

from dao.notification_dao import NotificationDAO
from dao.alerte_dao import AlerteDAO
from dao.employe_dao import EmployeDAO
from models.Notification import Notification
from typing import List, Optional, Dict
from datetime import datetime
import smtplib
import logging

class NotificationService:
    """
    Service gérant l'envoi de notifications.
    """

    def __init__(self):
        self.notification_dao = NotificationDAO()
        self.alerte_dao = AlerteDAO()
        self.employe_dao = EmployeDAO()
        self.logger = logging.getLogger(__name__)

    def get_notification_by_id(self, id_notification: int) -> Notification:
        """
        Récupère une notification par son ID.
        """
        notif = self.notification_dao.get_by_id(id_notification)
        if not notif:
            raise ValueError(f"Notification avec ID {id_notification} introuvable")
        return notif

    def get_notifications_par_alerte(self, id_alerte: int) -> List[Notification]:
        """
        Récupère les notifications d'une alerte.
        """
        return self.notification_dao.get_by_alerte(id_alerte)

    def get_notifications_non_lues(self, destinataire: str = None) -> List[Notification]:
        """
        Récupère les notifications non lues.
        """
        return self.notification_dao.get_non_lues(destinataire)

    def create_notification(self, notification_data: Dict) -> Notification:
        """
        Crée une notification.
        """
        # Validations
        if not notification_data.get('canal'):
            raise ValueError("Le canal est obligatoire")

        if not notification_data.get('destinataire'):
            raise ValueError("Le destinataire est obligatoire")

        if not notification_data.get('contenu'):
            raise ValueError("Le contenu est obligatoire")

        if not notification_data.get('id_alerte'):
            raise ValueError("L'ID alerte est obligatoire")

        # Vérifier que l'alerte existe
        alerte = self.alerte_dao.get_by_id(notification_data['id_alerte'])
        if not alerte:
            raise ValueError(f"Alerte avec ID {notification_data['id_alerte']} introuvable")

        # Création
        notification = Notification(**notification_data)

        if not notification.date_envoi:
            notification.date_envoi = datetime.now()

        if notification.tentative is None:
            notification.tentative = 0

        id_notif = self.notification_dao.create(notification)
        notification.id_notification = id_notif

        return notification

    def marquer_comme_lue(self, id_notification: int) -> Notification:
        """
        Marque une notification comme lue.
        """
        notification = self.get_notification_by_id(id_notification)

        self.notification_dao.update_statut(id_notification, 'lu', datetime.now())

        return self.get_notification_by_id(id_notification)

    def envoyer_maintenant(self, id_notification: int) -> bool:
        """
        Envoie une notification immédiatement.
        """
        notification = self.get_notification_by_id(id_notification)

        try:
            if notification.canal == 'EMAIL':
                success = self._envoyer_email(notification)
            elif notification.canal == 'SMS':
                success = self._envoyer_sms(notification)
            elif notification.canal == 'TELEGRAM':
                success = self._envoyer_telegram(notification)
            elif notification.canal == 'PUSH':
                success = self._envoyer_push(notification)
            else:
                raise ValueError(f"Canal non supporté: {notification.canal}")

            if success:
                self.notification_dao.update_statut(id_notification, 'envoye')
                return True
            else:
                self.notification_dao.increment_tentative(id_notification)
                return False

        except Exception as e:
            self.logger.error(f"Erreur envoi notification {id_notification}: {str(e)}")
            self.notification_dao.marquer_erreur(id_notification, str(e))
            return False

    def _envoyer_email(self, notification: Notification) -> bool:
        """
        Envoie un email.
        À configurer avec vos paramètres SMTP.
        """
        try:
            # Configuration SMTP à mettre dans config.py
            # server = smtplib.SMTP('smtp.gmail.com', 587)
            # server.starttls()
            # server.login('votre_email', 'votre_mdp')
            # server.send_message(msg)
            # server.quit()

            self.logger.info(f"Email envoyé à {notification.destinataire}")
            return True
        except Exception as e:
            self.logger.error(f"Erreur envoi email: {e}")
            return False

    def _envoyer_sms(self, notification: Notification) -> bool:
        """
        Envoie un SMS.
        À connecter avec un service comme Twilio.
        """
        # Implémentation SMS
        self.logger.info(f"SMS envoyé à {notification.destinataire}")
        return True

    def _envoyer_telegram(self, notification: Notification) -> bool:
        """
        Envoie un message Telegram.
        """
        # Implémentation Telegram
        self.logger.info(f"Telegram envoyé à {notification.destinataire}")
        return True

    def _envoyer_push(self, notification: Notification) -> bool:
        """
        Envoie une notification push.
        """
        # Implémentation Push
        self.logger.info(f"Push envoyé à {notification.destinataire}")
        return True

    def get_statistiques(self) -> Dict:
        """
        Statistiques sur les notifications.
        """
        toutes = self.notification_dao.get_par_statut('envoye')
        non_lues = self.notification_dao.get_non_lues()
        en_echec = self.notification_dao.get_par_statut('echec')

        return {
            "total_envoyees": len(toutes),
            "non_lues": len(non_lues),
            "en_echec": len(en_echec)
        }