# app/services/session_presence_service.py

from dao.session_presence_dao import SessionPresenceDAO
from dao.employe_dao import EmployeDAO
from models.SessionPresence import SessionPresence
from typing import List, Optional, Dict
from datetime import datetime, date, timedelta

class SessionPresenceService:
    """
    Service gérant les sessions de présence des employés.
    """

    def __init__(self):
        self.session_dao = SessionPresenceDAO()
        self.employe_dao = EmployeDAO()

    def get_session_by_id(self, id_session: int) -> SessionPresence:
        """
        Récupère une session par son ID.
        """
        session = self.session_dao.get_by_id(id_session)
        if not session:
            raise ValueError(f"Session avec ID {id_session} introuvable")
        return session

    def get_sessions_employe(self, id_employe: int) -> List[SessionPresence]:
        """
        Récupère les sessions d'un employé.
        """
        # Vérifier que l'employé existe
        employe = self.employe_dao.get_by_id(id_employe)
        if not employe:
            raise ValueError(f"Employé avec ID {id_employe} introuvable")

        return self.session_dao.get_by_employe(id_employe)

    def get_session_en_cours(self, id_employe: int) -> Optional[SessionPresence]:
        """
        Récupère la session en cours d'un employé.
        """
        sessions = self.session_dao.get_en_cours(id_employe)
        return sessions[0] if sessions else None

    def get_presence_aujourdhui(self, id_employe: int) -> List[SessionPresence]:
        """
        Récupère les sessions de présence du jour pour un employé.
        """
        aujourd_hui = date.today()
        return self.session_dao.get_par_jour(aujourd_hui)

    def demarrer_session(self, id_employe: int, type_session: str = "bureau") -> SessionPresence:
        """
        Démarre une session de présence.
        """
        # Vérifier que l'employé existe
        employe = self.employe_dao.get_by_id(id_employe)
        if not employe:
            raise ValueError(f"Employé avec ID {id_employe} introuvable")

        # Vérifier s'il n'y a pas déjà une session en cours
        en_cours = self.get_session_en_cours(id_employe)
        if en_cours:
            raise ValueError(f"Une session est déjà en cours pour cet employé (démarrée à {en_cours.debut})")

        # Création
        session = SessionPresence(
            debut=datetime.now(),
            id_employe=id_employe,
            type_session=type_session
        )

        id_session = self.session_dao.create(session)
        session.id_session = id_session

        return session

    def terminer_session(self, id_employe: int = None, id_session: int = None) -> SessionPresence:
        """
        Termine une session de présence.
        """
        if id_session:
            session = self.get_session_by_id(id_session)
        elif id_employe:
            session = self.get_session_en_cours(id_employe)
            if not session:
                raise ValueError(f"Aucune session en cours pour l'employé {id_employe}")
        else:
            raise ValueError("Il faut fournir soit id_employe soit id_session")

        if session.fin:
            raise ValueError(f"Cette session est déjà terminée depuis {session.fin}")

        self.session_dao.terminer(session.id_session)

        return self.get_session_by_id(session.id_session)

    def get_statistiques_presence(self, id_employe: int = None, debut: date = None, fin: date = None) -> Dict:
        """
        Statistiques de présence.
        """
        if not debut:
            debut = date.today() - timedelta(days=30)
        if not fin:
            fin = date.today()

        if id_employe:
            sessions = self.session_dao.get_by_employe(id_employe)
            sessions = [s for s in sessions if s.debut.date() >= debut and s.debut.date() <= fin]
        else:
            # Récupérer toutes les sessions sur la période
            sessions = []
            # À implémenter si besoin

        total_heures = sum(s.duree for s in sessions if s.duree)
        jours_presents = len(set(s.debut.date() for s in sessions))

        return {
            "total_sessions": len(sessions),
            "total_heures": round(total_heures, 2),
            "jours_presents": jours_presents,
            "moyenne_heures_par_jour": round(total_heures / jours_presents, 2) if jours_presents > 0 else 0
        }