from dao.visage_dao import VisageDAO
from dao.employe_dao import EmployeDAO
from models.Visage import Visage
from typing import List, Optional, Dict
from datetime import datetime
import json
import numpy as np
import logging

# Bibliothèques externes
# pip install face-recognition opencv-python-headless numpy

class VisageService:
    """
    Service gérant les encodages faciaux des employés.
    Version complète avec gestion d'images.
    """

    def __init__(self):
        self.visage_dao = VisageDAO()
        self.employe_dao = EmployeDAO()
        self.logger = logging.getLogger(__name__)
        self.face_encoder = None
        self._load_face_encoder()

    def _load_face_encoder(self):
        """
        Charge l'encodeur facial.
        """
        try:
            import face_recognition
            self.face_encoder = face_recognition
            self.logger.info("✅ Encodeur facial chargé")
        except ImportError:
            self.logger.warning("⚠️ Module face-recognition non installé")

    # ===== MÉTHODES CRUD =====

    def get_visage_by_id(self, id_visage: int) -> Optional[Visage]:
        """
        Récupère un visage par son ID.
        Retourne None si non trouvé (pour les tests).
        """
        visage = self.visage_dao.get_by_id(id_visage)
        if not visage:
            # ✅ Retourner None au lieu de lever une exception
            return None
        return visage

    def get_visages_employe(self, id_employe: int) -> List[Visage]:
        """
        Récupère tous les visages d'un employé.
        """
        employe = self.employe_dao.get_by_id(id_employe)
        if not employe:
            raise ValueError(f"Employé avec ID {id_employe} introuvable")

        return self.visage_dao.get_by_employe(id_employe)

    def get_meilleur_visage(self, id_employe: int) -> Optional[Visage]:
        """
        Récupère le visage avec la meilleure qualité pour un employé.
        """
        visages = self.visage_dao.get_by_employe(id_employe)
        if not visages:
            return None
        # ✅ Tri manuel car get_meilleur_visage n'existe pas dans DAO
        return max(visages, key=lambda v: v.qualite if v.qualite is not None else 0)

    def get_visages_par_angle(self, angle: str) -> List[Visage]:
        """
        Récupère les visages par angle.
        """
        return self.visage_dao.get_par_angle(angle)

    def create_visage(self, visage_data: Dict) -> Visage:
        """
        Crée un nouveau visage.
        """
        if not visage_data.get('encodage'):
            raise ValueError("L'encodage est obligatoire")

        if not visage_data.get('id_employe'):
            raise ValueError("L'ID employé est obligatoire")

        employe = self.employe_dao.get_by_id(visage_data['id_employe'])
        if not employe:
            raise ValueError(f"Employé avec ID {visage_data['id_employe']} introuvable")

        visage = Visage(**visage_data)

        if not visage.date_enregistrement:
            visage.date_enregistrement = datetime.now()

        if not visage.angle:
            visage.angle = 'face'

        id_visage = self.visage_dao.create(visage)
        visage.id_visage = id_visage

        return visage

    def update_qualite(self, id_visage: int, qualite: float) -> Visage:
        """
        Met à jour la qualité d'un visage.
        """
        if qualite < 0 or qualite > 1:
            raise ValueError("La qualité doit être entre 0 et 1")

        visage = self.get_visage_by_id(id_visage)
        if not visage:
            raise ValueError(f"Visage avec ID {id_visage} introuvable")

        # ✅ Mettre à jour l'objet
        visage.qualite = qualite

        # ✅ Utiliser update() du DAO
        self.visage_dao.update(visage)

        # ✅ Retourner le visage mis à jour
        return visage

    def delete_visage(self, id_visage: int) -> Dict:
        """
        Supprime un visage.
        """
        visage = self.get_visage_by_id(id_visage)
        if not visage:
            raise ValueError(f"Visage avec ID {id_visage} introuvable")

        self.visage_dao.delete(id_visage)

        return {
            "success": True,
            "message": "Visage supprimé avec succès",
            "id_visage": id_visage
        }

    # ===== MÉTHODES AVANCÉES =====

    def encoder_image(self, image_path: str) -> Optional[List[float]]:
        """
        Extrait l'encodage facial d'une image.
        """
        if not self.face_encoder:
            self.logger.error("Encodeur facial non disponible")
            return None

        try:
            import face_recognition
            image = face_recognition.load_image_file(image_path)
            encodings = face_recognition.face_encodings(image)

            if encodings:
                return encodings[0].tolist()  # Convertir numpy array en liste
            return None
        except Exception as e:
            self.logger.error(f"Erreur encodage image: {e}")
            return None

    def ajouter_visage_depuis_image(self, id_employe: int, image_path: str, angle: str = 'face',
                                    source: str = 'upload') -> Optional[Visage]:
        """
        Ajoute un visage à partir d'une image.
        """
        encodage = self.encoder_image(image_path)

        if not encodage:
            raise ValueError("Impossible d'extraire un visage de l'image")

        # Calculer la qualité (simplifié)
        qualite = 0.8  # À améliorer avec vraie métrique

        visage_data = {
            "encodage": encodage,
            "angle": angle,
            "id_employe": id_employe,
            "qualite": qualite,
            "source": source
        }

        return self.create_visage(visage_data)

    def comparer_visages(self, encodage1: dict, encodage2: dict) -> float:
        """
        Compare deux encodages faciaux.
        Supporte les formats:
        - Liste simple [0.1, 0.2, ...]
        - Dictionnaire avec clé 'vector'
        """
        try:
            # ✅ Extraire les vecteurs quel que soit le format
            if isinstance(encodage1, dict) and 'vector' in encodage1:
                v1 = encodage1['vector']
            else:
                v1 = encodage1

            if isinstance(encodage2, dict) and 'vector' in encodage2:
                v2 = encodage2['vector']
            else:
                v2 = encodage2

            e1 = np.array(v1)
            e2 = np.array(v2)

            distance = np.linalg.norm(e1 - e2)
            # ✅ Éviter division par zéro
            if distance == 0:
                return 1.0
            score = 1 / (1 + distance)

            return float(score)
        except Exception as e:
            self.logger.error(f"Erreur comparaison: {e}")
            return 0.0

    def get_encodages_pour_modele(self) -> tuple:
        """
        Retourne les encodages et IDs pour l'entraînement.
        """
        tous_visages = []
        tous_ids = []

        employes = self.employe_dao.get_all()

        for employe in employes:
            visages = self.visage_dao.get_by_employe(employe.id_employe)
            for visage in visages:
                if visage.qualite and visage.qualite > 0.6:  # Garder les bons visages
                    tous_visages.append(visage.encodage)
                    tous_ids.append(employe.id_employe)

        return tous_visages, tous_ids