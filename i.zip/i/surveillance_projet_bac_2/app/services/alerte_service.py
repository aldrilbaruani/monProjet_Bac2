from dao.alerte_dao import AlerteDAO
from dao.employe_dao import EmployeDAO
from dao.evenement_dao import EvenementDAO
from dao.deplacement_dao import DeplacementDAO
from dao.notification_dao import NotificationDAO
from models.Alerte import Alerte
from models.Notification import Notification
from typing import List, Optional, Dict
from datetime import datetime

class AlerteService:

    def __init__(self):
        self.alerte_dao = AlerteDAO()
        self.employe_dao = EmployeDAO()
        self.evenement_dao = EvenementDAO()
        self.deplacement_dao = DeplacementDAO()
        self.notification_dao = NotificationDAO()

    def get_alerte_by_id(self, id_alerte: int) -> Alerte:

        alerte = self.alerte_dao.get_by_id(id_alerte)
        if not alerte:
            raise ValueError(f"Alerte avec ID {id_alerte} introuvable")
        return alerte

    def get_alertes_non_traitees(self) -> List[Alerte]:

        return self.alerte_dao.get_non_traitees()

    def get_alertes_critiques(self) -> List[Alerte]:

        return self.alerte_dao.get_critiques()

    def get_alertes_employe(self, id_employe: int) -> List[Alerte]:

        return self.alerte_dao.get_par_employe(id_employe)

    def create_alerte(self, alerte_data: Dict) -> Alerte:

        if not alerte_data.get('type_alerte'):
            raise ValueError("Le type d'alerte est obligatoire")

        if not alerte_data.get('message'):
            raise ValueError("Le message est obligatoire")

        if not alerte_data.get('niveau_urgence'):
            raise ValueError("Le niveau d'urgence est obligatoire")

        if alerte_data.get('id_employe_concerne'):
            employe = self.employe_dao.get_by_id(alerte_data['id_employe_concerne'])
            if not employe:
                raise ValueError(f"Employé avec ID {alerte_data['id_employe_concerne']} introuvable")

        if alerte_data.get('id_evenement'):
            evenement = self.evenement_dao.get_by_id(alerte_data['id_evenement'])
            if not evenement:
                raise ValueError(f"Événement avec ID {alerte_data['id_evenement']} introuvable")

        if alerte_data.get('id_deplacement'):
            deplacement = self.deplacement_dao.get_by_id(alerte_data['id_deplacement'])
            if not deplacement:
                raise ValueError(f"Déplacement avec ID {alerte_data['id_deplacement']} introuvable")

        alerte = Alerte(**alerte_data)
        alerte.date_generation = datetime.now()
        alerte.statut = 'envoyee'

        id_alerte = self.alerte_dao.create(alerte)
        alerte.id_alerte = id_alerte

        return alerte

    def traiter_alerte(self, id_alerte: int, utilisateur_id: int, commentaire: str = None) -> Alerte:

        alerte = self.get_alerte_by_id(id_alerte)

        if alerte.statut != 'envoyee':
            raise ValueError(f"Cette alerte est déjà {alerte.statut}")

        self.alerte_dao.update_statut(id_alerte, 'traitee', utilisateur_id, commentaire)

        return self.get_alerte_by_id(id_alerte)

    def ignorer_alerte(self, id_alerte: int, utilisateur_id: int, raison: str = None) -> Alerte:

        alerte = self.get_alerte_by_id(id_alerte)

        if alerte.statut != 'envoyee':
            raise ValueError(f"Cette alerte est déjà {alerte.statut}")

        commentaire = f"IGNORÉ: {raison}" if raison else "Ignorée sans raison"
        self.alerte_dao.update_statut(id_alerte, 'ignoree', utilisateur_id, commentaire)

        return self.get_alerte_by_id(id_alerte)

    def get_statistiques(self) -> Dict:

        non_traitees = self.alerte_dao.get_non_traitees()
        critiques = self.alerte_dao.get_critiques()

        par_type = {}
        for a in non_traitees:
            par_type[a.type_alerte] = par_type.get(a.type_alerte, 0) + 1

        return {
            "non_traitees": len(non_traitees),
            "critiques": len(critiques),
            "par_type": par_type
        }

    def notifier_alerte(self, id_alerte: int, canaux: List[str] = None) -> List[Notification]:

        alerte = self.get_alerte_by_id(id_alerte)

        destinataires = []

        if alerte.id_employe_concerne:

            employe = self.employe_dao.get_by_id(alerte.id_employe_concerne)
            if employe and employe.email:
                destinataires.append({
                    'canal': 'EMAIL',
                    'destinataire': employe.email,
                    'id_employe': employe.id_employe
                })

        admins = self.employe_dao.get_by_role('admin')
        for admin in admins:
            if admin.email:
                destinataires.append({
                    'canal': 'EMAIL',
                    'destinataire': admin.email,
                    'id_employe': admin.id_employe
                })

        if canaux:
            destinataires = [d for d in destinataires if d['canal'] in canaux]

        notifications = []
        for dest in destinataires:
            notification = Notification(
                canal=dest['canal'],
                destinataire=dest['destinataire'],
                contenu=f"ALERTE [{alerte.type_alerte.upper()}] {alerte.message}",
                date_envoi=datetime.now(),
                statut_envoi='envoye',
                id_alerte=id_alerte
            )

            id_notif = self.notification_dao.create(notification)
            notification.id_notification = id_notif
            notifications.append(notification)

        return notifications