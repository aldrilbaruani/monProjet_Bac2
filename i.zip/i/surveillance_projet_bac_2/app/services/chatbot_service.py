# app/services/chatbot_service.py
from dao.chatbot_interaction_dao import ChatbotInteractionDAO
from models.ChatbotInteraction import ChatbotInteraction
from services.deplacement_service import DeplacementService
from typing import List, Optional, Dict
from datetime import datetime
import re


class ChatbotService:
    def __init__(self):
        self.chatbot_dao = ChatbotInteractionDAO()
        self.deplacement_service = DeplacementService()

    def create_interaction(self, interaction: ChatbotInteraction) -> Dict:
        """Crée une interaction chatbot."""
        id_interaction = self.chatbot_dao.create(interaction)
        return {
            "success": True,
            "message": "Interaction chatbot enregistrée",
            "id_interaction": id_interaction
        }

    def get_interactions_employe(self, id_employe: int) -> List[ChatbotInteraction]:
        """Récupère toutes les interactions d'un employé."""
        # ✅ CORRECTION : utiliser get_by_employe au lieu de get_par_employe
        return self.chatbot_dao.get_by_employe(id_employe)

    def get_interactions_recentes(self, limite: int = 50) -> List[ChatbotInteraction]:
        """Récupère les interactions récentes."""
        return self.chatbot_dao.get_recentes(limite)

    def get_interaction_by_id(self, id_interaction: int) -> Optional[ChatbotInteraction]:
        """Récupère une interaction par son ID."""
        return self.chatbot_dao.get_by_id(id_interaction)

    def traiter_commande_deplacement(self, commande: str, id_employe: int) -> Dict:
        """Traite une commande de déplacement via le chatbot."""
        # Extraction basique des informations
        # Exemple: "Je vais en zone A pour réunion, retour à 15h"

        # Détecter la destination
        zone_match = re.search(r'zone\s+(\w+)', commande, re.IGNORECASE)
        destination = zone_match.group(1) if zone_match else None

        # Détecter l'heure de retour
        heure_match = re.search(r'(\d{1,2})h', commande)
        heure_retour = heure_match.group(1) if heure_match else "2"

        # Détecter le motif
        motif_match = re.search(r'pour\s+(.+?)(?:,\s*retour|$)', commande, re.IGNORECASE)
        motif = motif_match.group(1).strip() if motif_match else "Déplacement non spécifié"

        # Créer le déplacement
        try:
            deplacement = self.deplacement_service.create_deplacement({
                "id_employe": id_employe,
                "id_zone_destination": 1,  # Zone par défaut (à adapter)
                "motif": motif,
                "date_depart": datetime.now().isoformat(),
                "date_retour_prevue": (
                    datetime.now().replace(hour=int(heure_retour), minute=0)).isoformat() if heure_match else None
            })

            # Enregistrer l'interaction
            interaction = ChatbotInteraction(
                commande=commande,
                reponse=f"Déplacement enregistré vers zone {destination or 'par défaut'}",
                id_employe=id_employe,
                id_deplacement=deplacement.id_deplacement
            )
            self.create_interaction(interaction)

            return {
                "success": True,
                "message": f"Déplacement enregistré avec succès",
                "deplacement_id": deplacement.id_deplacement
            }
        except Exception as e:
            return {
                "success": False,
                "message": f"Erreur: {str(e)}"
            }

    def delete_interaction(self, id_interaction: int) -> bool:
        """Supprime une interaction."""
        return self.chatbot_dao.delete(id_interaction)