# app/services/auth_service.py
from app.dao.employe_dao import EmployeDAO
from app.models.Employe import Employe
from app.utils.security import verify_password, generate_token
from typing import Dict, Optional
import logging

logger = logging.getLogger(__name__)


class AuthService:
    """Service d'authentification."""

    def __init__(self):
        self.employe_dao = EmployeDAO()

    def authenticate(self, email: str, password: str) -> Optional[Dict]:
        """
        Authentifie un employé par email/mot de passe.
        Retourne un token JWT et les informations de l'employé.
        """
        # Récupérer l'employé par email
        employe = self.employe_dao.get_by_email(email)

        if not employe:
            logger.warning(f"Tentative de connexion avec email inconnu: {email}")
            return None

        # Vérifier si le compte est actif
        if not employe.actif:
            logger.warning(f"Tentative de connexion sur compte inactif: {email}")
            return None

        # Vérifier le mot de passe
        if not employe.verifier_mot_de_passe(password):
            logger.warning(f"Mot de passe incorrect pour: {email}")
            return None

        # Générer le token
        token = generate_token(
            employe_id=employe.id_employe,
            email=employe.email,
            role=employe.role
        )

        logger.info(f"Connexion réussie: {email} ({employe.role})")

        return {
            'token': token,
            'employe': employe.to_dict(),
            'role': employe.role
        }

    def register(self, employe_data: Dict, password: str) -> Employe:
        """Inscrit un nouvel employé."""
        from app.services.employe_service import EmployeService

        employe_service = EmployeService()

        # Créer l'employé
        employe = employe_service.create_employe(employe_data)

        # Définir le mot de passe hashé
        employe.set_mot_de_passe(password)

        # Mettre à jour l'employé avec le mot de passe
        self.employe_dao.update(employe)

        logger.info(f"Nouvel employé inscrit: {employe.email}")
        return employe

    def change_password(self, id_employe: int, old_password: str, new_password: str) -> bool:
        """Change le mot de passe d'un employé."""
        employe = self.employe_dao.get_by_id(id_employe)

        if not employe:
            logger.error(f"Employé {id_employe} introuvable")
            return False

        # Vérifier l'ancien mot de passe
        if not employe.verifier_mot_de_passe(old_password):
            logger.warning(f"Ancien mot de passe incorrect pour employé {id_employe}")
            return False

        # Définir le nouveau mot de passe
        employe.set_mot_de_passe(new_password)

        # Mettre à jour
        self.employe_dao.update(employe)

        logger.info(f"Mot de passe changé pour employé {id_employe}")
        return True

    def reset_password(self, id_employe: int, new_password: str) -> bool:
        """Réinitialise le mot de passe d'un employé."""
        employe = self.employe_dao.get_by_id(id_employe)

        if not employe:
            logger.error(f"Employé {id_employe} introuvable")
            return False

        employe.set_mot_de_passe(new_password)
        self.employe_dao.update(employe)

        logger.info(f"Mot de passe réinitialisé pour employé {id_employe}")
        return True