# app/services/CameraService.py

from dao.camera_dao import CameraDAO
from dao.zone_dao import ZoneDAO
from dao.evenement_dao import EvenementDAO
from models.Camera import Camera
from typing import List, Optional, Dict
from datetime import datetime, timedelta

class CameraService:
    """
    Service gérant la logique métier des caméras.
    """

    def __init__(self):
        self.camera_dao = CameraDAO()
        self.zone_dao = ZoneDAO()
        self.evenement_dao = EvenementDAO()

    def get_all_cameras(self, actives_only: bool = False) -> List[Camera]:
        """
        Récupère toutes les caméras.
        """
        if actives_only:
            return self.camera_dao.get_actives()
        return self.camera_dao.get_all()

    def get_camera_by_id(self, id_camera: int) -> Camera:
        """
        Récupère une caméra par son ID.
        """
        camera = self.camera_dao.get_by_id(id_camera)
        if not camera:
            raise ValueError(f"Caméra avec ID {id_camera} introuvable")
        return camera

    def get_cameras_by_zone(self, id_zone: int) -> List[Camera]:
        """
        Récupère les caméras d'une zone.
        """
        # Vérifier que la zone existe
        zone = self.zone_dao.get_by_id(id_zone)
        if not zone:
            raise ValueError(f"Zone avec ID {id_zone} introuvable")

        return self.camera_dao.get_by_zone(id_zone)

    def create_camera(self, camera_data: Dict) -> Camera:
        """
        Crée une nouvelle caméra.
        """
        # Validations
        if not camera_data.get('nom_camera'):
            raise ValueError("Le nom de la caméra est obligatoire")

        if not camera_data.get('flux_url'):
            raise ValueError("L'URL du flux est obligatoire")

        if not camera_data.get('id_zone'):
            raise ValueError("La zone est obligatoire")

        # Vérifier que la zone existe
        zone = self.zone_dao.get_by_id(camera_data['id_zone'])
        if not zone:
            raise ValueError(f"Zone avec ID {camera_data['id_zone']} introuvable")

        # Création
        camera = Camera(**camera_data)

        if camera.est_active is None:
            camera.est_active = True

        id_camera = self.camera_dao.create(camera)
        camera.id_camera = id_camera

        return camera

    def update_camera(self, id_camera: int, camera_data: Dict) -> Camera:
        """
        Met à jour une caméra.
        """
        camera = self.get_camera_by_id(id_camera)

        for key, value in camera_data.items():
            if hasattr(camera, key) and value is not None:
                setattr(camera, key, value)

        self.camera_dao.update(camera)

        return camera

    def delete_camera(self, id_camera: int) -> Dict:
        """
        Supprime une caméra.
        """
        # Vérifier les dépendances
        evenements = self.evenement_dao.get_by_camera(id_camera, 1)
        if evenements:
            raise ValueError("Impossible de supprimer : des événements sont associés à cette caméra")

        self.camera_dao.delete(id_camera)

        return {
            "success": True,
            "message": "Caméra supprimée avec succès",
            "id_camera": id_camera
        }

    def activer_camera(self, id_camera: int) -> Camera:
        """
        Active une caméra.
        """
        camera = self.get_camera_by_id(id_camera)
        camera.est_active = True
        self.camera_dao.update(camera)
        return camera

    def desactiver_camera(self, id_camera: int) -> Camera:
        """
        Désactive une caméra.
        """
        camera = self.get_camera_by_id(id_camera)
        camera.est_active = False
        self.camera_dao.update(camera)
        return camera

    def update_connexion(self, id_camera: int) -> None:
        """
        Met à jour la date de dernière connexion.
        """
        self.camera_dao.update_connexion(id_camera)

    def get_statistiques(self) -> Dict:
        """
        Statistiques sur les caméras.
        """
        toutes = self.camera_dao.get_all()
        actives = [c for c in toutes if c.est_active]
        par_zone = {}

        for camera in toutes:
            zone_id = camera.id_zone
            par_zone[zone_id] = par_zone.get(zone_id, 0) + 1

        return {
            "total": len(toutes),
            "actives": len(actives),
            "inactives": len(toutes) - len(actives),
            "par_zone": par_zone
        }

    def get_cameras_avec_statut(self) -> List[Dict]:
        """
        Récupère les caméras avec leur statut en ligne.
        """
        cameras = self.camera_dao.get_all()
        result = []

        for camera in cameras:
            camera_dict = camera.to_dict()
            # Ajouter des métriques supplémentaires
            camera_dict['est_en_ligne'] = camera.est_en_ligne
            result.append(camera_dict)

        return result