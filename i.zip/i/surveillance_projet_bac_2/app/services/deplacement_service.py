from dao.deplacement_dao import DeplacementDAO
from dao.employe_dao import EmployeDAO
from dao.zone_dao import ZoneDAO
from dao.alerte_dao import AlerteDAO
from models.DeplacementSigne import DeplacementSigne
from models.Alerte import Alerte
from typing import List, Optional, Dict
from datetime import datetime, timedelta

class DeplacementService:

    def __init__(self):
        self.deplacement_dao = DeplacementDAO()
        self.employe_dao = EmployeDAO()
        self.zone_dao = ZoneDAO()
        self.alerte_dao = AlerteDAO()

    def _valider_dates(self, date_depart: datetime, date_retour_prevue: Optional[datetime]) -> None:

        if date_retour_prevue and date_retour_prevue <= date_depart:
            raise ValueError("La date de retour prévue doit être postérieure à la date de départ")

    def get_deplacement_by_id(self, id_deplacement: int) -> DeplacementSigne:

        deplacement = self.deplacement_dao.get_by_id(id_deplacement)
        if not deplacement:
            raise ValueError(f"Déplacement avec ID {id_deplacement} introuvable")
        return deplacement

    def get_deplacements_employe(self, id_employe: int) -> List[DeplacementSigne]:

        employe = self.employe_dao.get_by_id(id_employe)
        if not employe:
            raise ValueError(f"Employé avec ID {id_employe} introuvable")

        return self.deplacement_dao.get_by_employe(id_employe)

    def get_deplacements_en_cours(self) -> List[DeplacementSigne]:

        return self.deplacement_dao.get_en_cours()

    def create_deplacement(self, deplacement_data: Dict) -> DeplacementSigne:

        if not deplacement_data.get('id_employe'):
            raise ValueError("L'ID employé est obligatoire")

        if not deplacement_data.get('id_zone_destination'):
            raise ValueError("La zone de destination est obligatoire")

        if not deplacement_data.get('motif'):
            raise ValueError("Le motif est obligatoire")

        employe = self.employe_dao.get_by_id(deplacement_data['id_employe'])
        if not employe:
            raise ValueError(f"Employé avec ID {deplacement_data['id_employe']} introuvable")

        zone = self.zone_dao.get_by_id(deplacement_data['id_zone_destination'])
        if not zone:
            raise ValueError(f"Zone avec ID {deplacement_data['id_zone_destination']} introuvable")

        date_depart = deplacement_data.get('date_depart', datetime.now())
        date_retour_prevue = deplacement_data.get('date_retour_prevue')

        self._valider_dates(date_depart, date_retour_prevue)

        deplacement = DeplacementSigne(**deplacement_data)
        deplacement.date_depart = date_depart
        deplacement.date_signalement = datetime.now()
        deplacement.statut = 'en_cours'

        id_deplacement = self.deplacement_dao.create(deplacement)
        deplacement.id_deplacement = id_deplacement

        return deplacement

    def update_deplacement(self, id_deplacement: int, deplacement_data: Dict) -> DeplacementSigne:

        deplacement = self.get_deplacement_by_id(id_deplacement)

        if deplacement.statut in ['termine', 'annule']:
            raise ValueError("Impossible de modifier un déplacement terminé ou annulé")

        for key, value in deplacement_data.items():
            if hasattr(deplacement, key) and value is not None:
                setattr(deplacement, key, value)

        self._valider_dates(deplacement.date_depart, deplacement.date_retour_prevue)

        self.deplacement_dao.update(deplacement)

        return deplacement

    def terminer_deplacement(self, id_deplacement: int,
                             date_retour_reel: Optional[datetime] = None) -> DeplacementSigne:

        deplacement = self.get_deplacement_by_id(id_deplacement)

        if deplacement.statut == 'termine':
            raise ValueError("Ce déplacement est déjà terminé")

        if deplacement.statut == 'annule':
            raise ValueError("Ce déplacement a été annulé")

        self.deplacement_dao.terminer(id_deplacement, date_retour_reel)

        return self.get_deplacement_by_id(id_deplacement)

    def annuler_deplacement(self, id_deplacement: int, motif_annulation: str = None) -> DeplacementSigne:

        deplacement = self.get_deplacement_by_id(id_deplacement)

        if deplacement.statut in ['termine', 'annule']:
            raise ValueError(f"Ce déplacement est déjà {deplacement.statut}")

        deplacement.statut = 'annule'
        if motif_annulation:
            deplacement.notes = motif_annulation

        self.deplacement_dao.update(deplacement)

        return deplacement

    def verifier_retards(self) -> List[Dict]:

        deplacements_en_retard = self.deplacement_dao.get_en_retard()
        alertes_generees = []

        for deplacement in deplacements_en_retard:

            self.deplacement_dao.update_statut(deplacement.id_deplacement, 'en_retard')

            retard = datetime.now() - deplacement.date_retour_prevue
            minutes_retard = int(retard.total_seconds() / 60)

            alerte = Alerte(
                type_alerte='retard',
                message=f"Déplacement en retard: {deplacement.motif} - Retard de {minutes_retard} minutes",
                niveau_urgence=3 if minutes_retard < 30 else 4 if minutes_retard < 60 else 5,
                id_employe_concerne=deplacement.id_employe,
                id_deplacement=deplacement.id_deplacement
            )

            id_alerte = self.alerte_dao.create(alerte)

            alertes_generees.append({
                "id_deplacement": deplacement.id_deplacement,
                "id_employe": deplacement.id_employe,
                "retard_minutes": minutes_retard,
                "id_alerte": id_alerte
            })

        return alertes_generees

    def get_statistiques(self) -> Dict:

        en_cours = self.deplacement_dao.get_en_cours()
        en_retard = self.deplacement_dao.get_en_retard()

        par_employe = {}
        for d in en_cours:
            par_employe[d.id_employe] = par_employe.get(d.id_employe, 0) + 1

        return {
            "total_en_cours": len(en_cours),
            "total_en_retard": len(en_retard),
            "employes_avec_deplacement": len(par_employe),
            "deplacements_par_employe": par_employe
        }

    def get_deplacements_du_jour(self) -> List[DeplacementSigne]:

        aujourd_hui = datetime.now().replace(hour=0, minute=0, second=0, microsecond=0)
        demain = aujourd_hui + timedelta(days=1)

        return self.deplacement_dao.get_par_periode(aujourd_hui, demain)

    def verifier_deplacement_actuel(self, id_employe: int) -> Optional[DeplacementSigne]:

        deplacements = self.deplacement_dao.get_by_employe(id_employe)

        for d in deplacements:
            if d.statut == 'en_cours':
                return d

        return None