# app/services/reconnaissance_service.py

from dao.reconnaissance_dao import ReconnaissanceDAO
from dao.employe_dao import EmployeDAO
from dao.evenement_dao import EvenementDAO
from dao.visage_dao import VisageDAO
from models.Reconnaissance import Reconnaissance
from typing import List, Optional, Dict
from datetime import datetime
import logging
import random

class ReconnaissanceService:
    """
    SERVICE DE RECONNAISSANCE - MODE SIMULATION
    Version allégée pour permettre le développement sans dépendances complexes.
    À remplacer par la vraie logique IA ultérieurement.
    """

    def __init__(self):
        self.reconnaissance_dao = ReconnaissanceDAO()
        self.employe_dao = EmployeDAO()
        self.evenement_dao = EvenementDAO()
        self.visage_dao = VisageDAO()
        self.logger = logging.getLogger(__name__)
        self.logger.info("✅ Service de reconnaissance démarré en MODE SIMULATION")

    # --- Méthodes CRUD existantes (conservées à l'identique) ---

    def get_reconnaissance_by_id(self, id_reconnaissance: int) -> Reconnaissance:
        """Récupère une reconnaissance par son ID."""
        reco = self.reconnaissance_dao.get_by_id(id_reconnaissance)
        if not reco:
            raise ValueError(f"Reconnaissance avec ID {id_reconnaissance} introuvable")
        return reco

    def get_reconnaissances_recentes(self, limite: int = 50) -> List[Reconnaissance]:
        """Récupère les reconnaissances récentes."""
        return self.reconnaissance_dao.get_recentes(limite)

    def get_reconnaissances_employe(self, id_employe: int) -> List[Reconnaissance]:
        """Récupère les reconnaissances d'un employé."""
        return self.reconnaissance_dao.get_by_employe(id_employe)

    def create_reconnaissance(self, reconnaissance_data: Dict) -> Reconnaissance:
        """
        Crée une nouvelle reconnaissance (version réelle, sans simulation).
        """
        # Validations
        if not reconnaissance_data.get('id_evenement'):
            raise ValueError("L'ID événement est obligatoire")
        if not reconnaissance_data.get('methode'):
            raise ValueError("La méthode est obligatoire")
        if 'score_confiance' not in reconnaissance_data:
            raise ValueError("Le score de confiance est obligatoire")

        # Vérifier que l'événement existe
        evenement = self.evenement_dao.get_by_id(reconnaissance_data['id_evenement'])
        if not evenement:
            raise ValueError(f"Événement avec ID {reconnaissance_data['id_evenement']} introuvable")

        # Vérifier si une reconnaissance existe déjà pour cet événement
        existing = self.reconnaissance_dao.get_by_evenement(reconnaissance_data['id_evenement'])
        if existing:
            raise ValueError(f"Une reconnaissance existe déjà pour l'événement {reconnaissance_data['id_evenement']}")

        # Vérifier l'employé si fourni
        if reconnaissance_data.get('id_employe'):
            employe = self.employe_dao.get_by_id(reconnaissance_data['id_employe'])
            if not employe:
                raise ValueError(f"Employé avec ID {reconnaissance_data['id_employe']} introuvable")

        # Création
        reconnaissance = Reconnaissance(**reconnaissance_data)
        if not reconnaissance.date_analyse:
            reconnaissance.date_analyse = datetime.now()

        id_reco = self.reconnaissance_dao.create(reconnaissance)
        reconnaissance.id_reconnaissance = id_reco
        return reconnaissance

    def update_reconnaissance(self, id_reconnaissance: int, reconnaissance_data: Dict) -> Reconnaissance:
        """Met à jour une reconnaissance."""
        reconnaissance = self.get_reconnaissance_by_id(id_reconnaissance)
        for key, value in reconnaissance_data.items():
            if hasattr(reconnaissance, key) and value is not None:
                setattr(reconnaissance, key, value)
        self.reconnaissance_dao.update(reconnaissance)
        return reconnaissance

    def get_statistiques(self) -> Dict:
        """Statistiques sur les reconnaissances."""
        stats = self.reconnaissance_dao.get_statistiques()
        recentes = self.reconnaissance_dao.get_recentes(100)
        confiance_moyenne = 0
        if recentes:
            confiance_moyenne = sum(r.score_confiance for r in recentes) / len(recentes)

        return {
            **stats,
            "confiance_moyenne_recents": confiance_moyenne,
            "taux_identification": (stats.get('employes_identifies', 0) / stats.get('total', 1)) * 100
        }

    # --- MÉTHODE DE SIMULATION (cœur du mode développement) ---

    def traiter_evenement(self, id_evenement: int, mode_simulation: bool = True) -> Optional[Reconnaissance]:
        """
        Traite un événement pour reconnaissance.
        En mode simulation, retourne un résultat aléatoire mais plausible.
        """
        evenement = self.evenement_dao.get_by_id(id_evenement)
        if not evenement:
            raise ValueError(f"Événement {id_evenement} introuvable")

        # Vérifier si une reconnaissance existe déjà
        existing = self.reconnaissance_dao.get_by_evenement(id_evenement)
        if existing:
            return existing

        # --- LOGIQUE DE SIMULATION ---
        if mode_simulation:
            self.logger.info(f"🎲 Mode simulation pour l'événement {id_evenement}")

            # 1. Décider aléatoirement si la personne est identifiée (70% de chance)
            est_identifie = random.random() < 0.7

            if est_identifie:
                # Choisir un employé aléatoire parmi ceux qui existent
                tous_employes = self.employe_dao.get_all()
                if tous_employes:
                    employe = random.choice(tous_employes)
                    score = round(random.uniform(0.75, 0.99), 2)

                    reconnaissance_data = {
                        "id_evenement": id_evenement,
                        "methode": "faciale",
                        "score_confiance": score,
                        "id_employe": employe.id_employe,
                        "date_analyse": datetime.now()
                    }
                    self.logger.info(f"✅ Simulation: Employé {employe.nom} {employe.prenom} identifié (score: {score})")
                else:
                    # Aucun employé en base, on retourne inconnu
                    reconnaissance_data = {
                        "id_evenement": id_evenement,
                        "methode": "inconnu",
                        "score_confiance": 0.0,
                        "date_analyse": datetime.now()
                    }
                    self.logger.info("❌ Simulation: Personne non identifiée (aucun employé en base)")
            else:
                # Personne non identifiée
                reconnaissance_data = {
                    "id_evenement": id_evenement,
                    "methode": "inconnu",
                    "score_confiance": round(random.uniform(0.1, 0.4), 2),
                    "date_analyse": datetime.now()
                }
                self.logger.info("❌ Simulation: Personne non identifiée")

            # Créer la reconnaissance en base
            return self.create_reconnaissance(reconnaissance_data)

        # --- SI ON SOUHAITE AJOUTER UN VRAI MODULE PLUS TARD ---
        else:
            # Placeholder pour la vraie logique IA
            self.logger.warning("Mode réel non implémenté - utilisation de la simulation")
            return self.traiter_evenement(id_evenement, mode_simulation=True)