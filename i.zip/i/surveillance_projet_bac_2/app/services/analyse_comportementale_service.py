# analyse_comportementale_service.py - VERSION CORRIGÉE

from services.evenement_service import EvenementService  # ← Correction ici !
from services.reconnaissance_service import ReconnaissanceService
from services.deplacement_service import DeplacementService
from services.alerte_service import AlerteService
from services.employe_service import EmployeService
from services.zone_service import ZoneService
from models.Alerte import Alerte
from typing import List, Dict, Optional
from datetime import datetime, timedelta


class AnalyseComportementaleService:
    """
    Service d'analyse comportementale.
    C'est l'IA du système qui compare les déplacements signalés
    avec les détections réelles des caméras.
    """

    def __init__(self):
        self.evenement_service = EvenementService()
        self.reconnaissance_service = ReconnaissanceService()
        self.deplacement_service = DeplacementService()
        self.alerte_service = AlerteService()
        self.employe_service = EmployeService()
        self.zone_service = ZoneService()

    def analyser_evenement(self, id_evenement: int) -> Dict:
        """Analyse un événement de détection."""
        evenement = self.evenement_service.get_evenement_by_id(id_evenement)

        resultat = {
            "id_evenement": id_evenement,
            "type": evenement.type_evenement,
            "analyse": {},
            "alertes_generees": []
        }

        # Si c'est une détection de personne
        if evenement.a_personne_detectee:
            # Essayer de reconnaître la personne
            reconnaissance = self._identifier_personne(evenement)

            if reconnaissance and reconnaissance.id_employe:
                # Personne identifiée
                employe = self.employe_service.get_employe_by_id(reconnaissance.id_employe)
                resultat["analyse"]["employe_identifie"] = employe.to_dict()
                resultat["analyse"]["confiance"] = reconnaissance.score_confiance

                # Vérifier si cet employé a un déplacement en cours
                self._verifier_deplacement_employe(employe.id_employe, evenement, resultat)

                # Vérifier les droits d'accès à la zone
                self._verifier_acces_zone(employe, evenement, resultat)

            else:
                # Personne non identifiée
                resultat["analyse"]["employe_identifie"] = None
                resultat["analyse"]["confiance"] = 0

                # Alerte : personne non identifiée
                alerte = self._creer_alerte_inconnu(evenement)
                resultat["alertes_generees"].append(alerte.to_dict())

        return resultat

    def _identifier_personne(self, evenement):
        """Identifie une personne à partir d'un événement."""
        # Logique d'identification (à implémenter avec votre IA)
        return None

    def _verifier_deplacement_employe(self, id_employe: int, evenement, resultat: Dict):
        """Vérifie si l'employé a un déplacement en cours."""
        deplacement = self.deplacement_service.verifier_deplacement_actuel(id_employe)

        if deplacement:
            resultat["analyse"]["deplacement_en_cours"] = deplacement.to_dict()

            # Vérifier si la zone correspond
            if evenement.id_zone != deplacement.id_zone_destination:
                # L'employé n'est pas dans la zone prévue
                alerte = self._creer_alerte_zone_incorrecte(id_employe, evenement, deplacement)
                resultat["alertes_generees"].append(alerte.to_dict())
        else:
            resultat["analyse"]["deplacement_en_cours"] = None
            # L'employé est détecté sans déplacement signalé
            alerte = self._creer_alerte_deplacement_manquant(id_employe, evenement)
            resultat["alertes_generees"].append(alerte.to_dict())

    def _verifier_acces_zone(self, employe, evenement, resultat: Dict):
        """Vérifie si l'employé a le droit d'être dans cette zone."""
        zone = self.zone_service.get_zone_by_id(evenement.id_zone)

        if zone and zone.est_sensible:
            # Zone sensible, vérifier les droits
            acces = self.zone_service.verifier_acces(employe.id_employe, zone.id_zone)

            if not acces:
                alerte = self._creer_alerte_acces_non_autorise(employe, evenement, zone)
                resultat["alertes_generees"].append(alerte.to_dict())

    def _creer_alerte_inconnu(self, evenement):
        """Crée une alerte pour personne non identifiée."""
        alerte = Alerte(
            type_alerte='intrusion',
            message=f"Personne non identifiée détectée dans la zone",
            niveau_urgence=4,
            id_evenement=evenement.id_evenement
        )
        return self.alerte_service.create_alerte(alerte.__dict__)

    def _creer_alerte_zone_incorrecte(self, employe, evenement, deplacement):
        """Crée une alerte pour zone incorrecte."""
        alerte = Alerte(
            type_alerte='zone_interdite',
            message=f"Employé {employe.nom} {employe.prenom} détecté dans zone non prévue",
            niveau_urgence=3,
            id_employe_concerne=employe.id_employe,
            id_evenement=evenement.id_evenement,
            id_deplacement=deplacement.id_deplacement
        )
        return self.alerte_service.create_alerte(alerte.__dict__)

    def _creer_alerte_deplacement_manquant(self, id_employe: int, evenement):
        """Crée une alerte pour déplacement non signalé."""
        alerte = Alerte(
            type_alerte='absence',
            message=f"Employé détecté sans déplacement signalé",
            niveau_urgence=2,
            id_employe_concerne=id_employe,
            id_evenement=evenement.id_evenement
        )
        return self.alerte_service.create_alerte(alerte.__dict__)

    def _creer_alerte_acces_non_autorise(self, employe, evenement, zone):
        """Crée une alerte pour accès non autorisé."""
        alerte = Alerte(
            type_alerte='zone_interdite',
            message=f"Accès non autorisé à la zone {zone.nom_zone}",
            niveau_urgence=5,
            id_employe_concerne=employe.id_employe,
            id_evenement=evenement.id_evenement
        )
        return self.alerte_service.create_alerte(alerte.__dict__)

    def scanner_periodique(self) -> Dict:
        """Analyse périodique de tout le système."""
        resultats = {
            "timestamp": datetime.now().isoformat(),
            "retards_detectes": [],
            "intrusions_detectees": [],
            "alertes_generees": []
        }

        # 1. Vérifier les retards de déplacement
        retards = self.deplacement_service.verifier_retards()
        resultats["retards_detectes"] = retards

        # 2. Analyser les événements récents non traités
        evenements_recents = self.evenement_service.get_evenements_recents(50)

        for evenement in evenements_recents:
            analyse = self.analyser_evenement(evenement.id_evenement)
            if analyse["alertes_generees"]:
                resultats["alertes_generees"].extend(analyse["alertes_generees"])

        return resultats