# app/services/evenement_service.py
from dao.evenement_dao import EvenementDAO
from dao.camera_dao import CameraDAO
from dao.session_presence_dao import SessionPresenceDAO
from dao.reconnaissance_dao import ReconnaissanceDAO
from models.Evenement import Evenement
from models.Reconnaissance import Reconnaissance
from typing import List, Optional, Dict
from datetime import datetime, timedelta
import json

class EvenementService:

    def __init__(self):
        self.evenement_dao = EvenementDAO()
        self.camera_dao = CameraDAO()
        self.session_dao = SessionPresenceDAO()
        self.reconnaissance_dao = ReconnaissanceDAO()

    # ===== MÉTHODES CRUD =====

    def get_evenement_by_id(self, id_evenement: int) -> Optional[Evenement]:
        """Récupère un événement par son ID."""
        return self.evenement_dao.get_by_id(id_evenement)

    def create_evenement(self, evenement_data: Dict) -> Evenement:
        """
        Crée un nouvel événement.
        """
        # Validation des champs obligatoires
        if not evenement_data.get('date_heure'):
            raise ValueError("La date/heure est obligatoire")
        if not evenement_data.get('type_evenement'):
            raise ValueError("Le type d'événement est obligatoire")
        if evenement_data.get('confiance') is None:
            raise ValueError("La confiance est obligatoire")
        if evenement_data.get('metadata') is None:
            raise ValueError("Les métadonnées sont obligatoires")
        if not evenement_data.get('id_camera'):
            raise ValueError("L'ID caméra est obligatoire")

        # Vérifier que la caméra existe
        camera = self.camera_dao.get_by_id(evenement_data['id_camera'])
        if not camera:
            raise ValueError(f"Caméra avec ID {evenement_data['id_camera']} introuvable")

        # Vérifier la session si fournie
        if evenement_data.get('id_session'):
            session = self.session_dao.get_by_id(evenement_data['id_session'])
            if not session:
                raise ValueError(f"Session avec ID {evenement_data['id_session']} introuvable")

        # Créer l'objet Evenement
        evenement = Evenement(**evenement_data)

        # Définir la date/heure par défaut si non fournie
        if not evenement.date_heure:
            evenement.date_heure = datetime.now()

        # Insérer en base
        id_evenement = self.evenement_dao.create(evenement)
        evenement.id_evenement = id_evenement

        return evenement

    def create_evenements_batch(self, evenements_data: List[Dict]) -> List[Evenement]:
        """
        Crée plusieurs événements en une seule requête.
        """
        evenements = []
        for data in evenements_data:
            evenement = Evenement(**data)
            if not evenement.date_heure:
                evenement.date_heure = datetime.now()
            evenements.append(evenement)

        if evenements:
            self.evenement_dao.create_many(evenements)

        return evenements

    def get_evenements_recents(self, limite: int = 100) -> List[Evenement]:
        """
        Récupère les événements récents.
        """
        return self.evenement_dao.get_recents(limite)

    def get_evenements_par_camera(self, id_camera: int, limite: int = 100) -> List[Evenement]:
        """
        Récupère les événements d'une caméra.
        """
        return self.evenement_dao.get_by_camera(id_camera, limite)

    def get_evenements_par_periode(self, debut: datetime, fin: datetime) -> List[Evenement]:
        """
        Récupère les événements sur une période.
        """
        return self.evenement_dao.get_par_periode(debut, fin)

    def get_statistiques_par_jour(self, jours: int = 7) -> List[Dict]:
        """
        Statistiques journalières des événements.
        """
        stats = []
        for i in range(jours):
            jour = datetime.now().date() - timedelta(days=i)
            stat_jour = self.evenement_dao.get_statistiques_journalieres(jour)
            # ✅ Gérer les valeurs None
            stat_jour['date'] = jour.isoformat()
            stat_jour['total'] = stat_jour.get('total', 0) or 0
            stat_jour['cameras_actives'] = stat_jour.get('cameras_actives', 0) or 0
            confiance = stat_jour.get('confiance_moyenne')
            stat_jour['confiance_moyenne'] = float(confiance) if confiance is not None else 0.0
            stats.append(stat_jour)

        return stats

    def get_activite_par_heure(self) -> Dict[int, int]:
        """
        Récupère l'activité par heure.
        """
        query = """
        SELECT HOUR(date_heure) as heure, COUNT(*) as count
        FROM evenement
        WHERE date_heure >= DATE_SUB(NOW(), INTERVAL 24 HOUR)
        GROUP BY HOUR(date_heure)
        ORDER BY heure
        """
        results = self.evenement_dao.execute_query(query, fetchall=True)

        return {row['heure']: row['count'] for row in results} if results else {}

    def associer_reconnaissance(self, id_evenement: int, reconnaissance_data: Dict) -> Reconnaissance:
        """
        Associe une reconnaissance à un événement.
        """
        evenement = self.evenement_dao.get_by_id(id_evenement)
        if not evenement:
            raise ValueError(f"Événement avec ID {id_evenement} introuvable")

        existing = self.reconnaissance_dao.get_by_evenement(id_evenement)
        if existing:
            raise ValueError(f"Une reconnaissance existe déjà pour l'événement {id_evenement}")

        reconnaissance = Reconnaissance(**reconnaissance_data)
        reconnaissance.id_evenement = id_evenement
        reconnaissance.date_analyse = datetime.now()

        id_reconnaissance = self.reconnaissance_dao.create(reconnaissance)
        reconnaissance.id_reconnaissance = id_reconnaissance

        return reconnaissance

    def delete_evenement(self, id_evenement: int) -> bool:
        """
        Supprime un événement.
        """
        return self.evenement_dao.delete(id_evenement)