# app/dao/employe_dao.py

from dao.base_dao import BaseDAO
from models.Employe import Employe
from typing import List, Optional
import json


class EmployeDAO(BaseDAO):

    def get_by_id(self, id_employe: int) -> Optional[Employe]:
        """Récupère un employé par son ID."""
        query = "SELECT * FROM employe WHERE id_employe = %s"
        result = self.execute_query(query, (id_employe,), fetchone=True)

        if result:
            return Employe(**result)
        return None

    def get_by_email(self, email: str) -> Optional[Employe]:
        """Récupère un employé par son email."""
        query = "SELECT * FROM employe WHERE email = %s"
        result = self.execute_query(query, (email,), fetchone=True)

        if result:
            return Employe(**result)
        return None

    def get_all(self) -> List[Employe]:
        """Récupère tous les employés."""
        query = "SELECT * FROM employe ORDER BY nom, prenom"
        results = self.execute_query(query, fetchall=True)

        return [Employe(**row) for row in results] if results else []

    def get_by_role(self, role: str) -> List[Employe]:
        """Récupère les employés par rôle."""
        query = "SELECT * FROM employe WHERE role = %s ORDER BY nom, prenom"
        results = self.execute_query(query, (role,), fetchall=True)

        return [Employe(**row) for row in results] if results else []

    def get_actifs(self) -> List[Employe]:
        """Récupère les employés actifs."""
        query = "SELECT * FROM employe WHERE actif = TRUE ORDER BY nom, prenom"
        results = self.execute_query(query, fetchall=True)

        return [Employe(**row) for row in results] if results else []

    def create(self, employe: Employe) -> int:
        query = """
        INSERT INTO employe
        (nom, prenom, poste, email, telephone, date_embauche, photo_principale, role, actif, mot_de_passe)
        VALUES (%s, %s, %s, %s, %s, %s, %s, %s, %s, %s)
        """

        params = (
            employe.nom,
            employe.prenom,
            employe.poste,
            employe.email,
            employe.telephone,
            employe.date_embauche,
            employe.photo_principale,
            employe.role,
            employe.actif,
            employe.mot_de_passe
        )

        # Utiliser return_last_id=True
        last_id = self.execute_query(query, params, return_last_id=True)
        print(f"🟢 ID généré: {last_id}")

        return last_id if last_id else 0

    def update(self, employe: Employe) -> bool:
        """Met à jour un employé existant."""
        query = """
        UPDATE employe
        SET nom=%s, prenom=%s, poste=%s, email=%s,
            telephone=%s, date_embauche=%s, photo_principale=%s,
            role=%s, actif=%s, mot_de_passe=%s
        WHERE id_employe=%s
        """

        params = (
            employe.nom,
            employe.prenom,
            employe.poste,
            employe.email,
            employe.telephone,
            employe.date_embauche,
            employe.photo_principale,
            employe.role,
            employe.actif,
            employe.mot_de_passe,
            employe.id_employe
        )

        self.execute_query(query, params)
        return True

    def delete(self, id_employe: int) -> bool:
        """Supprime un employé."""
        query = "DELETE FROM employe WHERE id_employe = %s"
        self.execute_query(query, (id_employe,))
        return True

    def search(self, terme: str) -> List[Employe]:

        query = """
        SELECT * FROM employe 
        WHERE nom LIKE %s OR prenom LIKE %s OR email LIKE %s
        ORDER BY nom, prenom
        """
        search_term = f"%{terme}%"
        params = (search_term, search_term, search_term)
        results = self.execute_query(query, params, fetchall=True)
        return [Employe(**row) for row in results] if results else []

    def update_password(self, id_employe: int, mot_de_passe_hash: str) -> bool:
        """Met à jour le mot de passe d'un employé."""
        query = "UPDATE employe SET mot_de_passe = %s WHERE id_employe = %s"
        self.execute_query(query, (mot_de_passe_hash, id_employe))
        return True