# app/dao/__init__.py

from dao.alerte_dao import AlerteDAO
from dao.camera_dao import CameraDAO
from dao.chatbot_interaction_dao import ChatbotInteractionDAO
from dao.deplacement_dao import DeplacementDAO
from dao.employe_dao import EmployeDAO
from dao.evenement_dao import EvenementDAO
from dao.notification_dao import NotificationDAO
from dao.reconnaissance_dao import ReconnaissanceDAO
from dao.session_presence_dao import SessionPresenceDAO
from dao.uniforme_dao import UniformeDAO
from dao.visage_dao import VisageDAO
from dao.zone_dao import ZoneDAO
from dao.base_dao import BaseDAO

# Liste de tous les DAO disponibles
__all__ = [
    'BaseDAO',
    'AlerteDAO',
    'CameraDAO',
    'ChatbotInteractionDAO',
    'DeplacementDAO',
    'EmployeDAO',
    'EvenementDAO',
    'NotificationDAO',
    'ReconnaissanceDAO',
    'SessionPresenceDAO',
    'UniformeDAO',
    'VisageDAO',
    'ZoneDAO'
]