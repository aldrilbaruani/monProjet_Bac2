from dao.base_dao import BaseDAO
from models.Visage import Visage
from typing import List, Optional
import json


class VisageDAO(BaseDAO):

    def get_by_id(self, id_visage: int) -> Optional[Visage]:
        query = "SELECT * FROM visage WHERE id_visage = %s"
        result = self.execute_query(query, (id_visage,), fetchone=True)

        if result:
            return Visage(**result)
        return None

    def get_by_employe(self, id_employe: int) -> List[Visage]:
        query = """
        SELECT * FROM visage 
        WHERE id_employe = %s 
        ORDER BY date_enregistrement DESC
        """
        results = self.execute_query(query, (id_employe,), fetchall=True)

        return [Visage(**row) for row in results] if results else []

    def get_meilleur_visage(self, id_employe: int) -> Optional[Visage]:

        query = """
        SELECT * FROM visage 
        WHERE id_employe = %s 
        ORDER BY qualite DESC, date_enregistrement DESC
        LIMIT 1
        """
        result = self.execute_query(query, (id_employe,), fetchone=True)

        if result:
            return Visage(**result)
        return None

    def get_par_angle(self, angle: str) -> List[Visage]:
        query = """
        SELECT * FROM visage 
        WHERE angle = %s 
        ORDER BY qualite DESC
        """
        results = self.execute_query(query, (angle,), fetchall=True)

        return [Visage(**row) for row in results] if results else []

    def get_de_bonne_qualite(self, seuil: float = 0.7) -> List[Visage]:

        query = """
        SELECT * FROM visage 
        WHERE qualite >= %s 
        ORDER BY qualite DESC
        """
        results = self.execute_query(query, (seuil,), fetchall=True)

        return [Visage(**row) for row in results] if results else []

    # app/dao/visage_dao.py - create() modifié

    def create(self, visage: Visage) -> int:
        query = """
        INSERT INTO visage
        (encodage, angle, date_enregistrement, id_employe, qualite, source)
        VALUES (%s, %s, %s, %s, %s, %s)
        """

        encodage = json.dumps(visage.encodage) if visage.encodage else "{}"

        params = (
            encodage,
            visage.angle,
            visage.date_enregistrement,
            visage.id_employe,
            visage.qualite,
            visage.source
        )

        # Utiliser return_last_id=True
        last_id = self.execute_query(query, params, return_last_id=True)
        print(f"🟢 Visage ID généré: {last_id}")

        return last_id if last_id else 0

    def update_qualite(self, id_visage: int, qualite: float) -> bool:

        query = "UPDATE visage SET qualite = %s WHERE id_visage = %s"
        self.execute_query(query, (qualite, id_visage))
        return True

    def delete(self, id_visage: int) -> bool:
        query = "DELETE FROM visage WHERE id_visage = %s"
        self.execute_query(query, (id_visage,))
        return True

    # app/dao/visage_dao.py - ajouter/modifier

    def update(self, visage: Visage) -> bool:
        """Met à jour un visage."""
        query = """
            UPDATE visage
            SET encodage=%s, angle=%s, date_enregistrement=%s,
                id_employe=%s, qualite=%s, source=%s
            WHERE id_visage=%s
        """
        encodage = json.dumps(visage.encodage) if visage.encodage else "{}"
        params = (
            encodage,
            visage.angle,
            visage.date_enregistrement,
            visage.id_employe,
            visage.qualite,
            visage.source,
            visage.id_visage
        )
        self.execute_query(query, params)
        return True