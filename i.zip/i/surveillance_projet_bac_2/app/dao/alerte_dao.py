# app/dao/alerte_dao.py

from dao.base_dao import BaseDAO
from models.Alerte import Alerte
from typing import List, Optional


class AlerteDAO(BaseDAO):

    def get_by_id(self, id_alerte: int) -> Optional[Alerte]:
        query = "SELECT * FROM alerte WHERE id_alerte = %s"
        result = self.execute_query(query, (id_alerte,), fetchone=True)

        if result:
            return Alerte(**result)
        return None

    def get_non_traitees(self) -> List[Alerte]:
        query = """
        SELECT * FROM alerte
        WHERE statut = 'envoyee'
        ORDER BY niveau_urgence DESC, date_generation
        """
        results = self.execute_query(query, fetchall=True)
        return [Alerte(**row) for row in results] if results else []

    def get_par_employe(self, id_employe: int) -> List[Alerte]:
        query = """
        SELECT * FROM alerte
        WHERE id_employe_concerne = %s
        ORDER BY date_generation DESC
        """
        results = self.execute_query(query, (id_employe,), fetchall=True)
        return [Alerte(**row) for row in results] if results else []

    def get_critiques(self) -> List[Alerte]:
        query = """
        SELECT * FROM alerte
        WHERE niveau_urgence >= 4 AND statut = 'envoyee'
        ORDER BY date_generation
        """
        results = self.execute_query(query, fetchall=True)
        return [Alerte(**row) for row in results] if results else []

    def get_recentes(self, limite: int = 50) -> List[Alerte]:
        query = """
        SELECT * FROM alerte
        ORDER BY date_generation DESC
        LIMIT %s
        """
        results = self.execute_query(query, (limite,), fetchall=True)
        return [Alerte(**row) for row in results] if results else []

    # app/dao/alerte_dao.py - create() modifié

    def create(self, alerte: Alerte) -> int:
        query = """
        INSERT INTO alerte
        (type_alerte, message, date_generation, date_traitement,
         niveau_urgence, statut, id_employe_concerne, id_evenement,
         id_deplacement, traitee_par, commentaire)
        VALUES (%s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s)
        """

        params = (
            alerte.type_alerte,
            alerte.message,
            alerte.date_generation,
            alerte.date_traitement,
            alerte.niveau_urgence,
            alerte.statut,
            alerte.id_employe_concerne,
            alerte.id_evenement,
            alerte.id_deplacement,
            alerte.traitee_par,
            alerte.commentaire
        )

        # Utiliser return_last_id=True
        last_id = self.execute_query(query, params, return_last_id=True)
        print(f"🟢 Alerte ID généré: {last_id}")

        return last_id if last_id else 0

    def update_statut(self, id_alerte: int, statut: str, traitee_par: int = None, commentaire: str = None) -> bool:
        query = """
        UPDATE alerte
        SET statut = %s, date_traitement = NOW()
        """

        params = [statut]

        if traitee_par:
            query += ", traitee_par = %s"
            params.append(traitee_par)

        if commentaire:
            query += ", commentaire = %s"
            params.append(commentaire)

        query += " WHERE id_alerte = %s"
        params.append(id_alerte)

        self.execute_query(query, tuple(params))
        return True

    def delete(self, id_alerte: int) -> bool:
        query = "DELETE FROM alerte WHERE id_alerte = %s"
        self.execute_query(query, (id_alerte,))
        return True