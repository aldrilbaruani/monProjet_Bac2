# app/dao/zone_dao.py - create() et get_by_id() modifiés

from dao.base_dao import BaseDAO
from models.Zone import Zone
from typing import List, Optional
import json


class ZoneDAO(BaseDAO):

    def get_by_id(self, id_zone: int) -> Optional[Zone]:
        query = "SELECT * FROM zone WHERE id_zone = %s"
        result = self.execute_query(query, (id_zone,), fetchone=True)

        if result:
            # Convertir coordonnees JSON si nécessaire
            if result.get('coordonnees') and isinstance(result['coordonnees'], str):
                result['coordonnees'] = json.loads(result['coordonnees'])
            return Zone(**result)
        return None

    def get_all(self) -> List[Zone]:
        query = "SELECT * FROM zone ORDER BY nom_zone"
        results = self.execute_query(query, fetchall=True)

        if results:
            for row in results:
                if row.get('coordonnees') and isinstance(row['coordonnees'], str):
                    row['coordonnees'] = json.loads(row['coordonnees'])
            return [Zone(**row) for row in results]
        return []

    def get_by_type(self, type_zone: str) -> List[Zone]:
        query = "SELECT * FROM zone WHERE type_zone = %s ORDER BY nom_zone"
        results = self.execute_query(query, (type_zone,), fetchall=True)

        if results:
            for row in results:
                if row.get('coordonnees') and isinstance(row['coordonnees'], str):
                    row['coordonnees'] = json.loads(row['coordonnees'])
            return [Zone(**row) for row in results]
        return []

    # app/dao/alerte_dao.py - create() modifié

    # app/dao/zone_dao.py - create() modifié

    def create(self, zone: Zone) -> int:
        query = """
        INSERT INTO zone (nom_zone, type_zone, description, niveau_acces, coordonnees)
        VALUES (%s, %s, %s, %s, %s)
        """

        # Convertir le dictionnaire en JSON string
        coordonnees = json.dumps(zone.coordonnees) if zone.coordonnees else None

        params = (
            zone.nom_zone,
            zone.type_zone,
            zone.description,
            zone.niveau_acces,
            coordonnees
        )

        # Utiliser return_last_id=True
        last_id = self.execute_query(query, params, return_last_id=True)
        print(f"🟢 Zone ID généré: {last_id}")

        return last_id if last_id else 0


    def update(self, zone: Zone) -> bool:
        query = """
        UPDATE zone
        SET nom_zone=%s, type_zone=%s, description=%s,
            niveau_acces=%s, coordonnees=%s
        WHERE id_zone=%s
        """

        coordonnees = json.dumps(zone.coordonnees) if zone.coordonnees else None

        params = (
            zone.nom_zone,
            zone.type_zone,
            zone.description,
            zone.niveau_acces,
            coordonnees,
            zone.id_zone
        )

        self.execute_query(query, params)
        return True

    def delete(self, id_zone: int) -> bool:
        query = "DELETE FROM zone WHERE id_zone = %s"
        self.execute_query(query, (id_zone,))
        return True