# app/dao/uniforme_dao.py

from dao.base_dao import BaseDAO
from models.Uniforme import Uniforme
from typing import List, Optional
from datetime import date  # ← AJOUT IMPORTANT


class UniformeDAO(BaseDAO):

    def get_by_id(self, id_uniforme: int) -> Optional[Uniforme]:
        query = "SELECT * FROM uniforme WHERE id_uniforme = %s"
        result = self.execute_query(query, (id_uniforme,), fetchone=True)

        if result:
            # Convertir les dates si nécessaire
            if result.get('date_debut') and isinstance(result['date_debut'], date):
                result['date_debut'] = result['date_debut']
            if result.get('date_fin') and isinstance(result['date_fin'], date):
                result['date_fin'] = result['date_fin']
            return Uniforme(**result)
        return None

    def get_by_employe(self, id_employe: int) -> List[Uniforme]:
        query = """
        SELECT * FROM uniforme 
        WHERE id_employe = %s 
        ORDER BY date_debut DESC
        """
        results = self.execute_query(query, (id_employe,), fetchall=True)

        if results:
            for row in results:
                if row.get('date_debut') and isinstance(row['date_debut'], date):
                    row['date_debut'] = row['date_debut']
                if row.get('date_fin') and isinstance(row['date_fin'], date):
                    row['date_fin'] = row['date_fin']
            return [Uniforme(**row) for row in results]
        return []

    def get_actif(self, id_employe: int) -> Optional[Uniforme]:
        query = """
        SELECT * FROM uniforme 
        WHERE id_employe = %s AND (date_fin IS NULL OR date_fin >= CURDATE())
        ORDER BY date_debut DESC
        LIMIT 1
        """
        result = self.execute_query(query, (id_employe,), fetchone=True)

        if result:
            if result.get('date_debut') and isinstance(result['date_debut'], date):
                result['date_debut'] = result['date_debut']
            if result.get('date_fin') and isinstance(result['date_fin'], date):
                result['date_fin'] = result['date_fin']
            return Uniforme(**result)
        return None

    def get_par_couleur(self, couleur: str) -> List[Uniforme]:
        query = """
        SELECT * FROM uniforme 
        WHERE couleur_dominante = %s 
        ORDER BY date_debut DESC
        """
        results = self.execute_query(query, (couleur,), fetchall=True)

        if results:
            for row in results:
                if row.get('date_debut') and isinstance(row['date_debut'], date):
                    row['date_debut'] = row['date_debut']
                if row.get('date_fin') and isinstance(row['date_fin'], date):
                    row['date_fin'] = row['date_fin']
            return [Uniforme(**row) for row in results]
        return []

    def create(self, uniforme: Uniforme) -> int:
        query = """
        INSERT INTO uniforme
        (couleur_dominante, type_tenue, date_debut, date_fin, id_employe)
        VALUES (%s, %s, %s, %s, %s)
        """

        params = (
            uniforme.couleur_dominante,
            uniforme.type_tenue,
            uniforme.date_debut,
            uniforme.date_fin,
            uniforme.id_employe
        )

        # Utiliser return_last_id=True
        last_id = self.execute_query(query, params, return_last_id=True)
        print(f"🟢 Uniforme ID généré: {last_id}")

        return last_id if last_id else 0

    def update(self, uniforme: Uniforme) -> bool:
        query = """
        UPDATE uniforme
        SET couleur_dominante=%s, type_tenue=%s, date_debut=%s, date_fin=%s
        WHERE id_uniforme=%s
        """

        params = (
            uniforme.couleur_dominante,
            uniforme.type_tenue,
            uniforme.date_debut,
            uniforme.date_fin,
            uniforme.id_uniforme
        )

        self.execute_query(query, params)
        return True

    def terminer(self, id_uniforme: int, date_fin: date = None) -> bool:
        """Termine l'utilisation d'un uniforme."""
        if date_fin is None:
            date_fin = date.today()

        query = "UPDATE uniforme SET date_fin = %s WHERE id_uniforme = %s"
        self.execute_query(query, (date_fin, id_uniforme))
        return True

    def delete(self, id_uniforme: int) -> bool:
        """Supprime un uniforme."""
        query = "DELETE FROM uniforme WHERE id_uniforme = %s"
        self.execute_query(query, (id_uniforme,))
        return True