# app/dao/camera_dao.py

from dao.base_dao import BaseDAO
from models.Camera import Camera
from typing import List, Optional
import json


class CameraDAO(BaseDAO):

    def get_by_id(self, id_camera: int) -> Optional[Camera]:
        query = "SELECT * FROM camera WHERE id_camera = %s"
        result = self.execute_query(query, (id_camera,), fetchone=True)

        if result:
            # Convertir configuration JSON en dict si nécessaire
            if result.get('configuration') and isinstance(result['configuration'], str):
                result['configuration'] = json.loads(result['configuration'])
            return Camera(**result)
        return None

    def get_all(self) -> List[Camera]:
        query = "SELECT * FROM camera ORDER BY nom_camera"
        results = self.execute_query(query, fetchall=True)

        if results:
            for row in results:
                if row.get('configuration') and isinstance(row['configuration'], str):
                    row['configuration'] = json.loads(row['configuration'])
            return [Camera(**row) for row in results]
        return []

    def get_by_zone(self, id_zone: int) -> List[Camera]:
        query = "SELECT * FROM camera WHERE id_zone = %s ORDER BY nom_camera"
        results = self.execute_query(query, (id_zone,), fetchall=True)

        if results:
            for row in results:
                if row.get('configuration') and isinstance(row['configuration'], str):
                    row['configuration'] = json.loads(row['configuration'])
            return [Camera(**row) for row in results]
        return []

    def get_actives(self) -> List[Camera]:
        query = "SELECT * FROM camera WHERE est_active = TRUE ORDER BY nom_camera"
        results = self.execute_query(query, fetchall=True)

        if results:
            for row in results:
                if row.get('configuration') and isinstance(row['configuration'], str):
                    row['configuration'] = json.loads(row['configuration'])
            return [Camera(**row) for row in results]
        return []

    def create(self, camera: Camera) -> int:
        query = """
        INSERT INTO camera (nom_camera, emplacement, flux_url, est_active, 
                           configuration, id_zone, derniere_connexion)
        VALUES (%s, %s, %s, %s, %s, %s, %s)
        """

        # Convertir le dictionnaire en JSON string
        configuration = json.dumps(camera.configuration) if camera.configuration else None

        params = (
            camera.nom_camera,
            camera.emplacement,
            camera.flux_url,
            camera.est_active,
            configuration,
            camera.id_zone,
            camera.derniere_connexion
        )

        # Utiliser return_last_id=True
        last_id = self.execute_query(query, params, return_last_id=True)
        print(f"🟢 Caméra ID généré: {last_id}")

        return last_id if last_id else 0

    def update(self, camera: Camera) -> bool:
        query = """
        UPDATE camera
        SET nom_camera=%s, emplacement=%s, flux_url=%s, est_active=%s,
            configuration=%s, id_zone=%s, derniere_connexion=%s
        WHERE id_camera=%s
        """

        configuration = json.dumps(camera.configuration) if camera.configuration else None

        params = (
            camera.nom_camera,
            camera.emplacement,
            camera.flux_url,
            camera.est_active,
            configuration,
            camera.id_zone,
            camera.derniere_connexion,
            camera.id_camera
        )

        self.execute_query(query, params)
        return True

    def update_connexion(self, id_camera: int):
        """Met à jour la date de dernière connexion."""
        query = "UPDATE camera SET derniere_connexion = NOW() WHERE id_camera = %s"
        self.execute_query(query, (id_camera,))

    def delete(self, id_camera: int) -> bool:
        query = "DELETE FROM camera WHERE id_camera = %s"
        self.execute_query(query, (id_camera,))
        return True