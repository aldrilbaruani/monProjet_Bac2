# dao/check_relations.py

import sys
import os

# Ajouter le chemin racine (le dossier parent du dossier dao)
current_dir = os.path.dirname(os.path.abspath(__file__))  # dao/
project_root = os.path.dirname(current_dir)  # app/ (racine)

if project_root not in sys.path:
    sys.path.insert(0, project_root)

print(f"📁 Fichier actuel: {__file__}")
print(f"📁 Racine du projet (app): {project_root}")

# Imports (sans préfixe surveillance_projet_bac_2)
try:
    from dao.employe_dao import EmployeDAO
    from dao.zone_dao import ZoneDAO
    from dao.camera_dao import CameraDAO
    from utils.database import test_connection

    print("✅ Tous les imports réussis")
except ImportError as e:
    print(f"❌ Erreur d'import: {e}")

    # Debug: afficher le contenu
    print(f"\n📂 Contenu du dossier dao: {os.listdir('.')}")
    print(
        f"\n📂 Contenu du dossier utils: {os.listdir('../utils') if os.path.exists('../utils') else 'utils non trouvé'}")

    sys.exit(1)


def test_relations():
    """Test rapide des relations entre DAO."""
    print("\n🔍 Test des relations entre DAO...")

    # D'abord tester la connexion DB
    if not test_connection():
        print("❌ Arrêt des tests - Problème de connexion DB")
        return

    try:
        # Test 1: Récupérer un employé
        print("\n📊 Test 1: Récupération employé...")
        employe_dao = EmployeDAO()
        employe = employe_dao.get_by_id(1)
        if employe:
            print(f"✅ Employé trouvé: {employe.nom} {employe.prenom}")
        else:
            print("⚠️ Aucun employé avec ID 1 trouvé")

            # Lister tous les employés
            tous = employe_dao.get_all()
            print(f"📊 Total employés dans la base: {len(tous)}")
            for e in tous[:3]:
                print(f"   - ID {e.id_employe}: {e.nom} {e.prenom}")

        # Test 2: Récupérer une zone
        print("\n📊 Test 2: Récupération zone...")
        zone_dao = ZoneDAO()
        zone = zone_dao.get_by_id(1)
        if zone:
            print(f"✅ Zone trouvée: {zone.nom_zone}")
        else:
            print("⚠️ Aucune zone avec ID 1 trouvée")

            # Lister toutes les zones
            toutes = zone_dao.get_all()
            print(f"📊 Total zones dans la base: {len(toutes)}")
            for z in toutes:
                print(f"   - ID {z.id_zone}: {z.nom_zone}")

        # Test 3: Récupérer les caméras d'une zone
        print("\n📊 Test 3: Récupération caméras par zone...")
        if zone:
            camera_dao = CameraDAO()
            cameras = camera_dao.get_by_zone(zone.id_zone)
            if cameras:
                print(f"✅ {len(cameras)} caméras trouvées dans la zone {zone.nom_zone}")
                for cam in cameras:
                    print(f"   - {cam.nom_camera} (actif: {cam.est_active})")
            else:
                print(f"⚠️ Aucune caméra dans la zone {zone.nom_zone}")

    except Exception as e:
        print(f"❌ Erreur lors des tests: {type(e).__name__}: {e}")
        import traceback
        traceback.print_exc()


if __name__ == '__main__':
    test_relations()