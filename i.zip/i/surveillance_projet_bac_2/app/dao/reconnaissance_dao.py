# app/dao/reconnaissance_dao.py

from dao.base_dao import BaseDAO
from models.Reconnaissance import Reconnaissance
from typing import List, Optional
from datetime import datetime
import json


class ReconnaissanceDAO(BaseDAO):

    def get_by_id(self, id_reconnaissance: int) -> Optional[Reconnaissance]:
        query = "SELECT * FROM reconnaissance WHERE id_reconnaissance = %s"
        result = self.execute_query(query, (id_reconnaissance,), fetchone=True)

        if result:
            # Convertir les types si nécessaire
            if result.get('score_confiance') is not None:
                result['score_confiance'] = float(result['score_confiance'])
            return Reconnaissance(**result)
        return None

    def get_by_evenement(self, id_evenement: int) -> Optional[Reconnaissance]:
        query = "SELECT * FROM reconnaissance WHERE id_evenement = %s"
        result = self.execute_query(query, (id_evenement,), fetchone=True)

        if result:
            if result.get('score_confiance') is not None:
                result['score_confiance'] = float(result['score_confiance'])
            return Reconnaissance(**result)
        return None

    def get_by_employe(self, id_employe: int) -> List[Reconnaissance]:
        query = """
        SELECT * FROM reconnaissance 
        WHERE id_employe = %s 
        ORDER BY date_analyse DESC
        """
        results = self.execute_query(query, (id_employe,), fetchall=True)

        if results:
            for row in results:
                if row.get('score_confiance') is not None:
                    row['score_confiance'] = float(row['score_confiance'])
            return [Reconnaissance(**row) for row in results]
        return []

    def get_recentes(self, limite: int = 50) -> List[Reconnaissance]:
        query = """
        SELECT * FROM reconnaissance 
        ORDER BY date_analyse DESC 
        LIMIT %s
        """
        results = self.execute_query(query, (limite,), fetchall=True)

        if results:
            for row in results:
                if row.get('score_confiance') is not None:
                    row['score_confiance'] = float(row['score_confiance'])
            return [Reconnaissance(**row) for row in results]
        return []

    def get_statistiques(self) -> dict:
        query = """
        SELECT 
            COUNT(*) as total,
            AVG(score_confiance) as score_moyen,
            COUNT(DISTINCT id_employe) as employes_identifies,
            SUM(CASE WHEN id_employe IS NULL THEN 1 ELSE 0 END) as inconnus
        FROM reconnaissance
        """
        return self.execute_query(query, fetchone=True) or {}

    def create(self, reconnaissance: Reconnaissance) -> int:
        query = """
        INSERT INTO reconnaissance
        (methode, score_confiance, date_analyse, id_evenement, id_employe, temps_traitement_ms)
        VALUES (%s, %s, %s, %s, %s, %s)
        """

        params = (
            reconnaissance.methode,
            reconnaissance.score_confiance,
            reconnaissance.date_analyse,
            reconnaissance.id_evenement,
            reconnaissance.id_employe,
            reconnaissance.temps_traitement_ms
        )

        # Utiliser return_last_id=True
        last_id = self.execute_query(query, params, return_last_id=True)
        print(f"🟢 Reconnaissance ID généré: {last_id}")

        return last_id if last_id else 0

    def update(self, reconnaissance: Reconnaissance) -> bool:
        query = """
        UPDATE reconnaissance
        SET methode=%s, score_confiance=%s, id_employe=%s, temps_traitement_ms=%s
        WHERE id_reconnaissance=%s
        """

        params = (
            reconnaissance.methode,
            reconnaissance.score_confiance,
            reconnaissance.id_employe,
            reconnaissance.temps_traitement_ms,
            reconnaissance.id_reconnaissance
        )

        self.execute_query(query, params)
        return True

    def delete(self, id_reconnaissance: int) -> bool:
        """Supprime une reconnaissance."""
        query = "DELETE FROM reconnaissance WHERE id_reconnaissance = %s"
        self.execute_query(query, (id_reconnaissance,))
        return True