
from dao.base_dao import BaseDAO
from models.SessionPresence import SessionPresence
from typing import List, Optional
from datetime import datetime, date


class SessionPresenceDAO(BaseDAO):


    def get_by_id(self, id_session: int) -> Optional[SessionPresence]:
        query = "SELECT * FROM session_presence WHERE id_session = %s"
        result = self.execute_query(query, (id_session,), fetchone=True)

        if result:
            return SessionPresence(**result)
        return None

    def get_by_employe(self, id_employe: int) -> List[SessionPresence]:
        query = """
        SELECT * FROM session_presence 
        WHERE id_employe = %s 
        ORDER BY debut DESC
        """
        results = self.execute_query(query, (id_employe,), fetchall=True)

        return [SessionPresence(**row) for row in results] if results else []

    def get_en_cours(self, id_employe: int = None) -> List[SessionPresence]:


        if id_employe:
            query = "SELECT * FROM session_presence WHERE id_employe = %s AND fin IS NULL"
            results = self.execute_query(query, (id_employe,), fetchall=True)
        else:
            query = "SELECT * FROM session_presence WHERE fin IS NULL ORDER BY debut"
            results = self.execute_query(query, fetchall=True)

        return [SessionPresence(**row) for row in results] if results else []

    def get_par_jour(self, date_jour: date) -> List[SessionPresence]:
        query = """
        SELECT * FROM session_presence 
        WHERE DATE(debut) = %s
        ORDER BY debut
        """
        results = self.execute_query(query, (date_jour,), fetchall=True)

        return [SessionPresence(**row) for row in results] if results else []

    # app/dao/session_presence_dao.py - create() modifié

    def create(self, session: SessionPresence) -> int:
        query = """
        INSERT INTO session_presence (debut, fin, id_employe, type_session)
        VALUES (%s, %s, %s, %s)
        """

        params = (
            session.debut,
            session.fin,
            session.id_employe,
            session.type_session
        )

        # Utiliser return_last_id=True
        last_id = self.execute_query(query, params, return_last_id=True)
        print(f"🟢 Session ID généré: {last_id}")

        return last_id if last_id else 0
    def update(self, session: SessionPresence) -> bool:
        query = """
        UPDATE session_presence
        SET debut=%s, fin=%s, type_session=%s
        WHERE id_session=%s
        """

        params = (
            session.debut,
            session.fin,
            session.type_session,
            session.id_session
        )

        self.execute_query(query, params)
        return True

    def terminer(self, id_session: int) -> bool:

        query = "UPDATE session_presence SET fin = NOW() WHERE id_session = %s AND fin IS NULL"
        self.execute_query(query, (id_session,))
        return True

    def delete(self, id_session: int) -> bool:
        query = "DELETE FROM session_presence WHERE id_session = %s"
        self.execute_query(query, (id_session,))
        return True