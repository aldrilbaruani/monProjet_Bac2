from dao.base_dao import BaseDAO
from models.ChatbotInteraction import ChatbotInteraction
from typing import List, Optional


class ChatbotInteractionDAO(BaseDAO):

    def get_by_id(self, id_interaction: int) -> Optional[ChatbotInteraction]:
        query = "SELECT * FROM chatbot_interaction WHERE id_interaction = %s"
        result = self.execute_query(query, (id_interaction,), fetchone=True)

        if result:
            return ChatbotInteraction(**result)
        return None

    def get_by_employe(self, id_employe: int) -> List[ChatbotInteraction]:
        query = """
        SELECT * FROM chatbot_interaction 
        WHERE id_employe = %s 
        ORDER BY date_interaction DESC
        """
        results = self.execute_query(query, (id_employe,), fetchall=True)

        return [ChatbotInteraction(**row) for row in results] if results else []

    def get_recentes(self, limite: int = 50) -> List[ChatbotInteraction]:
        query = """
        SELECT * FROM chatbot_interaction 
        ORDER BY date_interaction DESC 
        LIMIT %s
        """
        results = self.execute_query(query, (limite,), fetchall=True)

        return [ChatbotInteraction(**row) for row in results] if results else []

    def get_par_intention(self, intention: str) -> List[ChatbotInteraction]:
        query = """
        SELECT * FROM chatbot_interaction 
        WHERE intention = %s 
        ORDER BY date_interaction DESC
        """
        results = self.execute_query(query, (intention,), fetchall=True)

        return [ChatbotInteraction(**row) for row in results] if results else []

    def get_avec_deplacement(self) -> List[ChatbotInteraction]:

        query = """
        SELECT * FROM chatbot_interaction 
        WHERE id_deplacement IS NOT NULL 
        ORDER BY date_interaction DESC
        """
        results = self.execute_query(query, fetchall=True)

        return [ChatbotInteraction(**row) for row in results] if results else []

    # app/dao/chatbot_interaction_dao.py - create() modifié

    def create(self, interaction: ChatbotInteraction) -> int:
        query = """
        INSERT INTO chatbot_interaction
        (date_interaction, commande, reponse, id_employe, id_deplacement,
         intention, score_confiance, temps_reponse_ms)
        VALUES (%s, %s, %s, %s, %s, %s, %s, %s)
        """

        params = (
            interaction.date_interaction,
            interaction.commande,
            interaction.reponse,
            interaction.id_employe,
            interaction.id_deplacement,
            interaction.intention,
            interaction.score_confiance,
            interaction.temps_reponse_ms
        )

        # Utiliser return_last_id=True
        last_id = self.execute_query(query, params, return_last_id=True)
        print(f"🟢 Interaction ID généré: {last_id}")

        return last_id if last_id else 0

    def update(self, interaction: ChatbotInteraction) -> bool:
        query = """
        UPDATE chatbot_interaction
        SET reponse=%s, id_deplacement=%s, intention=%s, score_confiance=%s, temps_reponse_ms=%s
        WHERE id_interaction=%s
        """

        params = (
            interaction.reponse,
            interaction.id_deplacement,
            interaction.intention,
            interaction.score_confiance,
            interaction.temps_reponse_ms,
            interaction.id_interaction
        )

        self.execute_query(query, params)
        return True

    # app/dao/chatbot_interaction_dao.py - ajouter cette méthode

    def delete(self, id_interaction: int) -> bool:
        """Supprime une interaction."""
        query = "DELETE FROM chatbot_interaction WHERE id_interaction = %s"
        self.execute_query(query, (id_interaction,))
        return True