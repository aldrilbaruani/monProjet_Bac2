# app/dao/base_dao.py

from utils.database import get_connection
import traceback


class BaseDAO:

    def execute_query(self, query, params=None, fetchone=False, fetchall=False, return_last_id=False):
        """
        Exécute une requête SQL et retourne le résultat.
        """
        connection = get_connection()

        if connection is None:
            raise Exception("Connexion impossible à la base de données!")

        cursor = connection.cursor(dictionary=True)

        try:
            print(f"🔍 SQL: {query[:200]}...")
            print(f"🔍 PARAMS: {params}")
            cursor.execute(query, params or ())
        except Exception as e:
            print(f"❌ ERREUR SQL: {e}")
            traceback.print_exc()
            connection.rollback()
            cursor.close()
            connection.close()
            raise

        result = None
        last_id = None

        if fetchone:
            result = cursor.fetchone()

        if fetchall:
            result = cursor.fetchall()

        if return_last_id:
            last_id = cursor.lastrowid

        connection.commit()

        cursor.close()
        connection.close()

        if return_last_id:
            return last_id
        return result

    def execute_many(self, query, params_list):
        """Exécute une requête multiple."""
        connection = get_connection()

        if connection is None:
            raise Exception("Connexion impossible à la base de données!")

        cursor = connection.cursor(dictionary=True)

        try:
            cursor.executemany(query, params_list)
        except Exception as e:
            print(f"❌ ERREUR SQL: {e}")
            connection.rollback()
            cursor.close()
            connection.close()
            raise

        connection.commit()

        cursor.close()
        connection.close()