# app/dao/notification_dao.py

from dao.base_dao import BaseDAO
from models.Notification import Notification
from typing import List, Optional
from datetime import datetime


class NotificationDAO(BaseDAO):

    def get_by_id(self, id_notification: int) -> Optional[Notification]:
        query = "SELECT * FROM notification WHERE id_notification = %s"
        result = self.execute_query(query, (id_notification,), fetchone=True)

        if result:
            # Convertir les champs JSON si nécessaire
            if result.get('erreur') and isinstance(result['erreur'], dict):
                result['erreur'] = str(result['erreur'])
            return Notification(**result)
        return None

    def get_by_alerte(self, id_alerte: int) -> List[Notification]:
        query = "SELECT * FROM notification WHERE id_alerte = %s ORDER BY date_envoi"
        results = self.execute_query(query, (id_alerte,), fetchall=True)
        return [Notification(**row) for row in results] if results else []

    def get_non_lues(self, destinataire: str = None) -> List[Notification]:
        if destinataire:
            query = "SELECT * FROM notification WHERE destinataire = %s AND statut_envoi = 'envoye'"
            results = self.execute_query(query, (destinataire,), fetchall=True)
        else:
            query = "SELECT * FROM notification WHERE statut_envoi = 'envoye'"
            results = self.execute_query(query, fetchall=True)
        return [Notification(**row) for row in results] if results else []

    def get_par_statut(self, statut: str) -> List[Notification]:
        query = "SELECT * FROM notification WHERE statut_envoi = %s ORDER BY date_envoi"
        results = self.execute_query(query, (statut,), fetchall=True)
        return [Notification(**row) for row in results] if results else []

    def create(self, notification: Notification) -> int:
        query = """
        INSERT INTO notification
        (canal, destinataire, contenu, date_envoi, statut_envoi, id_alerte,
         date_lecture, tentative, erreur)
        VALUES (%s, %s, %s, %s, %s, %s, %s, %s, %s)
        """

        params = (
            notification.canal,
            notification.destinataire,
            notification.contenu,
            notification.date_envoi,
            notification.statut_envoi,
            notification.id_alerte,
            notification.date_lecture,
            notification.tentative,
            notification.erreur
        )

        # Utiliser return_last_id=True
        last_id = self.execute_query(query, params, return_last_id=True)
        print(f"🟢 Notification ID généré: {last_id}")

        return last_id if last_id else 0

    def update_statut(self, id_notification: int, statut: str, date_lecture: datetime = None) -> bool:
        query = "UPDATE notification SET statut_envoi = %s"
        params = [statut]

        if date_lecture or statut == 'lu':
            query += ", date_lecture = %s"
            params.append(date_lecture or datetime.now())

        query += " WHERE id_notification = %s"
        params.append(id_notification)

        self.execute_query(query, tuple(params))
        return True

    def increment_tentative(self, id_notification: int) -> bool:
        query = "UPDATE notification SET tentative = tentative + 1 WHERE id_notification = %s"
        self.execute_query(query, (id_notification,))
        return True

    def marquer_erreur(self, id_notification: int, erreur: str) -> bool:
        query = "UPDATE notification SET statut_envoi = 'echec', erreur = %s WHERE id_notification = %s"
        self.execute_query(query, (erreur, id_notification))
        return True

    def delete(self, id_notification: int) -> bool:
        """Supprime une notification."""
        query = "DELETE FROM notification WHERE id_notification = %s"
        self.execute_query(query, (id_notification,))
        return True