# app/dao/evenement_dao.py

from dao.base_dao import BaseDAO
from models.Evenement import Evenement
from typing import List, Optional
from datetime import datetime, date
import json


class EvenementDAO(BaseDAO):

    def _convert_row(self, row: dict) -> dict:
        """Convertit les types pour correspondre au modèle Evenement."""
        if not row:
            return row

        # Convertir metadata JSON en dict
        if row.get('metadata') and isinstance(row['metadata'], str):
            row['metadata'] = json.loads(row['metadata'])

        # Convertir confiance (decimal en float)
        if row.get('confiance') is not None:
            row['confiance'] = float(row['confiance'])

        return row

    def get_by_id(self, id_evenement: int) -> Optional[Evenement]:
        query = "SELECT * FROM evenement WHERE id_evenement = %s"
        result = self.execute_query(query, (id_evenement,), fetchone=True)

        if result:
            result = self._convert_row(result)
            return Evenement(**result)
        return None

    def get_recents(self, limite: int = 100) -> List[Evenement]:
        query = """
        SELECT * FROM evenement
        ORDER BY date_heure DESC
        LIMIT %s
        """
        results = self.execute_query(query, (limite,), fetchall=True)

        if results:
            results = [self._convert_row(row) for row in results]
            return [Evenement(**row) for row in results]
        return []

    def get_by_camera(self, id_camera: int, limite: int = 100) -> List[Evenement]:
        query = """
        SELECT * FROM evenement
        WHERE id_camera = %s
        ORDER BY date_heure DESC
        LIMIT %s
        """
        results = self.execute_query(query, (id_camera, limite), fetchall=True)

        if results:
            results = [self._convert_row(row) for row in results]
            return [Evenement(**row) for row in results]
        return []

    def get_by_type(self, type_evenement: str, limite: int = 100) -> List[Evenement]:
        query = """
        SELECT * FROM evenement
        WHERE type_evenement = %s
        ORDER BY date_heure DESC
        LIMIT %s
        """
        results = self.execute_query(query, (type_evenement, limite), fetchall=True)

        if results:
            results = [self._convert_row(row) for row in results]
            return [Evenement(**row) for row in results]
        return []

    def get_par_periode(self, debut: datetime, fin: datetime) -> List[Evenement]:
        query = """
        SELECT * FROM evenement
        WHERE date_heure BETWEEN %s AND %s
        ORDER BY date_heure DESC
        """
        results = self.execute_query(query, (debut, fin), fetchall=True)

        if results:
            results = [self._convert_row(row) for row in results]
            return [Evenement(**row) for row in results]
        return []

    def get_statistiques_journalieres(self, date_jour: date) -> dict:
        query = """
        SELECT
            COUNT(*) as total,
            AVG(confiance) as confiance_moyenne,
            COUNT(DISTINCT id_camera) as cameras_actives
        FROM evenement
        WHERE DATE(date_heure) = %s
        """
        result = self.execute_query(query, (date_jour,), fetchone=True)
        return result or {}

    def create(self, evenement: Evenement) -> int:
        query = """
        INSERT INTO evenement
        (date_heure, type_evenement, confiance, metadata, id_camera, id_session)
        VALUES (%s, %s, %s, %s, %s, %s)
        """

        metadata = json.dumps(evenement.metadata) if evenement.metadata else "{}"

        params = (
            evenement.date_heure,
            evenement.type_evenement,
            evenement.confiance,
            metadata,
            evenement.id_camera,
            evenement.id_session
        )

        # Utiliser return_last_id=True
        last_id = self.execute_query(query, params, return_last_id=True)
        print(f"🟢 Événement ID généré: {last_id}")

        return last_id if last_id else 0

    def create_many(self, evenements: List[Evenement]) -> int:
        query = """
        INSERT INTO evenement
        (date_heure, type_evenement, confiance, metadata, id_camera, id_session)
        VALUES (%s, %s, %s, %s, %s, %s)
        """

        params_list = []
        for evt in evenements:
            metadata = json.dumps(evt.metadata) if evt.metadata else "{}"
            params_list.append((
                evt.date_heure,
                evt.type_evenement,
                evt.confiance,
                metadata,
                evt.id_camera,
                evt.id_session
            ))

        self.execute_many(query, params_list)

        result = self.execute_query("SELECT LAST_INSERT_ID() as id", fetchone=True)
        return result['id'] if result else 0

    def delete(self, id_evenement: int) -> bool:
        query = "DELETE FROM evenement WHERE id_evenement = %s"
        self.execute_query(query, (id_evenement,))
        return True