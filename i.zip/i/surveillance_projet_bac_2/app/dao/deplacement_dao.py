from dao.base_dao import BaseDAO
from models.DeplacementSigne import DeplacementSigne
from typing import List, Optional
from datetime import datetime


class DeplacementDAO(BaseDAO):


    def get_by_id(self, id_deplacement: int) -> Optional[DeplacementSigne]:
        query = "SELECT * FROM deplacement_signe WHERE id_deplacement = %s"
        result = self.execute_query(query, (id_deplacement,), fetchone=True)

        if result:
            return DeplacementSigne(**result)
        return None

    def get_by_employe(self, id_employe: int) -> List[DeplacementSigne]:
        query = """
        SELECT * FROM deplacement_signe 
        WHERE id_employe = %s 
        ORDER BY date_depart DESC
        """
        results = self.execute_query(query, (id_employe,), fetchall=True)

        return [DeplacementSigne(**row) for row in results] if results else []

    def get_en_cours(self) -> List[DeplacementSigne]:
        query = """
        SELECT * FROM deplacement_signe 
        WHERE statut = 'en_cours' 
        ORDER BY date_retour_prevue
        """
        results = self.execute_query(query, fetchall=True)

        return [DeplacementSigne(**row) for row in results] if results else []

    def get_en_retard(self) -> List[DeplacementSigne]:
        query = """
        SELECT * FROM deplacement_signe 
        WHERE statut = 'en_cours' AND date_retour_prevue < NOW()
        ORDER BY date_retour_prevue
        """
        results = self.execute_query(query, fetchall=True)

        return [DeplacementSigne(**row) for row in results] if results else []

    def get_par_periode(self, debut: datetime, fin: datetime) -> List[DeplacementSigne]:
        query = """
        SELECT * FROM deplacement_signe 
        WHERE date_depart BETWEEN %s AND %s
        ORDER BY date_depart DESC
        """
        results = self.execute_query(query, (debut, fin), fetchall=True)

        return [DeplacementSigne(**row) for row in results] if results else []

    # app/dao/deplacement_dao.py - ajouter cette méthode

    def get_by_zone(self, id_zone: int) -> List[DeplacementSigne]:
        """
        Récupère tous les déplacements vers une zone de destination spécifique.
        """
        query = """
        SELECT * FROM deplacement_signe 
        WHERE id_zone_destination = %s 
        ORDER BY date_depart DESC
        """
        results = self.execute_query(query, (id_zone,), fetchall=True)
        return [DeplacementSigne(**row) for row in results] if results else []

    # app/dao/deplacement_dao.py - create() modifié

    def create(self, deplacement: DeplacementSigne) -> int:
        query = """
        INSERT INTO deplacement_signe
        (date_depart, date_retour_prevue, date_retour_reel, motif,
         date_signalement, statut, id_employe, id_zone_destination, notes)
        VALUES (%s, %s, %s, %s, %s, %s, %s, %s, %s)
        """

        params = (
            deplacement.date_depart,
            deplacement.date_retour_prevue,
            deplacement.date_retour_reel,
            deplacement.motif,
            deplacement.date_signalement,
            deplacement.statut,
            deplacement.id_employe,
            deplacement.id_zone_destination,
            deplacement.notes
        )

        # Utiliser return_last_id=True
        last_id = self.execute_query(query, params, return_last_id=True)
        print(f"🟢 Déplacement ID généré: {last_id}")

        return last_id if last_id else 0
    def update(self, deplacement: DeplacementSigne) -> bool:
        query = """
        UPDATE deplacement_signe
        SET date_depart=%s, date_retour_prevue=%s, date_retour_reel=%s,
            motif=%s, statut=%s, id_zone_destination=%s, notes=%s
        WHERE id_deplacement=%s
        """

        params = (
            deplacement.date_depart,
            deplacement.date_retour_prevue,
            deplacement.date_retour_reel,
            deplacement.motif,
            deplacement.statut,
            deplacement.id_zone_destination,
            deplacement.notes,
            deplacement.id_deplacement
        )

        self.execute_query(query, params)
        return True

    def update_statut(self, id_deplacement: int, statut: str) -> bool:
        query = "UPDATE deplacement_signe SET statut = %s WHERE id_deplacement = %s"
        self.execute_query(query, (statut, id_deplacement))
        return True

    def terminer(self, id_deplacement: int, date_retour_reel: datetime = None) -> bool:

        if date_retour_reel is None:
            date_retour_reel = datetime.now()

        query = """
        UPDATE deplacement_signe 
        SET statut = 'termine', date_retour_reel = %s 
        WHERE id_deplacement = %s
        """
        self.execute_query(query, (date_retour_reel, id_deplacement))
        return True

    def delete(self, id_deplacement: int) -> bool:
        query = "DELETE FROM deplacement_signe WHERE id_deplacement = %s"
        self.execute_query(query, (id_deplacement,))
        return True