# app/controllers/notification_controller.py

from flask import Blueprint, request
from controllers.base_controller import BaseController, handle_errors
from services.notification_service import NotificationService

notification_bp = Blueprint('notifications', __name__, url_prefix='/api/notifications')
notification_service = NotificationService()


@notification_bp.route('/', methods=['GET'])
@handle_errors
def get_all_notifications():
    """
    Récupère les notifications avec filtres.

    Query Parameters:
        statut: str - Filtrer par statut (envoye, echec, lu, ignore)
        destinataire: str - Filtrer par destinataire
        limite: int - Nombre maximum de résultats (défaut: 100)
    """
    statut = request.args.get('statut')
    destinataire = request.args.get('destinataire')
    limite = BaseController.get_int_param('limite', 100)

    if destinataire:
        notifications = notification_service.notification_dao.get_non_lues(destinataire)
    elif statut:
        notifications = notification_service.notification_dao.get_par_statut(statut)
    else:
        # Par défaut, récupérer les notifications récentes
        from services.notification_service import NotificationService
        service = NotificationService()
        notifications = service.notification_dao.get_par_statut('envoye')

    notifications = notifications[:limite]

    return BaseController.success([n.to_dict() for n in notifications])


@notification_bp.route('/<int:id_notification>', methods=['GET'])
@handle_errors
def get_notification(id_notification: int):
    """
    Récupère une notification par son ID.

    Path Parameters:
        id_notification: int - ID de la notification
    """
    notification = notification_service.get_notification_by_id(id_notification)
    return BaseController.success(notification.to_dict())


@notification_bp.route('/', methods=['POST'])
@handle_errors
def create_notification():
    """
    Crée une nouvelle notification.

    Request Body:
        canal: str (SMS, EMAIL, PUSH, TELEGRAM)
        destinataire: str
        contenu: str
        id_alerte: int
    """
    data = BaseController.get_json_or_400()
    notification = notification_service.create_notification(data)
    return BaseController.success(notification.to_dict(), "Notification créée", 201)


@notification_bp.route('/<int:id_notification>/lire', methods=['POST'])
@handle_errors
def marquer_comme_lue(id_notification: int):
    """
    Marque une notification comme lue.

    Path Parameters:
        id_notification: int - ID de la notification
    """
    notification = notification_service.marquer_comme_lue(id_notification)
    return BaseController.success(notification.to_dict(), "Notification marquée comme lue")


@notification_bp.route('/<int:id_notification>/envoyer', methods=['POST'])
@handle_errors
def envoyer_notification(id_notification: int):
    """
    Envoie une notification immédiatement.

    Path Parameters:
        id_notification: int - ID de la notification
    """
    success = notification_service.envoyer_maintenant(id_notification)

    if success:
        return BaseController.success(None, "Notification envoyée")
    else:
        return BaseController.error("Échec de l'envoi", 500)


@notification_bp.route('/non-lues', methods=['GET'])
@handle_errors
def get_notifications_non_lues():
    """
    Récupère les notifications non lues.

    Query Parameters:
        destinataire: str - Filtrer par destinataire
    """
    destinataire = request.args.get('destinataire')
    notifications = notification_service.get_notifications_non_lues(destinataire)
    return BaseController.success([n.to_dict() for n in notifications])


@notification_bp.route('/alerte/<int:id_alerte>', methods=['GET'])
@handle_errors
def get_notifications_par_alerte(id_alerte: int):
    """
    Récupère les notifications d'une alerte.

    Path Parameters:
        id_alerte: int - ID de l'alerte
    """
    notifications = notification_service.get_notifications_par_alerte(id_alerte)
    return BaseController.success([n.to_dict() for n in notifications])


@notification_bp.route('/stats', methods=['GET'])
@handle_errors
def get_notification_stats():
    """
    Statistiques sur les notifications.
    """
    stats = notification_service.get_statistiques()
    return BaseController.success(stats)