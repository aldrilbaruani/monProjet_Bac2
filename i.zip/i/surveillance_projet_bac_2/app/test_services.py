# test_services.py

import sys
import os
import random
from datetime import datetime, date, timedelta

# Ajouter le chemin du projet
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))

# Imports des services
from app.services.employe_service import EmployeService
from app.services.zone_service import ZoneService
from app.services.camera_service import CameraService
from app.services.deplacement_service import DeplacementService
from app.services.alerte_service import AlerteService
from app.services.auth_service import AuthService
from app.services.evenement_service import EvenementService
from app.services.reconnaissance_service import ReconnaissanceService
from app.services.notification_service import NotificationService
from app.services.session_presence_service import SessionPresenceService
from app.services.chatbot_service import ChatbotService
from app.services.uniforme_service import UniformeService
from app.services.visage_service import VisageService
from app.services.analyse_comportementale_service import AnalyseComportementaleService

# Imports des modèles pour les tests
from app.models.Employe import Employe
from app.models.Zone import Zone
from app.models.Camera import Camera
from app.models.DeplacementSigne import DeplacementSigne
from app.models.Alerte import Alerte
from app.models.Evenement import Evenement
from app.models.Reconnaissance import Reconnaissance
from app.models.Notification import Notification
from app.models.SessionPresence import SessionPresence
from app.models.ChatbotInteraction import ChatbotInteraction
from app.models.Uniforme import Uniforme
from app.models.Visage import Visage


# Dans test_services.py - test_employe_service() modifié

# test_services.py - test_employe_service() corrigé

# test_services.py - test_employe_service() corrigé (fin)

def test_employe_service():
    print("\n" + "=" * 60)
    print("📌 TEST EmployeService")
    print("=" * 60)

    service = EmployeService()

    # 1. Compter les employés existants
    tous = service.get_all_employes()
    print(f"   📊 Employés existants: {len(tous)}")

    # 2. Créer un employé
    email = f"test_service_{random.randint(1, 10000)}@test.com"
    nom_original = "ServiceTest"
    employe_data = {
        "nom": nom_original,
        "prenom": "Employe",
        "poste": "Testeur",
        "email": email,
        "date_embauche": datetime.now().isoformat(),
        "telephone": "0123456789",
        "role": "employe",
        "mot_de_passe": "Test123!"
    }
    employe = service.create_employe(employe_data)
    print(f"   ✅ Employé créé: {employe.nom_complet} (ID: {employe.id_employe})")

    # 3. Récupérer par ID
    emp = service.get_employe_by_id(employe.id_employe)
    assert emp is not None
    assert emp.email == email
    print("   ✅ Récupération par ID OK")

    # 4. Récupérer par email
    emp2 = service.get_employe_by_email(email)
    assert emp2 is not None
    print("   ✅ Récupération par email OK")

    # 5. Rechercher AVANT mise à jour
    recherche_avant = service.search_employes(nom_original)
    print(f"   🔍 Recherche avant mise à jour: {len(recherche_avant)} trouvé(s)")
    assert len(recherche_avant) >= 1
    print("   ✅ Recherche avant mise à jour OK")

    # 6. Mettre à jour
    nouveau_nom = "UpdatedName"
    updated = service.update_employe(employe.id_employe, {"nom": nouveau_nom})
    assert updated.nom == nouveau_nom
    print("   ✅ Mise à jour OK")

    # 7. Rechercher APRÈS mise à jour avec le nouveau nom
    recherche_apres = service.search_employes(nouveau_nom)
    print(f"   🔍 Recherche après mise à jour: {len(recherche_apres)} trouvé(s)")
    assert len(recherche_apres) >= 1
    print("   ✅ Recherche après mise à jour OK")

    # 8. Récupérer tous les employés par rôle
    employes_role = service.get_employes_by_role("employe")
    print(f"   📊 Employés avec rôle 'employe': {len(employes_role)}")

    # 9. Statistiques
    stats = service.get_statistiques()
    print(f"   📊 Statistiques: {stats['actifs']} actifs / {stats['total']} total")

    # 10. Soft delete
    result = service.delete_employe(employe.id_employe, soft_delete=True)
    assert result["success"] == True
    emp_disabled = service.get_employe_by_id(employe.id_employe)
    assert emp_disabled.actif == False
    print("   ✅ Soft delete OK")

    # 11. Suppression définitive
    service.delete_employe(employe.id_employe, soft_delete=False)

    # 12. Vérifier que l'employé n'existe plus
    try:
        emp_deleted = service.get_employe_by_id(employe.id_employe)
        print("   ❌ L'employé existe encore après suppression")
        assert False
    except ValueError as e:
        # C'est normal - l'employé n'existe plus
        print(f"   ✅ Suppression définitive OK (employé introuvable)")

def test_zone_service():
    print("\n" + "=" * 60)
    print("📌 TEST ZoneService")
    print("=" * 60)

    service = ZoneService()

    # 1. Créer une zone
    zone_data = {
        "nom_zone": "Zone Test Service",
        "type_zone": "publique",
        "description": "Zone de test",
        "niveau_acces": 2
    }
    zone = service.create_zone(zone_data)
    print(f"   ✅ Zone créée: {zone.nom_zone} (ID: {zone.id_zone})")

    # 2. Récupérer par ID
    zone2 = service.get_zone_by_id(zone.id_zone)
    assert zone2 is not None
    print("   ✅ Récupération par ID OK")

    # 3. Récupérer toutes les zones
    toutes = service.get_all_zones()
    print(f"   📊 Total zones: {len(toutes)}")

    # 4. Récupérer par type
    zones_publiques = service.get_zones_by_type("publique")
    print(f"   📊 Zones publiques: {len(zones_publiques)}")

    # 5. Mettre à jour
    zone_updated = service.update_zone(zone.id_zone, {"description": "Description modifiée"})
    assert zone_updated.description == "Description modifiée"
    print("   ✅ Mise à jour OK")

    # 6. Vérifier accès (simulation)
    # Créer un employé pour tester l'accès
    employe_service = EmployeService()
    emp = employe_service.create_employe({
        "nom": "AccesTest",
        "prenom": "User",
        "poste": "Test",
        "email": f"acces_{random.randint(1,10000)}@test.com",
        "date_embauche": datetime.now().isoformat(),
        "role": "employe"
    })
    acces = service.verifier_acces(emp.id_employe, zone.id_zone)
    print(f"   ✅ Vérification accès: {acces}")

    # 7. Supprimer
    service.delete_zone(zone.id_zone)
    employe_service.delete_employe(emp.id_employe, soft_delete=False)
    print("   ✅ Zone supprimée")


def test_camera_service():
    print("\n" + "=" * 60)
    print("📌 TEST CameraService")
    print("=" * 60)

    zone_service = ZoneService()
    service = CameraService()

    # Créer une zone
    zone = zone_service.create_zone({
        "nom_zone": "Zone Cam Test",
        "type_zone": "publique"
    })

    # 1. Créer une caméra
    camera_data = {
        "nom_camera": "Cam Test Service",
        "emplacement": "Salle Serveurs",
        "flux_url": "rtsp://192.168.1.100:554/stream",
        "id_zone": zone.id_zone
    }
    camera = service.create_camera(camera_data)
    print(f"   ✅ Caméra créée: {camera.nom_camera} (ID: {camera.id_camera})")

    # 2. Récupérer par ID
    cam = service.get_camera_by_id(camera.id_camera)
    assert cam is not None
    print("   ✅ Récupération par ID OK")

    # 3. Récupérer toutes les caméras
    toutes = service.get_all_cameras()
    print(f"   📊 Total caméras: {len(toutes)}")

    # 4. Récupérer caméras actives
    actives = service.get_all_cameras(actives_only=True)
    print(f"   📊 Caméras actives: {len(actives)}")

    # 5. Récupérer par zone
    cam_zone = service.get_cameras_by_zone(zone.id_zone)
    print(f"   📊 Caméras dans la zone: {len(cam_zone)}")

    # 6. Désactiver
    service.desactiver_camera(camera.id_camera)
    cam_desact = service.get_camera_by_id(camera.id_camera)
    assert cam_desact.est_active == False
    print("   ✅ Désactivation OK")

    # 7. Réactiver
    service.activer_camera(camera.id_camera)
    cam_act = service.get_camera_by_id(camera.id_camera)
    assert cam_act.est_active == True
    print("   ✅ Réactivation OK")

    # 8. Mettre à jour la connexion
    service.update_connexion(camera.id_camera)
    cam_conn = service.get_camera_by_id(camera.id_camera)
    assert cam_conn.derniere_connexion is not None
    print("   ✅ Mise à jour connexion OK")

    # 9. Statistiques
    stats = service.get_statistiques()
    print(f"   📊 Statistiques: {stats['actives']} actives / {stats['total']} total")

    # 10. Supprimer
    service.delete_camera(camera.id_camera)
    zone_service.delete_zone(zone.id_zone)
    print("   ✅ Caméra et zone supprimées")


def test_deplacement_service():
    print("\n" + "=" * 60)
    print("📌 TEST DeplacementService")
    print("=" * 60)

    employe_service = EmployeService()
    zone_service = ZoneService()
    service = DeplacementService()

    # Créer un employé
    emp = employe_service.create_employe({
        "nom": "DeplacementTest",
        "prenom": "User",
        "poste": "Testeur",
        "email": f"deplacement_{random.randint(1,10000)}@test.com",
        "date_embauche": datetime.now().isoformat()
    })

    # Créer une zone
    zone = zone_service.create_zone({
        "nom_zone": "Zone Destination",
        "type_zone": "publique"
    })

    # 1. Créer un déplacement
    deplacement_data = {
        "id_employe": emp.id_employe,
        "id_zone_destination": zone.id_zone,
        "motif": "Test de déplacement",
        "date_depart": datetime.now().isoformat(),
        "date_retour_prevue": (datetime.now() + timedelta(hours=2)).isoformat()
    }
    deplacement = service.create_deplacement(deplacement_data)
    print(f"   ✅ Déplacement créé: ID {deplacement.id_deplacement}")

    # 2. Récupérer par ID
    dep = service.get_deplacement_by_id(deplacement.id_deplacement)
    assert dep is not None
    print("   ✅ Récupération par ID OK")

    # 3. Récupérer déplacements d'un employé
    deps_emp = service.get_deplacements_employe(emp.id_employe)
    print(f"   📊 Déplacements de l'employé: {len(deps_emp)}")

    # 4. Récupérer déplacements en cours
    en_cours = service.get_deplacements_en_cours()
    print(f"   📊 Déplacements en cours: {len(en_cours)}")

    # 5. Vérifier les retards (simulation)
    retards = service.verifier_retards()
    print(f"   📊 Retards détectés: {len(retards)}")

    # 6. Terminer le déplacement
    dep_termine = service.terminer_deplacement(deplacement.id_deplacement)
    assert dep_termine.statut == "termine"
    print("   ✅ Déplacement terminé")

    # 7. Annuler un déplacement
    deplacement2 = service.create_deplacement({
        "id_employe": emp.id_employe,
        "id_zone_destination": zone.id_zone,
        "motif": "Test annulation",
        "date_depart": datetime.now().isoformat(),
        "date_retour_prevue": (datetime.now() + timedelta(hours=1)).isoformat()
    })
    service.annuler_deplacement(deplacement2.id_deplacement, "Test annulation")
    dep_annule = service.get_deplacement_by_id(deplacement2.id_deplacement)
    assert dep_annule.statut == "annule"
    print("   ✅ Déplacement annulé")

    # 8. Statistiques
    stats = service.get_statistiques()
    print(f"   📊 Statistiques: {stats['total_en_cours']} en cours / {stats['total_en_retard']} en retard")

    # 9. Nettoyage
    service.deplacement_dao.delete(deplacement.id_deplacement)
    service.deplacement_dao.delete(deplacement2.id_deplacement)
    employe_service.delete_employe(emp.id_employe, soft_delete=False)
    zone_service.delete_zone(zone.id_zone)
    print("   ✅ Nettoyage OK")


def test_alerte_service():
    print("\n" + "=" * 60)
    print("📌 TEST AlerteService")
    print("=" * 60)

    service = AlerteService()

    # 1. Créer une alerte
    alerte_data = {
        "type_alerte": "intrusion",
        "message": "Test d'alerte - Intrusion détectée",
        "niveau_urgence": 4
    }
    alerte = service.create_alerte(alerte_data)
    print(f"   ✅ Alerte créée: ID {alerte.id_alerte}")

    # 2. Récupérer par ID
    al = service.get_alerte_by_id(alerte.id_alerte)
    assert al is not None
    print("   ✅ Récupération par ID OK")

    # 3. Récupérer alertes non traitées
    non_traitees = service.get_alertes_non_traitees()
    print(f"   📊 Alertes non traitées: {len(non_traitees)}")

    # 4. Récupérer alertes critiques
    critiques = service.get_alertes_critiques()
    print(f"   📊 Alertes critiques: {len(critiques)}")

    # 5. Traiter l'alerte
    al_traitee = service.traiter_alerte(alerte.id_alerte, utilisateur_id=1)
    assert al_traitee.statut == "traitee"
    print("   ✅ Alerte traitée")

    # 6. Créer une autre alerte pour ignorer
    alerte2 = service.create_alerte({
        "type_alerte": "retard",
        "message": "Test d'alerte - Retard",
        "niveau_urgence": 2
    })
    al_ignoree = service.ignorer_alerte(alerte2.id_alerte, utilisateur_id=1)
    assert al_ignoree.statut == "ignoree"
    print("   ✅ Alerte ignorée")

    # 7. Notifier une alerte
    notifications = service.notifier_alerte(alerte.id_alerte)
    print(f"   📊 Notifications envoyées: {len(notifications)}")

    # 8. Statistiques
    stats = service.get_statistiques()
    print(f"   📊 Statistiques: {stats['non_traitees']} non traitées / {stats['critiques']} critiques")

    # 9. Nettoyage
    service.alerte_dao.delete(alerte.id_alerte)
    service.alerte_dao.delete(alerte2.id_alerte)
    print("   ✅ Nettoyage OK")


def test_auth_service():
    print("\n" + "=" * 60)
    print("📌 TEST AuthService")
    print("=" * 60)

    service = AuthService()
    employe_service = EmployeService()

    # 1. Créer un employé via auth
    email = f"auth_{random.randint(1, 10000)}@test.com"
    employe_data = {
        "nom": "AuthTest",
        "prenom": "User",
        "poste": "Testeur",
        "email": email,
        "date_embauche": datetime.now().isoformat()
    }
    employe = service.register(employe_data, "Test123!")
    print(f"   ✅ Employé créé via auth: {employe.email}")

    # 2. Tester authentification avec mot de passe correct
    auth_result = service.authenticate(employe.email, "Test123!")
    assert auth_result is not None
    assert "token" in auth_result
    print("   ✅ Authentification OK")

    # 3. Tester authentification avec mot de passe incorrect
    auth_fail = service.authenticate(employe.email, "wrongpassword")
    assert auth_fail is None
    print("   ✅ Échec attendu pour mauvais mot de passe")

    # 4. Tester changement de mot de passe
    change = service.change_password(employe.id_employe, "Test123!", "NewPass456!")
    assert change == True
    print("   ✅ Changement mot de passe OK")

    # 5. Vérifier nouveau mot de passe
    auth_new = service.authenticate(employe.email, "NewPass456!")
    assert auth_new is not None
    print("   ✅ Nouveau mot de passe fonctionne")

    # 6. Tester réinitialisation (admin seulement - simulé)
    reset = service.reset_password(employe.id_employe, "ResetPass789!")
    assert reset == True
    print("   ✅ Réinitialisation OK")

    # 7. Nettoyage
    employe_service.delete_employe(employe.id_employe, soft_delete=False)
    print("   ✅ Nettoyage OK")

# test_services.py - test_session_presence_service() corrigée

def test_session_presence_service():
    print("\n" + "=" * 60)
    print("📌 TEST SessionPresenceService")
    print("=" * 60)
    employe_service = EmployeService()
    service = SessionPresenceService()

    # Créer un employé
    email = f"presence_{random.randint(1, 10000)}@test.com"
    emp = employe_service.create_employe({
        "nom": "PresenceTest",
        "prenom": "User",
        "poste": "Testeur",
        "email": email,
        "date_embauche": datetime.now().isoformat(),
        "mot_de_passe": "Test123!"
    })
    print(f" 📍 Employé créé: {emp.id_employe}")

    # 1. Démarrer une session
    session = service.demarrer_session(emp.id_employe)
    print(f" ✅ Session démarrée: ID {session.id_session}")

    # 2. Récupérer session en cours
    en_cours = service.get_session_en_cours(emp.id_employe)
    assert en_cours is not None
    assert en_cours.est_active == True
    print(" ✅ Session en cours récupérée")

    # 3. Récupérer toutes les sessions d'un employé
    sessions = service.get_sessions_employe(emp.id_employe)
    print(f" 📊 Sessions de l'employé: {len(sessions)}")

    # 4. Terminer la session
    session_terminee = service.terminer_session(id_session=session.id_session)
    assert session_terminee.est_active == False
    print(" ✅ Session terminée")

    # 5. Démarrer une autre session et terminer par employé
    session2 = service.demarrer_session(emp.id_employe)
    service.terminer_session(id_employe=emp.id_employe)
    session2_fin = service.get_session_by_id(session2.id_session)
    assert session2_fin.fin is not None
    print(" ✅ Terminaison par employé OK")

    # 6. Statistiques
    stats = service.get_statistiques_presence(emp.id_employe)
    print(f" 📊 Statistiques: {stats['total_sessions']} sessions, {stats['total_heures']} heures")

    # 7. ✅ Nettoyage CORRIGÉ : Supprimer les sessions AVANT l'employé
    for s in service.get_sessions_employe(emp.id_employe):
        service.session_dao.delete(s.id_session)
        print(f" 🗑️ Session {s.id_session} supprimée")

    # Maintenant l'employé n'a plus de sessions, on peut le supprimer
    employe_service.delete_employe(emp.id_employe, soft_delete=False)
    print(" ✅ Nettoyage OK")


# test_services.py - test_evenement_service() corrigée

def test_evenement_service():
    print("\n" + "=" * 60)
    print("📌 TEST EvenementService")
    print("=" * 60)
    zone_service = ZoneService()
    camera_service = CameraService()
    service = EvenementService()

    # Créer une zone et une caméra
    zone = zone_service.create_zone({
        "nom_zone": "Zone Evenement Test",
        "type_zone": "publique"
    })
    camera = camera_service.create_camera({
        "nom_camera": "Cam Evenement Test",
        "emplacement": "Test",
        "flux_url": "rtsp://test",
        "id_zone": zone.id_zone
    })

    # ✅ 1. Créer un événement AVEC date_heure
    evenement_data = {
        "date_heure": datetime.now().isoformat(),  # ← AJOUT OBLIGATOIRE
        "type_evenement": "detection",
        "confiance": 0.95,
        "metadata": {"bbox": [100, 200, 50, 100], "couleur_dominante": "bleu"},
        "id_camera": camera.id_camera
    }
    evenement = service.create_evenement(evenement_data)
    print(f" ✅ Événement créé: ID {evenement.id_evenement}")

    # 2. Récupérer par ID
    evt = service.get_evenement_by_id(evenement.id_evenement)
    assert evt is not None
    print(" ✅ Récupération par ID OK")

    # 3. Récupérer événements récents
    recents = service.get_evenements_recents(10)
    print(f" 📊 Événements récents: {len(recents)}")

    # 4. Récupérer par caméra
    cam_events = service.get_evenements_par_camera(camera.id_camera, 10)
    print(f" 📊 Événements de la caméra: {len(cam_events)}")

    # 5. Statistiques journalières
    stats = service.get_statistiques_par_jour(7)
    print(f" 📊 Statistiques sur {len(stats)} jours")

    # 6. Activité par heure
    activite = service.get_activite_par_heure()
    print(f" 📊 Activité sur {len(activite)} heures")

    # 7. Nettoyage
    service.evenement_dao.delete(evenement.id_evenement)
    camera_service.delete_camera(camera.id_camera)
    zone_service.delete_zone(zone.id_zone)
    print(" ✅ Nettoyage OK")


# test_services.py - test_uniforme_service() corrigée

def test_uniforme_service():
    print("\n" + "=" * 60)
    print("📌 TEST UniformeService")
    print("=" * 60)
    employe_service = EmployeService()
    service = UniformeService()

    # Créer un employé
    email = f"uniforme_{random.randint(1, 10000)}@test.com"
    emp = employe_service.create_employe({
        "nom": "UniformeTest",
        "prenom": "User",
        "poste": "Testeur",
        "email": email,
        "date_embauche": datetime.now().isoformat(),
        "mot_de_passe": "Test123!"
    })
    print(f" 📍 Employé créé: {emp.id_employe}")

    # 1. Créer un uniforme
    uniforme_data = {
        "couleur_dominante": "rouge",
        "type_tenue": "veste",
        "date_debut": date.today().isoformat(),
        "id_employe": emp.id_employe
    }
    uniforme = service.create_uniforme(uniforme_data)
    print(f" ✅ Uniforme créé: ID {uniforme.id_uniforme}")

    # 2. Récupérer par ID
    uni = service.get_uniforme_by_id(uniforme.id_uniforme)
    assert uni is not None
    print(" ✅ Récupération par ID OK")

    # 3. Récupérer uniformes d'un employé
    uniforms = service.get_uniformes_employe(emp.id_employe)
    print(f" 📊 Uniformes de l'employé: {len(uniforms)}")

    # 4. Récupérer uniforme actuel
    actuel = service.get_uniforme_actuel(emp.id_employe)
    assert actuel is not None
    print(" ✅ Uniforme actuel récupéré")

    # 5. Récupérer par couleur
    rouges = service.get_uniformes_par_couleur("rouge")
    print(f" 📊 Uniformes rouges: {len(rouges)}")

    # 6. Terminer l'uniforme
    uni_termine = service.terminer_uniforme(uniforme.id_uniforme)
    # ✅ Maintenant est_actif est False
    assert uni_termine.est_actif == False
    print(" ✅ Uniforme terminé")

    # 7. Nettoyage
    service.uniforme_dao.delete(uniforme.id_uniforme)
    employe_service.delete_employe(emp.id_employe, soft_delete=False)
    print(" ✅ Nettoyage OK")


# test_services.py - test_chatbot_service() corrigée

def test_chatbot_service():
    print("\n" + "=" * 60)
    print("📌 TEST ChatbotService")
    print("=" * 60)
    employe_service = EmployeService()
    service = ChatbotService()

    # Créer un employé
    email = f"chatbot_{random.randint(1, 10000)}@test.com"
    emp = employe_service.create_employe({
        "nom": "ChatbotTest",
        "prenom": "User",
        "poste": "Testeur",
        "email": email,
        "date_embauche": datetime.now().isoformat(),
        "mot_de_passe": "Test123!"
    })
    print(f" 📍 Employé créé: {emp.id_employe}")

    # 1. Créer une interaction
    interaction = ChatbotInteraction(
        commande="Je vais en zone B pour maintenance",
        reponse="Déplacement enregistré",
        id_employe=emp.id_employe
    )
    result = service.create_interaction(interaction)
    print(f" ✅ Interaction créée: {result['message']}")

    # 2. Récupérer interactions d'un employé
    interactions = service.get_interactions_employe(emp.id_employe)
    print(f" 📊 Interactions de l'employé: {len(interactions)}")

    # 3. Traiter une commande de déplacement
    resultat = service.traiter_commande_deplacement(
        commande="Je vais en zone A pour réunion, retour à 15h",
        id_employe=emp.id_employe
    )
    print(f" ✅ Commande traitée: {resultat['message']}")

    # 4. Récupérer interactions récentes
    recentes = service.get_interactions_recentes(10)
    print(f" 📊 Interactions récentes: {len(recentes)}")

    # 5. Nettoyage
    for i in interactions:
        service.delete_interaction(i.id_interaction)
    for i in recentes:
        if i.id_interaction not in [x.id_interaction for x in interactions]:
            service.delete_interaction(i.id_interaction)
    employe_service.delete_employe(emp.id_employe, soft_delete=False)
    print(" ✅ Nettoyage OK")

def test_visage_service():
    print("\n" + "=" * 60)
    print("📌 TEST VisageService")
    print("=" * 60)

    employe_service = EmployeService()
    service = VisageService()

    # Créer un employé
    emp = employe_service.create_employe({
        "nom": "VisageTest",
        "prenom": "User",
        "poste": "Testeur",
        "email": f"visage_{random.randint(1,10000)}@test.com",
        "date_embauche": datetime.now().isoformat()
    })

    # 1. Créer un visage
    visage_data = {
        "encodage": {"vector": [0.1, 0.2, 0.3, 0.4, 0.5]},
        "id_employe": emp.id_employe,
        "angle": "face",
        "qualite": 0.85
    }
    visage = service.create_visage(visage_data)
    print(f"   ✅ Visage créé: ID {visage.id_visage}")

    # 2. Récupérer par ID
    vis = service.get_visage_by_id(visage.id_visage)
    assert vis is not None
    print("   ✅ Récupération par ID OK")

    # 3. Récupérer visages d'un employé
    visages = service.get_visages_employe(emp.id_employe)
    print(f"   📊 Visages de l'employé: {len(visages)}")

    # 4. Récupérer meilleur visage
    meilleur = service.get_meilleur_visage(emp.id_employe)
    assert meilleur is not None
    print("   ✅ Meilleur visage récupéré")

    # 5. Récupérer visages par angle
    faces = service.get_visages_par_angle("face")
    print(f"   📊 Visages de face: {len(faces)}")

    # 6. Mettre à jour la qualité
    vis_updated = service.update_qualite(visage.id_visage, 0.95)
    assert vis_updated.qualite == 0.95
    print("   ✅ Mise à jour qualité OK")

    # 7. Comparer deux visages (simulation)
    score = service.comparer_visages(visage.encodage, visage.encodage)
    print(f"   ✅ Comparaison: score {score}")

    # 8. Nettoyage
    service.delete_visage(visage.id_visage)
    employe_service.delete_employe(emp.id_employe, soft_delete=False)
    print("   ✅ Nettoyage OK")


# test_services.py - test_reconnaissance_service() corrigée

def test_reconnaissance_service():
    print("\n" + "=" * 60)
    print("📌 TEST ReconnaissanceService")
    print("=" * 60)
    employe_service = EmployeService()
    zone_service = ZoneService()
    camera_service = CameraService()
    evenement_service = EvenementService()
    service = ReconnaissanceService()

    # Créer un employé
    email = f"reco_{random.randint(1, 10000)}@test.com"
    emp = employe_service.create_employe({
        "nom": "RecoTest",
        "prenom": "User",
        "poste": "Testeur",
        "email": email,
        "date_embauche": datetime.now().isoformat(),
        "mot_de_passe": "Test123!"
    })
    print(f" 📍 Employé créé: {emp.id_employe}")

    # Créer une zone, une caméra et un événement
    zone = zone_service.create_zone({
        "nom_zone": "Zone Reco Test",
        "type_zone": "publique"
    })
    print(f" 📍 Zone créée: {zone.id_zone}")

    camera = camera_service.create_camera({
        "nom_camera": "Cam Reco Test",
        "emplacement": "Test",
        "flux_url": "rtsp://test",
        "id_zone": zone.id_zone
    })
    print(f" 📍 Caméra créée: {camera.id_camera}")

    # ✅ AJOUTER date_heure OBLIGATOIRE
    evenement = evenement_service.create_evenement({
        "date_heure": datetime.now().isoformat(),  # ← OBLIGATOIRE
        "type_evenement": "detection",
        "confiance": 0.95,
        "metadata": {"bbox": [100, 200, 50, 100]},
        "id_camera": camera.id_camera
    })
    print(f" 📍 Événement créé: {evenement.id_evenement}")

    # 1. Créer une reconnaissance
    reconnaissance_data = {
        "methode": "faciale",
        "score_confiance": 0.85,
        "id_evenement": evenement.id_evenement,
        "id_employe": emp.id_employe
    }
    reco = service.create_reconnaissance(reconnaissance_data)
    print(f" ✅ Reconnaissance créée: ID {reco.id_reconnaissance}")

    # 2. Récupérer par ID
    rec = service.get_reconnaissance_by_id(reco.id_reconnaissance)
    assert rec is not None
    print(" ✅ Récupération par ID OK")

    # 3. Récupérer par événement
    reco_evt = service.reconnaissance_dao.get_by_evenement(evenement.id_evenement)
    assert reco_evt is not None
    print(" ✅ Récupération par événement OK")

    # 4. Récupérer par employé
    recos_emp = service.get_reconnaissances_employe(emp.id_employe)
    print(f" 📊 Reconnaissances de l'employé: {len(recos_emp)}")

    # 5. Récupérer récentes
    recentes = service.get_reconnaissances_recentes(10)
    print(f" 📊 Reconnaissances récentes: {len(recentes)}")

    # 6. Statistiques
    stats = service.get_statistiques()
    print(f" 📊 Statistiques: {stats['total']} total, {stats['taux_identification']:.1f}% identifiés")

    # 7. Nettoyage
    service.reconnaissance_dao.delete(reco.id_reconnaissance)
    evenement_service.evenement_dao.delete(evenement.id_evenement)
    camera_service.delete_camera(camera.id_camera)
    zone_service.delete_zone(zone.id_zone)
    employe_service.delete_employe(emp.id_employe, soft_delete=False)
    print(" ✅ Nettoyage OK")

if __name__ == "__main__":
    print("=" * 70)
    print("🧪 TEST DES SERVICES")
    print("=" * 70)

    test_employe_service()
    test_zone_service()
    test_camera_service()
    test_deplacement_service()
    test_alerte_service()
    test_auth_service()
    test_session_presence_service()
    test_evenement_service()
    test_uniforme_service()
    test_chatbot_service()
    test_visage_service()
    test_reconnaissance_service()

    print("\n" + "=" * 70)
    print("✅ TESTS DES SERVICES TERMINÉS")
    print("=" * 70)