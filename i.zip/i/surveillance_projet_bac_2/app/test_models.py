# test_models.py

import sys
import os

# Ajouter le chemin du projet
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))

from datetime import datetime, timedelta, date
from app.models.Employe import Employe
from app.models.Zone import Zone
from app.models.Camera import Camera
from app.models.DeplacementSigne import DeplacementSigne
from app.models.Evenement import Evenement
from app.models.Alerte import Alerte
from app.models.Reconnaissance import Reconnaissance
from app.models.Notification import Notification
from app.models.SessionPresence import SessionPresence
from app.models.ChatbotInteraction import ChatbotInteraction
from app.models.Uniforme import Uniforme
from app.models.Visage import Visage


def test_employe():
    print("\n📌 TEST Employe")
    try:
        # Test création valide
        emp = Employe(
            nom="Dupont",
            prenom="Jean",
            poste="Agent",
            email="jean@test.com",
            date_embauche=datetime.now()
        )
        assert emp.nom == "Dupont"
        assert emp.email == "jean@test.com"
        print("   ✅ Création valide OK")

        # Test création invalide (champ manquant) - TypeError attendu
        try:
            emp2 = Employe(nom="Test", prenom="Test", poste="Test", email="test@test.com")
            print("   ❌ Devrait échouer (date_embauche manquante)")
        except TypeError as e:
            print(f"   ✅ Échec attendu (TypeError: {str(e)[:50]}...)")

        # Test setter email invalide
        try:
            emp.email = "invalid"
            print("   ❌ Devrait échouer (email invalide)")
        except ValueError:
            print("   ✅ Échec attendu (email invalide)")

    except Exception as e:
        print(f"   ❌ Erreur: {type(e).__name__}: {e}")


def test_zone():
    print("\n📌 TEST Zone")
    try:
        zone = Zone(nom_zone="Zone A", type_zone="publique")
        assert zone.type_zone == "publique"
        print("   ✅ Création valide OK")

        try:
            zone2 = Zone(nom_zone="Zone B", type_zone="invalide")
            print("   ❌ Devrait échouer (type invalide)")
        except ValueError:
            print("   ✅ Échec attendu (type invalide)")
    except Exception as e:
        print(f"   ❌ Erreur: {type(e).__name__}: {e}")


def test_camera():
    print("\n📌 TEST Camera")
    try:
        cam = Camera(
            nom_camera="Cam1",
            emplacement="Hall",
            flux_url="rtsp://192.168.1.1:554/stream",
            id_zone=1
        )
        assert cam.flux_url == "rtsp://192.168.1.1:554/stream"
        print("   ✅ Création valide OK")

        try:
            cam2 = Camera(
                nom_camera="Cam2",
                emplacement="Salle",
                flux_url="invalid",
                id_zone=1
            )
            print("   ❌ Devrait échouer (URL invalide)")
        except ValueError as e:
            print(f"   ✅ Échec attendu (URL invalide: {e})")
    except Exception as e:
        print(f"   ❌ Erreur: {type(e).__name__}: {e}")


def test_deplacement():
    print("\n📌 TEST DeplacementSigne")
    try:
        dep = DeplacementSigne(
            date_depart=datetime.now(),
            motif="Maintenance",
            id_employe=1,
            id_zone_destination=2
        )
        assert dep.motif == "Maintenance"
        print("   ✅ Création valide OK")

        # Test date retour avant départ
        try:
            dep.date_retour_prevue = datetime.now() - timedelta(hours=1)
            print("   ❌ Devrait échouer (retour avant départ)")
        except ValueError:
            print("   ✅ Échec attendu (retour avant départ)")
    except Exception as e:
        print(f"   ❌ Erreur: {type(e).__name__}: {e}")


def test_evenement():
    print("\n📌 TEST Evenement")
    try:
        evt = Evenement(
            date_heure=datetime.now(),
            type_evenement="detection",
            confiance=0.95,
            metadata={"bbox": [100, 200, 50, 100]},
            id_camera=1
        )
        assert evt.est_fiable == True
        print("   ✅ Création valide OK")

        try:
            evt2 = Evenement(
                date_heure=datetime.now(),
                type_evenement="detection",
                confiance=1.5,
                metadata={},
                id_camera=1
            )
            print("   ❌ Devrait échouer (confiance >1)")
        except ValueError:
            print("   ✅ Échec attendu (confiance >1)")
    except Exception as e:
        print(f"   ❌ Erreur: {type(e).__name__}: {e}")


def test_alerte():
    print("\n📌 TEST Alerte")
    try:
        alerte = Alerte(
            type_alerte="intrusion",
            message="Intrusion détectée",
            niveau_urgence=4
        )
        assert alerte.est_critique == True
        print("   ✅ Création valide OK")

        try:
            alerte2 = Alerte(
                type_alerte="invalid",
                message="Test",
                niveau_urgence=3
            )
            print("   ❌ Devrait échouer (type invalide)")
        except ValueError:
            print("   ✅ Échec attendu (type invalide)")
    except Exception as e:
        print(f"   ❌ Erreur: {type(e).__name__}: {e}")


def test_reconnaissance():
    print("\n📌 TEST Reconnaissance")
    try:
        reco = Reconnaissance(
            methode="faciale",
            score_confiance=0.85,
            id_evenement=1
        )
        assert reco.est_fiable == True
        print("   ✅ Création valide OK")

        try:
            reco2 = Reconnaissance(
                methode="faciale",
                score_confiance=1.2,
                id_evenement=1
            )
            print("   ❌ Devrait échouer (score >1)")
        except ValueError:
            print("   ✅ Échec attendu (score >1)")
    except Exception as e:
        print(f"   ❌ Erreur: {type(e).__name__}: {e}")


def test_notification():
    print("\n📌 TEST Notification")
    try:
        notif = Notification(
            canal="EMAIL",
            destinataire="test@test.com",
            contenu="Message de test",
            id_alerte=1
        )
        assert notif.canal == "EMAIL"
        print("   ✅ Création valide OK")

        try:
            notif2 = Notification(
                canal="FAX",
                destinataire="test@test.com",
                contenu="Test",
                id_alerte=1
            )
            print("   ❌ Devrait échouer (canal invalide)")
        except ValueError:
            print("   ✅ Échec attendu (canal invalide)")
    except Exception as e:
        print(f"   ❌ Erreur: {type(e).__name__}: {e}")


def test_session_presence():
    print("\n📌 TEST SessionPresence")
    try:
        session = SessionPresence(
            debut=datetime.now(),
            id_employe=1
        )
        assert session.est_active == True
        print("   ✅ Création valide OK")

        session.terminer()
        assert session.est_active == False
        print("   ✅ Terminaison OK")
    except Exception as e:
        print(f"   ❌ Erreur: {type(e).__name__}: {e}")


def test_chatbot_interaction():
    print("\n📌 TEST ChatbotInteraction")
    try:
        interaction = ChatbotInteraction(
            commande="Je vais en zone B",
            reponse="Déplacement enregistré",
            id_employe=1
        )
        assert interaction.commande == "Je vais en zone B"
        print("   ✅ Création valide OK")
    except Exception as e:
        print(f"   ❌ Erreur: {type(e).__name__}: {e}")


def test_uniforme():
    print("\n📌 TEST Uniforme")
    try:
        # Test création avec date fixe
        debut = date(2024, 1, 1)
        uniforme = Uniforme(
            couleur_dominante="bleu",
            type_tenue="chemise",
            date_debut=debut,
            id_employe=1
        )
        assert uniforme.est_actif == True
        print("   ✅ Création valide OK")

        # Test terminaison avec date dans le passé
        uniforme._date_fin = date(2023, 12, 31)
        assert uniforme.est_actif == False
        print("   ✅ Terminaison (date dans le passé) OK")

        # Test terminer() avec date aujourd'hui (reste actif selon logique métier)
        uniforme2 = Uniforme(
            couleur_dominante="rouge",
            type_tenue="veste",
            date_debut=date.today(),
            id_employe=1
        )
        uniforme2.terminer()
        # Selon la logique métier, un uniforme terminé aujourd'hui est encore actif
        assert uniforme2.est_actif == True
        print("   ✅ Terminer() aujourd'hui (reste actif) OK")

    except Exception as e:
        print(f"   ❌ Erreur: {type(e).__name__}: {e}")
        import traceback
        traceback.print_exc()


def test_visage():
    print("\n📌 TEST Visage")
    try:
        visage = Visage(
            encodage={"vector": [0.1, 0.2, 0.3]},
            id_employe=1,
            angle="face"
        )
        assert visage.est_de_face == True
        print("   ✅ Création valide OK")

        try:
            visage2 = Visage(
                encodage={"vector": [0.1, 0.2]},
                id_employe=1,
                angle="invalid"
            )
            print("   ❌ Devrait échouer (angle invalide)")
        except ValueError:
            print("   ✅ Échec attendu (angle invalide)")
    except Exception as e:
        print(f"   ❌ Erreur: {type(e).__name__}: {e}")


if __name__ == "__main__":
    print("=" * 60)
    print("🧪 TEST DES MODÈLES (CORRIGÉ)")
    print("=" * 60)

    test_employe()
    test_zone()
    test_camera()
    test_deplacement()
    test_evenement()
    test_alerte()
    test_reconnaissance()
    test_notification()
    test_session_presence()
    test_chatbot_interaction()
    test_uniforme()
    test_visage()

    print("\n" + "=" * 60)
    print("✅ Tests des modèles terminés")