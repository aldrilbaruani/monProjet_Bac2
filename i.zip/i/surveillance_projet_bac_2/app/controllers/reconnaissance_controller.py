# app/controllers/reconnaissance_controller.py
from flask import Blueprint, request
from app.controllers.base_controller import BaseController, handle_errors
from app.services.reconnaissance_service import ReconnaissanceService
from app.services.employe_service import EmployeService
from app.services.evenement_service import EvenementService
from app.utils.security import token_required, admin_required

reconnaissance_bp = Blueprint('reconnaissances', __name__, url_prefix='/api/reconnaissances')
reconnaissance_service = ReconnaissanceService()
employe_service = EmployeService()
evenement_service = EvenementService()


@reconnaissance_bp.route('/', methods=['GET'])
@token_required
@handle_errors
def get_all_reconnaissances():
    """Récupère toutes les reconnaissances."""
    employe_id = BaseController.get_int_param('employe_id')
    evenement_id = BaseController.get_int_param('evenement_id')
    limite = BaseController.get_int_param('limite', 100)

    if employe_id:
        reconnaissances = reconnaissance_service.get_reconnaissances_employe(employe_id)
    elif evenement_id:
        reco = reconnaissance_service.reconnaissance_dao.get_by_evenement(evenement_id)
        reconnaissances = [reco] if reco else []
    else:
        reconnaissances = reconnaissance_service.get_reconnaissances_recentes(limite)

    result = []
    for r in reconnaissances:
        r_dict = r.to_dict()
        if r.id_employe:
            try:
                employe = employe_service.get_employe_by_id(r.id_employe)
                r_dict['employe_nom'] = employe.nom_complet
            except:
                r_dict['employe_nom'] = "Inconnu"
        result.append(r_dict)

    return BaseController.success(result)


@reconnaissance_bp.route('/<int:id_reconnaissance>', methods=['GET'])
@token_required
@handle_errors
def get_reconnaissance(id_reconnaissance: int):
    """Récupère une reconnaissance par son ID."""
    reconnaissance = reconnaissance_service.get_reconnaissance_by_id(id_reconnaissance)
    r_dict = reconnaissance.to_dict()
    if reconnaissance.id_employe:
        try:
            employe = employe_service.get_employe_by_id(reconnaissance.id_employe)
            r_dict['employe_nom'] = employe.nom_complet
        except:
            r_dict['employe_nom'] = "Inconnu"
    return BaseController.success(r_dict)


@reconnaissance_bp.route('/', methods=['POST'])
@admin_required
@handle_errors
def create_reconnaissance():
    """Crée une nouvelle reconnaissance."""
    data = BaseController.get_json_or_400()
    reconnaissance = reconnaissance_service.create_reconnaissance(data)
    return BaseController.success(reconnaissance.to_dict(), "Reconnaissance créée", 201)


@reconnaissance_bp.route('/<int:id_reconnaissance>', methods=['PUT'])
@admin_required
@handle_errors
def update_reconnaissance(id_reconnaissance: int):
    """Met à jour une reconnaissance."""
    data = BaseController.get_json_or_400()
    reconnaissance = reconnaissance_service.update_reconnaissance(id_reconnaissance, data)
    return BaseController.success(reconnaissance.to_dict(), "Reconnaissance mise à jour")


@reconnaissance_bp.route('/evenement/<int:id_evenement>', methods=['GET'])
@token_required
@handle_errors
def get_reconnaissance_by_evenement(id_evenement: int):
    """Récupère la reconnaissance associée à un événement."""
    reconnaissance = reconnaissance_service.reconnaissance_dao.get_by_evenement(id_evenement)
    if not reconnaissance:
        return BaseController.error("Aucune reconnaissance trouvée pour cet événement", 404)
    return BaseController.success(reconnaissance.to_dict())


@reconnaissance_bp.route('/employe/<int:id_employe>', methods=['GET'])
@token_required
@handle_errors
def get_reconnaissances_by_employe(id_employe: int):
    """Récupère les reconnaissances d'un employé."""
    reconnaissances = reconnaissance_service.get_reconnaissances_employe(id_employe)
    return BaseController.success([r.to_dict() for r in reconnaissances])


@reconnaissance_bp.route('/traiter-evenement/<int:id_evenement>', methods=['POST'])
@admin_required
@handle_errors
def traiter_evenement(id_evenement: int):
    """Lance le traitement de reconnaissance sur un événement."""
    evenement = evenement_service.get_evenement_by_id(id_evenement)
    reconnaissance = reconnaissance_service.traiter_evenement(id_evenement)
    return BaseController.success(reconnaissance.to_dict(), "Traitement de reconnaissance effectué")


@reconnaissance_bp.route('/stats', methods=['GET'])
@admin_required
@handle_errors
def get_reconnaissance_stats():
    """Statistiques sur les reconnaissances."""
    stats = reconnaissance_service.get_statistiques()
    return BaseController.success(stats)


@reconnaissance_bp.route('/recentes', methods=['GET'])
@token_required
@handle_errors
def get_reconnaissances_recentes():
    """Récupère les reconnaissances récentes."""
    limite = BaseController.get_int_param('limite', 50)
    reconnaissances = reconnaissance_service.get_reconnaissances_recentes(limite)

    result = []
    for r in reconnaissances:
        r_dict = r.to_dict()
        if r.id_employe:
            try:
                employe = employe_service.get_employe_by_id(r.id_employe)
                r_dict['employe_nom'] = employe.nom_complet
            except:
                r_dict['employe_nom'] = "Inconnu"
        result.append(r_dict)

    return BaseController.success(result)