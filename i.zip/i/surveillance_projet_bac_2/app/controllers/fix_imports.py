from app.services.employe_service import EmployeService
# fix_imports.py


import os
import re


def fix_controller_imports(controller_dir):
    """Corrige les imports dans tous les fichiers controllers."""
    for filename in os.listdir(controller_dir):
        if filename.endswith('.py') and filename != '__init__.py':
            filepath = os.path.join(controller_dir, filename)

            with open(filepath, 'r', encoding='utf-8') as f:
                content = f.read()

            # Remplacer les imports incorrects
            content = re.sub(
                r'from surveillance_projet_bac_2\.app\.controllers\.base_controller',
                'from controllers.base_controller',
                content
            )

            content = re.sub(
                r'from surveillance_projet_bac_2\.app\.services\.(\w+)',
                r'from app.services.\1',
                content
            )

            content = re.sub(
                r'from surveillance_projet_bac_2\.app\.utils\.security',
                'from app.utils.security',
                content
            )

            content = re.sub(
                r'from surveillance_projet_bac_2\.app\.dao\.(\w+)',
                r'from app.dao.\1',
                content
            )

            with open(filepath, 'w', encoding='utf-8') as f:
                f.write(content)

            print(f" Corrigé: {filename}")


if __name__ == '__main__':
    controller_dir = 'app/controllers'
    fix_controller_imports(controller_dir)
    print("✨ Tous les imports ont été corrigés !")