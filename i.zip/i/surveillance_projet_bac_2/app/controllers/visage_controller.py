# app/controllers/visage_controller.py
from flask import Blueprint, request
from app.controllers.base_controller import BaseController, handle_errors
from app.services.visage_service import VisageService
from app.services.employe_service import EmployeService
from app.utils.security import token_required, admin_required
import tempfile

visage_bp = Blueprint('visages', __name__, url_prefix='/api/visages')
visage_service = VisageService()
employe_service = EmployeService()


@visage_bp.route('/', methods=['GET'])
@token_required
@handle_errors
def get_all_visages():
    """Récupère tous les visages."""
    employe_id = BaseController.get_int_param('employe_id')
    angle = request.args.get('angle')
    qualite_min = request.args.get('qualite_min')

    if employe_id:
        visages = visage_service.get_visages_employe(employe_id)
    elif angle:
        visages = visage_service.get_visages_par_angle(angle)
    elif qualite_min:
        visages = visage_service.visage_dao.get_de_bonne_qualite(float(qualite_min))
    else:
        visages = visage_service.visage_dao.get_de_bonne_qualite(0.5)

    result = []
    for v in visages:
        v_dict = v.to_dict()
        try:
            employe = employe_service.get_employe_by_id(v.id_employe)
            v_dict['employe_nom'] = employe.nom_complet
        except:
            v_dict['employe_nom'] = "Inconnu"
        result.append(v_dict)

    return BaseController.success(result)


@visage_bp.route('/<int:id_visage>', methods=['GET'])
@token_required
@handle_errors
def get_visage(id_visage: int):
    """Récupère un visage par son ID."""
    visage = visage_service.get_visage_by_id(id_visage)
    v_dict = visage.to_dict()
    try:
        employe = employe_service.get_employe_by_id(visage.id_employe)
        v_dict['employe_nom'] = employe.nom_complet
    except:
        v_dict['employe_nom'] = "Inconnu"
    return BaseController.success(v_dict)


@visage_bp.route('/', methods=['POST'])
@admin_required
@handle_errors
def create_visage():
    """Crée un nouveau visage."""
    data = BaseController.get_json_or_400()
    visage = visage_service.create_visage(data)
    return BaseController.success(visage.to_dict(), "Visage créé", 201)


@visage_bp.route('/<int:id_visage>/qualite', methods=['PUT'])
@admin_required
@handle_errors
def update_qualite(id_visage: int):
    """Met à jour la qualité d'un visage."""
    data = BaseController.get_json_or_400()
    qualite = data.get('qualite')
    if qualite is None:
        raise ValueError("La qualité est obligatoire")

    visage = visage_service.update_qualite(id_visage, qualite)
    return BaseController.success(visage.to_dict(), "Qualité mise à jour")


@visage_bp.route('/<int:id_visage>', methods=['DELETE'])
@admin_required
@handle_errors
def delete_visage(id_visage: int):
    """Supprime un visage."""
    result = visage_service.delete_visage(id_visage)
    return BaseController.success(result, result['message'])


@visage_bp.route('/employe/<int:id_employe>', methods=['GET'])
@token_required
@handle_errors
def get_visages_employe(id_employe: int):
    """Récupère les visages d'un employé."""
    visages = visage_service.get_visages_employe(id_employe)
    return BaseController.success([v.to_dict() for v in visages])


@visage_bp.route('/employe/<int:id_employe>/meilleur', methods=['GET'])
@token_required
@handle_errors
def get_meilleur_visage(id_employe: int):
    """Récupère le meilleur visage d'un employé."""
    visage = visage_service.get_meilleur_visage(id_employe)
    if not visage:
        return BaseController.error("Aucun visage trouvé pour cet employé", 404)
    return BaseController.success(visage.to_dict())


@visage_bp.route('/angle/<angle>', methods=['GET'])
@token_required
@handle_errors
def get_visages_by_angle(angle: str):
    """Récupère les visages par angle."""
    visages = visage_service.get_visages_par_angle(angle)
    return BaseController.success([v.to_dict() for v in visages])


@visage_bp.route('/upload', methods=['POST'])
@admin_required
@handle_errors
def upload_visage():
    """Upload une image pour créer un encodage facial."""
    if 'image' not in request.files:
        raise ValueError("Aucune image fournie")

    image = request.files['image']
    id_employe = request.form.get('id_employe')
    angle = request.form.get('angle', 'face')

    if not id_employe:
        raise ValueError("L'ID employé est obligatoire")

    with tempfile.NamedTemporaryFile(delete=False, suffix='.jpg') as tmp:
        image.save(tmp.name)
        tmp_path = tmp.name

    visage = visage_service.ajouter_visage_depuis_image(int(id_employe), tmp_path, angle, source='upload')
    return BaseController.success(visage.to_dict(), "Visage créé à partir de l'image", 201)