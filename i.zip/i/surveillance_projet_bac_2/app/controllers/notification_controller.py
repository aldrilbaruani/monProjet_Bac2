# app/controllers/notification_controller.py
from flask import Blueprint, request
from app.controllers.base_controller import BaseController, handle_errors
from app.services.notification_service import NotificationService
from app.utils.security import token_required, admin_required

notification_bp = Blueprint('notifications', __name__, url_prefix='/api/notifications')
notification_service = NotificationService()


@notification_bp.route('/', methods=['GET'])
@token_required
@handle_errors
def get_all_notifications():
    """Récupère les notifications avec filtres."""
    statut = request.args.get('statut')
    destinataire = request.args.get('destinataire')
    limite = BaseController.get_int_param('limite', 100)

    if destinataire:
        notifications = notification_service.get_notifications_non_lues(destinataire)
    elif statut:
        notifications = notification_service.notification_dao.get_par_statut(statut)
    else:
        notifications = notification_service.notification_dao.get_par_statut('envoye')

    notifications = notifications[:limite]
    return BaseController.success([n.to_dict() for n in notifications])


@notification_bp.route('/<int:id_notification>', methods=['GET'])
@token_required
@handle_errors
def get_notification(id_notification: int):
    """Récupère une notification par son ID."""
    notification = notification_service.get_notification_by_id(id_notification)
    return BaseController.success(notification.to_dict())


@notification_bp.route('/', methods=['POST'])
@admin_required
@handle_errors
def create_notification():
    """Crée une nouvelle notification."""
    data = BaseController.get_json_or_400()
    notification = notification_service.create_notification(data)
    return BaseController.success(notification.to_dict(), "Notification créée", 201)


@notification_bp.route('/<int:id_notification>/lire', methods=['POST'])
@token_required
@handle_errors
def marquer_comme_lue(id_notification: int):
    """Marque une notification comme lue."""
    notification = notification_service.marquer_comme_lue(id_notification)
    return BaseController.success(notification.to_dict(), "Notification marquée comme lue")


@notification_bp.route('/<int:id_notification>/envoyer', methods=['POST'])
@admin_required
@handle_errors
def envoyer_notification(id_notification: int):
    """Envoie une notification immédiatement."""
    success = notification_service.envoyer_maintenant(id_notification)
    if success:
        return BaseController.success(None, "Notification envoyée")
    return BaseController.error("Échec de l'envoi", 500)


@notification_bp.route('/non-lues', methods=['GET'])
@token_required
@handle_errors
def get_notifications_non_lues():
    """Récupère les notifications non lues."""
    destinataire = request.args.get('destinataire')
    notifications = notification_service.get_notifications_non_lues(destinataire)
    return BaseController.success([n.to_dict() for n in notifications])


@notification_bp.route('/alerte/<int:id_alerte>', methods=['GET'])
@token_required
@handle_errors
def get_notifications_par_alerte(id_alerte: int):
    """Récupère les notifications d'une alerte."""
    notifications = notification_service.get_notifications_par_alerte(id_alerte)
    return BaseController.success([n.to_dict() for n in notifications])


@notification_bp.route('/stats', methods=['GET'])
@admin_required
@handle_errors
def get_notification_stats():
    """Statistiques sur les notifications."""
    stats = notification_service.get_statistiques()
    return BaseController.success(stats)