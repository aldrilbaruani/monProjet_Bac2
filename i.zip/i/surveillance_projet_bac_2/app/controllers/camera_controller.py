# app/controllers/camera_controller.py
from flask import Blueprint, request
from app.controllers.base_controller import BaseController, handle_errors
from app.services.camera_service import CameraService
from app.utils.security import token_required, admin_required

camera_bp = Blueprint('cameras', __name__, url_prefix='/api/cameras')
camera_service = CameraService()


@camera_bp.route('/', methods=['GET'])
@token_required
@handle_errors
def get_all_cameras():
    """Récupère toutes les caméras."""
    actives_only = BaseController.get_bool_param('actives_only', False)
    zone_id = BaseController.get_int_param('zone_id')
    avec_statut = BaseController.get_bool_param('avec_statut', False)

    if zone_id:
        cameras = camera_service.get_cameras_by_zone(zone_id)
    elif actives_only:
        cameras = camera_service.get_all_cameras(actives_only=True)
    else:
        cameras = camera_service.get_all_cameras()

    if avec_statut:
        return BaseController.success([c.to_dict() for c in cameras])
    else:
        return BaseController.success([{
            'id_camera': c.id_camera,
            'nom_camera': c.nom_camera,
            'emplacement': c.emplacement,
            'flux_url': c.flux_url,
            'est_active': c.est_active,
            'id_zone': c.id_zone
        } for c in cameras])


@camera_bp.route('/<int:id_camera>', methods=['GET'])
@token_required
@handle_errors
def get_camera(id_camera: int):
    """Récupère une caméra par son ID."""
    camera = camera_service.get_camera_by_id(id_camera)
    return BaseController.success(camera.to_dict())


@camera_bp.route('/', methods=['POST'])
@admin_required
@handle_errors
def create_camera():
    """Crée une nouvelle caméra."""
    data = BaseController.get_json_or_400()
    camera = camera_service.create_camera(data)
    return BaseController.success(camera.to_dict(), "Caméra créée avec succès", 201)


@camera_bp.route('/<int:id_camera>', methods=['PUT'])
@admin_required
@handle_errors
def update_camera(id_camera: int):
    """Met à jour une caméra."""
    data = BaseController.get_json_or_400()
    camera = camera_service.update_camera(id_camera, data)
    return BaseController.success(camera.to_dict(), "Caméra mise à jour avec succès")


@camera_bp.route('/<int:id_camera>', methods=['DELETE'])
@admin_required
@handle_errors
def delete_camera(id_camera: int):
    """Supprime une caméra."""
    result = camera_service.delete_camera(id_camera)
    return BaseController.success(result, result['message'])


@camera_bp.route('/<int:id_camera>/activer', methods=['POST'])
@admin_required
@handle_errors
def activer_camera(id_camera: int):
    """Active une caméra."""
    camera = camera_service.activer_camera(id_camera)
    return BaseController.success(camera.to_dict(), "Caméra activée")


@camera_bp.route('/<int:id_camera>/desactiver', methods=['POST'])
@admin_required
@handle_errors
def desactiver_camera(id_camera: int):
    """Désactive une caméra."""
    camera = camera_service.desactiver_camera(id_camera)
    return BaseController.success(camera.to_dict(), "Caméra désactivée")


@camera_bp.route('/<int:id_camera>/connexion', methods=['POST'])
@token_required
@handle_errors
def update_connexion(id_camera: int):
    """Met à jour la date de connexion d'une caméra."""
    camera_service.update_connexion(id_camera)
    return BaseController.success(None, "Connexion mise à jour")


@camera_bp.route('/avec-statut', methods=['GET'])
@token_required
@handle_errors
def get_cameras_avec_statut():
    """Récupère les caméras avec leur statut en ligne."""
    cameras = camera_service.get_cameras_avec_statut()
    return BaseController.success(cameras)


@camera_bp.route('/zone/<int:id_zone>', methods=['GET'])
@token_required
@handle_errors
def get_cameras_by_zone(id_zone: int):
    """Récupère les caméras d'une zone spécifique."""
    cameras = camera_service.get_cameras_by_zone(id_zone)
    return BaseController.success([c.to_dict() for c in cameras])


@camera_bp.route('/stats', methods=['GET'])
@admin_required
@handle_errors
def get_camera_stats():
    """Statistiques sur les caméras."""
    stats = camera_service.get_statistiques()
    return BaseController.success(stats)