# app/controllers/zone_controller.py
from flask import Blueprint, request
from app.controllers.base_controller import BaseController, handle_errors
from app.services.zone_service import ZoneService
from app.utils.security import token_required, admin_required

zone_bp = Blueprint('zones', __name__, url_prefix='/api/zones')
zone_service = ZoneService()


@zone_bp.route('/', methods=['GET'])
@token_required
@handle_errors
def get_all_zones():
    """Récupère toutes les zones."""
    type_zone = request.args.get('type')

    if type_zone:
        zones = zone_service.get_zones_by_type(type_zone)
    else:
        zones = zone_service.get_all_zones()

    return BaseController.success([z.to_dict() for z in zones])


@zone_bp.route('/<int:id_zone>', methods=['GET'])
@token_required
@handle_errors
def get_zone(id_zone: int):
    """Récupère une zone par son ID."""
    zone = zone_service.get_zone_by_id(id_zone)
    return BaseController.success(zone.to_dict())


@zone_bp.route('/', methods=['POST'])
@admin_required
@handle_errors
def create_zone():
    """Crée une nouvelle zone."""
    data = BaseController.get_json_or_400()
    zone = zone_service.create_zone(data)
    return BaseController.success(zone.to_dict(), "Zone créée avec succès", 201)


@zone_bp.route('/<int:id_zone>', methods=['PUT'])
@admin_required
@handle_errors
def update_zone(id_zone: int):
    """Met à jour une zone."""
    data = BaseController.get_json_or_400()
    zone = zone_service.update_zone(id_zone, data)
    return BaseController.success(zone.to_dict(), "Zone mise à jour avec succès")


@zone_bp.route('/<int:id_zone>', methods=['DELETE'])
@admin_required
@handle_errors
def delete_zone(id_zone: int):
    """Supprime une zone."""
    result = zone_service.delete_zone(id_zone)
    return BaseController.success(result, result['message'])


@zone_bp.route('/<int:id_zone>/cameras', methods=['GET'])
@token_required
@handle_errors
def get_zone_cameras(id_zone: int):
    """Récupère les caméras d'une zone."""
    from app.services.camera_service import CameraService
    camera_service = CameraService()
    cameras = camera_service.get_cameras_by_zone(id_zone)
    return BaseController.success([c.to_dict() for c in cameras])


@zone_bp.route('/avec-cameras', methods=['GET'])
@token_required
@handle_errors
def get_zones_avec_cameras():
    """Récupère les zones avec leurs caméras."""
    zones = zone_service.get_zones_avec_cameras()
    return BaseController.success(zones)


@zone_bp.route('/<int:id_zone>/verifier-acces/<int:id_employe>', methods=['GET'])
@token_required
@handle_errors
def verifier_acces(id_zone: int, id_employe: int):
    """Vérifie si un employé a accès à une zone."""
    acces = zone_service.verifier_acces(id_employe, id_zone)
    return BaseController.success({
        "acces_autorise": acces,
        "id_zone": id_zone,
        "id_employe": id_employe
    })


@zone_bp.route('/type/<type_zone>', methods=['GET'])
@token_required
@handle_errors
def get_zones_by_type(type_zone: str):
    """Récupère les zones par type."""
    zones = zone_service.get_zones_by_type(type_zone)
    return BaseController.success([z.to_dict() for z in zones])


@zone_bp.route('/stats', methods=['GET'])
@admin_required
@handle_errors
def get_zone_stats():
    """Statistiques sur les zones."""
    zones = zone_service.get_all_zones()

    stats = {"total": len(zones), "par_type": {}, "niveau_acces_moyen": 0}
    total_niveau = 0
    for zone in zones:
        stats["par_type"][zone.type_zone] = stats["par_type"].get(zone.type_zone, 0) + 1
        total_niveau += zone.niveau_acces

    if zones:
        stats["niveau_acces_moyen"] = total_niveau / len(zones)

    return BaseController.success(stats)