# app/controllers/__init__.py
"""
Module des contrôleurs de l'API.
"""

# Importer tous les blueprints
from app.controllers.auth_controller import auth_bp
from app.controllers.employe_controller import employe_bp
from app.controllers.zone_controller import zone_bp
from app.controllers.camera_controller import camera_bp
from app.controllers.deplacement_controller import deplacement_bp
from app.controllers.evenement_controller import evenement_bp
from app.controllers.alerte_controller import alerte_bp
from app.controllers.notification_controller import notification_bp
from app.controllers.reconnaissance_controller import reconnaissance_bp
from app.controllers.chatbot_controller import chatbot_bp
from app.controllers.session_presence_controller import session_bp
from app.controllers.uniforme_controller import uniforme_bp
from app.controllers.visage_controller import visage_bp
from app.controllers.stats_controller import stats_bp
from app.controllers.analyse_controller import analyse_bp


def register_blueprints(app):
    """Enregistre tous les blueprints dans l'application Flask."""
    blueprints = [
        (auth_bp, "auth", "/api/auth"),
        (employe_bp, "employes", "/api/employes"),
        (zone_bp, "zones", "/api/zones"),
        (camera_bp, "cameras", "/api/cameras"),
        (deplacement_bp, "deplacements", "/api/deplacements"),
        (evenement_bp, "evenements", "/api/evenements"),
        (alerte_bp, "alertes", "/api/alertes"),
        (notification_bp, "notifications", "/api/notifications"),
        (reconnaissance_bp, "reconnaissances", "/api/reconnaissances"),
        (chatbot_bp, "chatbot", "/api/chatbot"),
        (session_bp, "sessions", "/api/sessions"),
        (uniforme_bp, "uniformes", "/api/uniformes"),
        (visage_bp, "visages", "/api/visages"),
        (stats_bp, "stats", "/api/stats"),
        (analyse_bp, "analyse", "/api/analyse")
    ]

    for blueprint, name, url in blueprints:
        app.register_blueprint(blueprint)
        print(f"✅ Blueprint enregistré: {name} -> {url}")