# controllers/test_all.py - VERSION CORRIGÉE

import sys
import os

# Configuration du chemin
def main():
    current_dir = os.path.dirname(os.path.abspath(__file__))
    project_root = os.path.dirname(current_dir)
    if project_root not in sys.path:
        sys.path.insert(0, project_root)

    # Imports
    from app.services.employe_service import EmployeService
    from app.services.zone_service import ZoneService
    from app.services.camera_service import CameraService

    print("✅ Imports réussis dans test_all.py")
if __name__ == '__main__':
    main()