# app/controllers/auth_controller.py
from flask import Blueprint, request, jsonify
from app.controllers.base_controller import BaseController, handle_errors
from app.services.auth_service import AuthService
from app.services.employe_service import EmployeService
from app.utils.security import token_required, get_current_user_id, admin_required
import logging
import bcrypt
import jwt
from datetime import datetime, timedelta
import os

auth_bp = Blueprint('auth', __name__, url_prefix='/api/auth')
auth_service = AuthService()
logger = logging.getLogger(__name__)


@auth_bp.route('/login', methods=['POST'])
@handle_errors
def login():
    """Authentification utilisateur avec base de données réelle."""
    data = BaseController.get_json_or_400()
    email = data.get('email')
    password = data.get('password')

    if not email or not password:
        raise ValueError("Email et mot de passe requis")

    # ✅ Utiliser le service d'authentification réel
    result = auth_service.authenticate(email, password)

    if not result:
        raise ValueError("Email ou mot de passe incorrect")

    # ✅ Le service retourne déjà le token et les infos employé
    return BaseController.success(result, "Connexion réussie")


@auth_bp.route('/register', methods=['POST'])
@admin_required
@handle_errors
def register():
    """Inscription d'un nouvel employé (admin seulement)."""
    data = BaseController.get_json_or_400()

    required_fields = ['nom', 'prenom', 'email', 'password', 'poste', 'date_embauche']
    for field in required_fields:
        if field not in data:
            raise ValueError(f"Le champ {field} est requis")

    password = data.pop('password')
    if len(password) < 6:
        raise ValueError("Le mot de passe doit contenir au moins 6 caractères")

    employe = auth_service.register(data, password)
    return BaseController.success(employe.to_dict(), "Employé créé avec succès", 201)


@auth_bp.route('/me', methods=['GET'])
@token_required
@handle_errors
def get_current_user():
    """Récupère l'utilisateur connecté."""
    user_id = get_current_user_id()
    employe_service = EmployeService()
    employe = employe_service.get_employe_by_id(user_id)

    if not employe:
        raise ValueError("Utilisateur introuvable")
    if not employe.actif:
        raise PermissionError("Compte désactivé")

    return BaseController.success(employe.to_dict())


@auth_bp.route('/logout', methods=['POST'])
@token_required
@handle_errors
def logout():
    """Déconnexion."""
    user_id = get_current_user_id()
    logger.info(f"Déconnexion de l'utilisateur {user_id}")
    return BaseController.success(None, "Déconnexion réussie")


@auth_bp.route('/verify', methods=['GET'])
@handle_errors
def verify_token():
    """Vérifie la validité d'un token."""
    from app.utils.security import get_token_from_header, decode_token

    token = get_token_from_header()
    if not token:
        return BaseController.success({'valid': False, 'reason': 'missing'})

    payload = decode_token(token)
    if not payload:
        return BaseController.success({'valid': False, 'reason': 'invalid'})

    return BaseController.success({
        'valid': True,
        'id_employe': payload['id_employe'],
        'role': payload['role'],
        'exp': payload['exp']
    })


@auth_bp.route('/change-password', methods=['POST'])
@token_required
@handle_errors
def change_password():
    """Change le mot de passe de l'utilisateur connecté."""
    data = BaseController.get_json_or_400()
    old_password = data.get('old_password')
    new_password = data.get('new_password')

    if not old_password or not new_password:
        raise ValueError("Ancien et nouveau mot de passe requis")
    if len(new_password) < 6:
        raise ValueError("Le nouveau mot de passe doit contenir au moins 6 caractères")

    user_id = get_current_user_id()
    success = auth_service.change_password(user_id, old_password, new_password)

    if not success:
        raise ValueError("Ancien mot de passe incorrect")

    return BaseController.success(None, "Mot de passe changé avec succès")


@auth_bp.route('/reset-password/<int:id_employe>', methods=['POST'])
@admin_required
@handle_errors
def reset_password(id_employe: int):
    """Réinitialise le mot de passe d'un employé (admin seulement)."""
    data = BaseController.get_json_or_400()
    new_password = data.get('new_password')

    if not new_password:
        raise ValueError("Nouveau mot de passe requis")
    if len(new_password) < 6:
        raise ValueError("Le mot de passe doit contenir au moins 6 caractères")

    success = auth_service.reset_password(id_employe, new_password)
    if not success:
        raise ValueError("Employé introuvable")

    return BaseController.success(None, "Mot de passe réinitialisé avec succès")