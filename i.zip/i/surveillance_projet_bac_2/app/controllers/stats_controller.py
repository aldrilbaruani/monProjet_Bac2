# app/controllers/stats_controller.py
from flask import Blueprint, request
from app.controllers.base_controller import BaseController, handle_errors
from app.services.employe_service import EmployeService
from app.services.camera_service import CameraService
from app.services.deplacement_service import DeplacementService
from app.services.alerte_service import AlerteService
from app.services.evenement_service import EvenementService
from app.services.session_presence_service import SessionPresenceService
from app.services.zone_service import ZoneService
from app.utils.security import token_required, admin_required
from datetime import datetime, timedelta

stats_bp = Blueprint('stats', __name__, url_prefix='/api/stats')


@stats_bp.route('/dashboard', methods=['GET'])
@token_required
@handle_errors
def get_dashboard_stats():
    """Statistiques pour le dashboard principal."""
    employe_service = EmployeService()
    camera_service = CameraService()
    deplacement_service = DeplacementService()
    alerte_service = AlerteService()
    evenement_service = EvenementService()
    presence_service = SessionPresenceService()

    employes = employe_service.get_statistiques()
    cameras = camera_service.get_statistiques()
    deplacements = deplacement_service.get_statistiques()
    alertes = alerte_service.get_statistiques()

    now = datetime.now()
    hier = now - timedelta(hours=24)
    evenements_recents = evenement_service.get_evenements_par_periode(hier, now)
    sessions_en_cours = presence_service.session_dao.get_en_cours()

    stats = {
        "employes": employes,
        "cameras": cameras,
        "deplacements": deplacements,
        "alertes": alertes,
        "evenements_24h": len(evenements_recents),
        "presences_actuelles": len(sessions_en_cours),
        "timestamp": now.isoformat()
    }

    return BaseController.success(stats)


@stats_bp.route('/superadmin', methods=['GET'])
@admin_required
@handle_errors
def get_superadmin_stats():
    """Statistiques complètes pour super admin."""
    employe_service = EmployeService()
    camera_service = CameraService()
    deplacement_service = DeplacementService()
    alerte_service = AlerteService()
    zone_service = ZoneService()

    employes = employe_service.get_statistiques()
    cameras = camera_service.get_statistiques()
    deplacements = deplacement_service.get_statistiques()
    alertes = alerte_service.get_statistiques()
    tous_employes = employe_service.get_all_employes(actifs_only=False)
    zones = zone_service.get_all_zones()

    stats_par_zone = []
    for zone in zones:
        cameras_zone = camera_service.get_cameras_by_zone(zone.id_zone)
        stats_par_zone.append({
            "zone": zone.nom_zone,
            "cameras": len(cameras_zone)
        })

    stats = {
        "employes": {
            **employes,
            "liste_roles": {
                'super_admin': len([e for e in tous_employes if e.role == 'super_admin']),
                'admin': len([e for e in tous_employes if e.role == 'admin']),
                'employe': len([e for e in tous_employes if e.role == 'employe'])
            }
        },
        "cameras": cameras,
        "deplacements": deplacements,
        "alertes": alertes,
        "zones": stats_par_zone,
        "timestamp": datetime.now().isoformat()
    }

    return BaseController.success(stats)


@stats_bp.route('/admin', methods=['GET'])
@admin_required
@handle_errors
def get_admin_stats():
    """Statistiques pour admin (vue restreinte)."""
    deplacement_service = DeplacementService()
    alerte_service = AlerteService()

    deplacements = deplacement_service.get_statistiques()
    alertes = alerte_service.get_statistiques()

    stats = {
        "deplacements_en_cours": deplacements.get('total_en_cours', 0),
        "deplacements_en_retard": deplacements.get('total_en_retard', 0),
        "alertes_non_traitees": alertes.get('non_traitees', 0),
        "alertes_critiques": alertes.get('critiques', 0)
    }

    return BaseController.success(stats)


@stats_bp.route('/employe/<int:id_employe>', methods=['GET'])
@token_required
@handle_errors
def get_employe_stats(id_employe: int):
    """Statistiques personnelles d'un employé."""
    deplacement_service = DeplacementService()
    alerte_service = AlerteService()
    presence_service = SessionPresenceService()

    deplacements = deplacement_service.get_deplacements_employe(id_employe)
    alertes = alerte_service.get_alertes_employe(id_employe)
    sessions = presence_service.get_sessions_employe(id_employe)

    deplacements_en_cours = [d for d in deplacements if d.est_en_cours]
    deplacements_termines = [d for d in deplacements if d.est_termine]
    deplacements_retard = [d for d in deplacements if d.est_en_retard]

    alertes_non_lues = [a for a in alertes if a.statut == 'envoyee']

    aujourd_hui = datetime.now().date()
    sessions_aujourdhui = [s for s in sessions if s.debut.date() == aujourd_hui]

    stats = {
        "deplacements": {
            "total": len(deplacements),
            "en_cours": len(deplacements_en_cours),
            "termines": len(deplacements_termines),
            "en_retard": len(deplacements_retard)
        },
        "alertes": {
            "total": len(alertes),
            "non_lues": len(alertes_non_lues)
        },
        "presence": {
            "present_aujourdhui": len(sessions_aujourdhui) > 0,
            "temps_total": sum(s.duree for s in sessions_aujourdhui if s.duree)
        }
    }

    return BaseController.success(stats)


@stats_bp.route('/temps-reel', methods=['GET'])
@token_required
@handle_errors
def get_temps_reel():
    """Statistiques en temps réel (pour rafraîchissement auto)."""
    alerte_service = AlerteService()
    deplacement_service = DeplacementService()
    camera_service = CameraService()

    alertes_non_traitees = alerte_service.get_alertes_non_traitees()
    deplacements_en_cours = deplacement_service.get_deplacements_en_cours()
    deplacements_en_retard = deplacement_service.deplacement_dao.get_en_retard()
    cameras_actives = camera_service.get_all_cameras(actives_only=True)
    alertes_critiques = [a for a in alertes_non_traitees if a.est_critique]

    return BaseController.success({
        "alertes_non_traitees": len(alertes_non_traitees),
        "alertes_critiques": len(alertes_critiques),
        "deplacements_en_cours": len(deplacements_en_cours),
        "deplacements_en_retard": len(deplacements_en_retard),
        "cameras_actives": len(cameras_actives),
        "timestamp": datetime.now().isoformat()
    })