# app/controllers/alerte_controller.py
from flask import Blueprint, request
from app.controllers.base_controller import BaseController, handle_errors
from app.services.alerte_service import AlerteService
from app.services.employe_service import EmployeService
from app.utils.security import token_required, admin_required

alerte_bp = Blueprint('alertes', __name__, url_prefix='/api/alertes')
alerte_service = AlerteService()
employe_service = EmployeService()


@alerte_bp.route('/', methods=['GET'])
@token_required
@handle_errors
def get_all_alertes():
    """Récupère les alertes avec filtres."""
    statut = request.args.get('statut')
    type_alerte = request.args.get('type')
    employe_id = BaseController.get_int_param('employe_id')
    limite = BaseController.get_int_param('limite', 100)

    if employe_id:
        alertes = alerte_service.get_alertes_employe(employe_id)
    elif statut == 'non_traitees':
        alertes = alerte_service.get_alertes_non_traitees()
    elif statut == 'critiques':
        alertes = alerte_service.get_alertes_critiques()
    else:
        alertes = alerte_service.get_alertes_non_traitees()

    if type_alerte:
        alertes = [a for a in alertes if a.type_alerte == type_alerte]
    if statut and statut not in ['non_traitees', 'critiques']:
        alertes = [a for a in alertes if a.statut == statut]

    alertes = alertes[:limite]

    result = []
    for a in alertes:
        a_dict = a.to_dict()
        if a.id_employe_concerne:
            try:
                employe = employe_service.get_employe_by_id(a.id_employe_concerne)
                a_dict['employe_nom'] = employe.nom_complet
            except:
                a_dict['employe_nom'] = "Inconnu"
        result.append(a_dict)

    return BaseController.success(result)


@alerte_bp.route('/<int:id_alerte>', methods=['GET'])
@token_required
@handle_errors
def get_alerte(id_alerte: int):
    """Récupère une alerte par son ID."""
    alerte = alerte_service.get_alerte_by_id(id_alerte)
    a_dict = alerte.to_dict()
    if alerte.id_employe_concerne:
        try:
            employe = employe_service.get_employe_by_id(alerte.id_employe_concerne)
            a_dict['employe_nom'] = employe.nom_complet
        except:
            a_dict['employe_nom'] = "Inconnu"
    return BaseController.success(a_dict)


@alerte_bp.route('/non-traitees', methods=['GET'])
@token_required
@handle_errors
def get_alertes_non_traitees():
    """Récupère les alertes non traitées."""
    alertes = alerte_service.get_alertes_non_traitees()

    result = []
    for a in alertes:
        a_dict = a.to_dict()
        if a.id_employe_concerne:
            try:
                employe = employe_service.get_employe_by_id(a.id_employe_concerne)
                a_dict['employe_nom'] = employe.nom_complet
            except:
                a_dict['employe_nom'] = "Inconnu"
        result.append(a_dict)

    return BaseController.success(result)


@alerte_bp.route('/critiques', methods=['GET'])
@token_required
@handle_errors
def get_alertes_critiques():
    """Récupère les alertes critiques."""
    alertes = alerte_service.get_alertes_critiques()

    result = []
    for a in alertes:
        a_dict = a.to_dict()
        if a.id_employe_concerne:
            try:
                employe = employe_service.get_employe_by_id(a.id_employe_concerne)
                a_dict['employe_nom'] = employe.nom_complet
            except:
                a_dict['employe_nom'] = "Inconnu"
        result.append(a_dict)

    return BaseController.success(result)


@alerte_bp.route('/employe/<int:id_employe>', methods=['GET'])
@token_required
@handle_errors
def get_alertes_employe(id_employe: int):
    """Récupère les alertes d'un employé."""
    alertes = alerte_service.get_alertes_employe(id_employe)
    return BaseController.success([a.to_dict() for a in alertes])


@alerte_bp.route('/', methods=['POST'])
@admin_required
@handle_errors
def create_alerte():
    """Crée une nouvelle alerte."""
    data = BaseController.get_json_or_400()
    alerte = alerte_service.create_alerte(data)
    return BaseController.success(alerte.to_dict(), "Alerte créée", 201)


@alerte_bp.route('/<int:id_alerte>/traiter', methods=['POST'])
@admin_required
@handle_errors
def traiter_alerte(id_alerte: int):
    """Marque une alerte comme traitée."""
    from app.utils.security import get_current_user_id
    data = request.get_json() or {}
    commentaire = data.get('commentaire')
    utilisateur_id = get_current_user_id()

    alerte = alerte_service.traiter_alerte(id_alerte, utilisateur_id, commentaire)
    return BaseController.success(alerte.to_dict(), "Alerte traitée")


@alerte_bp.route('/<int:id_alerte>/ignorer', methods=['POST'])
@admin_required
@handle_errors
def ignorer_alerte(id_alerte: int):
    """Ignore une alerte."""
    from app.utils.security import get_current_user_id
    data = request.get_json() or {}
    raison = data.get('raison')
    utilisateur_id = get_current_user_id()

    alerte = alerte_service.ignorer_alerte(id_alerte, utilisateur_id, raison)
    return BaseController.success(alerte.to_dict(), "Alerte ignorée")


@alerte_bp.route('/<int:id_alerte>/notifier', methods=['POST'])
@admin_required
@handle_errors
def notifier_alerte(id_alerte: int):
    """Envoie des notifications pour une alerte."""
    data = request.get_json() or {}
    canaux = data.get('canaux')

    notifications = alerte_service.notifier_alerte(id_alerte, canaux)
    return BaseController.success([n.to_dict() for n in notifications], f"{len(notifications)} notifications envoyées")


@alerte_bp.route('/stats', methods=['GET'])
@admin_required
@handle_errors
def get_alerte_stats():
    """Statistiques sur les alertes."""
    stats = alerte_service.get_statistiques()
    return BaseController.success(stats)