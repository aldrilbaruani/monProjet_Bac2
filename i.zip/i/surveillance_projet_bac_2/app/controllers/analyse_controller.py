# app/controllers/analyse_controller.py
from flask import Blueprint, request
from app.controllers.base_controller import BaseController, handle_errors
from app.services.analyse_comportementale_service import AnalyseComportementaleService
from app.services.evenement_service import EvenementService
from app.services.deplacement_service import DeplacementService
from app.services.alerte_service import AlerteService
from app.services.zone_service import ZoneService
from app.services.session_presence_service import SessionPresenceService
from app.services.employe_service import EmployeService
from app.utils.security import token_required, admin_required

analyse_bp = Blueprint('analyse', __name__, url_prefix='/api/analyse')
analyse_service = AnalyseComportementaleService()
evenement_service = EvenementService()


@analyse_bp.route('/evenement/<int:id_evenement>', methods=['POST'])
@token_required
@handle_errors
def analyser_evenement(id_evenement: int):
    """Analyse un événement spécifique."""
    evenement = evenement_service.get_evenement_by_id(id_evenement)
    resultat = analyse_service.analyser_evenement(id_evenement)
    return BaseController.success(resultat, "Analyse terminée")


@analyse_bp.route('/scan-periodique', methods=['POST'])
@admin_required
@handle_errors
def scan_periodique():
    """Lance un scan périodique du système."""
    resultats = analyse_service.scanner_periodique()
    message = f"Scan terminé. {len(resultats['alertes_generees'])} alertes générées"
    return BaseController.success(resultats, message)


@analyse_bp.route('/detection-temps-reel', methods=['POST'])
@token_required
@handle_errors
def detection_temps_reel():
    """Traite une détection en temps réel."""
    data = BaseController.get_json_or_400()
    evenement = evenement_service.create_evenement(data)
    resultat = analyse_service.analyser_evenement(evenement.id_evenement)
    return BaseController.success({
        "evenement": evenement.to_dict(),
        "analyse": resultat
    }, "Détection traitée", 201)


@analyse_bp.route('/verifier-zone', methods=['POST'])
@token_required
@handle_errors
def verifier_zone():
    """Vérifie si un employé a le droit d'être dans une zone."""
    data = BaseController.get_json_or_400()
    id_employe = data.get('id_employe')
    id_zone = data.get('id_zone')

    if not id_employe or not id_zone:
        raise ValueError("ID employé et ID zone requis")

    zone_service = ZoneService()
    acces = zone_service.verifier_acces(id_employe, id_zone)

    return BaseController.success({
        "acces_autorise": acces,
        "id_employe": id_employe,
        "id_zone": id_zone
    })


@analyse_bp.route('/statistiques/comportement', methods=['GET'])
@token_required
@handle_errors
def get_statistiques_comportement():
    """Statistiques comportementales."""
    employe_id = BaseController.get_int_param('employe_id')

    if employe_id:
        deplacement_service = DeplacementService()
        alerte_service = AlerteService()

        deplacements = deplacement_service.get_deplacements_employe(employe_id)
        alertes = alerte_service.get_alertes_employe(employe_id)

        stats = {
            "employe_id": employe_id,
            "total_deplacements": len(deplacements),
            "deplacements_en_retard": len([d for d in deplacements if d.est_en_retard]),
            "total_alertes": len(alertes),
            "alertes_non_traitees": len([a for a in alertes if a.statut == 'envoyee'])
        }
    else:
        deplacement_service = DeplacementService()
        stats = deplacement_service.get_statistiques()

    return BaseController.success(stats)


@analyse_bp.route('/alerts/actives', methods=['GET'])
@token_required
@handle_errors
def get_alertes_actives():
    """Récupère les alertes actives (non traitées)."""
    alerte_service = AlerteService()
    alertes = alerte_service.get_alertes_non_traitees()
    return BaseController.success([a.to_dict() for a in alertes])


@analyse_bp.route('/presence/global', methods=['GET'])
@token_required
@handle_errors
def get_presence_globale():
    """Statistiques globales de présence."""
    session_service = SessionPresenceService()
    employe_service = EmployeService()

    sessions_en_cours = session_service.session_dao.get_en_cours()
    total_employes = len(employe_service.get_all_employes())

    return BaseController.success({
        "employes_presents": len(sessions_en_cours),
        "total_employes": total_employes,
        "taux_presence": round((len(sessions_en_cours) / total_employes) * 100, 2) if total_employes > 0 else 0,
        "sessions": [s.to_dict() for s in sessions_en_cours[:10]]
    })