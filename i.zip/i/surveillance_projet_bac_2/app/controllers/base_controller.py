# app/controllers/base_controller.py
from flask import jsonify, request
from functools import wraps
import logging
from typing import Any, Dict, Optional, List, Union

logger = logging.getLogger(__name__)


class BaseController:
    """Classe de base avec utilitaires pour tous les controllers."""

    @staticmethod
    def success(data: Any = None, message: str = "Succès", status_code: int = 200) -> tuple:
        """Retourne une réponse JSON de succès."""
        response = {"success": True, "message": message}
        if data is not None:
            response["data"] = data
        return jsonify(response), status_code

    @staticmethod
    def error(message: str = "Erreur", status_code: int = 400, errors: Optional[Dict] = None) -> tuple:
        """Retourne une réponse JSON d'erreur."""
        response = {"success": False, "message": message}
        if errors:
            response["errors"] = errors
        return jsonify(response), status_code

    @staticmethod
    def get_json_or_400() -> Dict:
        """Récupère les données JSON de la requête."""
        if not request.is_json:
            raise ValueError("Le contenu doit être au format JSON")
        data = request.get_json()
        if data is None:
            raise ValueError("Données JSON invalides ou manquantes")
        return data

    @staticmethod
    def get_int_param(param_name: str, default: Optional[int] = None) -> Optional[int]:
        """Récupère un paramètre entier de l'URL."""
        value = request.args.get(param_name)
        if value is None:
            return default
        try:
            return int(value)
        except ValueError:
            raise ValueError(f"Le paramètre {param_name} doit être un entier, reçu: {value}")

    @staticmethod
    def get_bool_param(param_name: str, default: bool = False) -> bool:
        """Récupère un paramètre booléen de l'URL."""
        value = request.args.get(param_name)
        if value is None:
            return default
        return value.lower() in ('true', '1', 'yes', 'on')

    @staticmethod
    def get_str_param(param_name: str, default: Optional[str] = None) -> Optional[str]:
        """Récupère un paramètre chaîne de l'URL."""
        value = request.args.get(param_name)
        if value is None:
            return default
        return value.strip() if value else default

    @staticmethod
    def get_float_param(param_name: str, default: Optional[float] = None) -> Optional[float]:
        """Récupère un paramètre flottant de l'URL."""
        value = request.args.get(param_name)
        if value is None:
            return default
        try:
            return float(value)
        except ValueError:
            raise ValueError(f"Le paramètre {param_name} doit être un nombre, reçu: {value}")


def handle_errors(f):
    """Décorateur pour gérer les erreurs de manière centralisée."""
    @wraps(f)
    def decorated_function(*args, **kwargs):
        try:
            return f(*args, **kwargs)
        except ValueError as e:
            logger.warning(f"Erreur de validation: {str(e)}")
            return BaseController.error(str(e), 400)
        except PermissionError as e:
            logger.warning(f"Erreur de permission: {str(e)}")
            return BaseController.error(str(e), 403)
        except Exception as e:
            logger.exception(f"Erreur non gérée: {str(e)}")
            return BaseController.error("Erreur interne du serveur", 500)
    return decorated_function