# app/controllers/session_presence_controller.py
from flask import Blueprint, request
from app.controllers.base_controller import BaseController, handle_errors
from app.services.session_presence_service import SessionPresenceService
from app.services.employe_service import EmployeService
from app.utils.security import token_required, admin_required
from datetime import date

session_bp = Blueprint('sessions', __name__, url_prefix='/api/sessions')
session_service = SessionPresenceService()
employe_service = EmployeService()


@session_bp.route('/', methods=['GET'])
@token_required
@handle_errors
def get_all_sessions():
    """Récupère toutes les sessions de présence."""
    employe_id = BaseController.get_int_param('employe_id')
    en_cours = BaseController.get_bool_param('en_cours', False)
    date_str = request.args.get('date')

    if employe_id:
        sessions = session_service.get_sessions_employe(employe_id)
    elif en_cours:
        sessions = session_service.session_dao.get_en_cours()
    elif date_str:
        date_obj = date.fromisoformat(date_str)
        sessions = session_service.session_dao.get_par_jour(date_obj)
    else:
        sessions = session_service.session_dao.get_en_cours()

    result = []
    for s in sessions:
        s_dict = s.to_dict()
        try:
            employe = employe_service.get_employe_by_id(s.id_employe)
            s_dict['employe_nom'] = employe.nom_complet
        except:
            s_dict['employe_nom'] = "Inconnu"
        result.append(s_dict)

    return BaseController.success(result)


@session_bp.route('/<int:id_session>', methods=['GET'])
@token_required
@handle_errors
def get_session(id_session: int):
    """Récupère une session par son ID."""
    session = session_service.get_session_by_id(id_session)
    s_dict = session.to_dict()
    try:
        employe = employe_service.get_employe_by_id(session.id_employe)
        s_dict['employe_nom'] = employe.nom_complet
    except:
        s_dict['employe_nom'] = "Inconnu"
    return BaseController.success(s_dict)


@session_bp.route('/', methods=['POST'])
@token_required
@handle_errors
def demarrer_session():
    """Démarre une nouvelle session de présence."""
    data = BaseController.get_json_or_400()
    id_employe = data.get('id_employe')
    type_session = data.get('type_session', 'bureau')

    if not id_employe:
        raise ValueError("L'ID employé est obligatoire")

    session = session_service.demarrer_session(id_employe, type_session)
    return BaseController.success(session.to_dict(), "Session démarrée", 201)


@session_bp.route('/<int:id_session>/terminer', methods=['POST'])
@token_required
@handle_errors
def terminer_session(id_session: int):
    """Termine une session de présence."""
    session = session_service.terminer_session(id_session=id_session)
    return BaseController.success(session.to_dict(), "Session terminée")


@session_bp.route('/employe/<int:id_employe>/terminer', methods=['POST'])
@token_required
@handle_errors
def terminer_session_employe(id_employe: int):
    """Termine la session en cours d'un employé."""
    session = session_service.terminer_session(id_employe=id_employe)
    return BaseController.success(session.to_dict(), "Session terminée")


@session_bp.route('/employe/<int:id_employe>/en-cours', methods=['GET'])
@token_required
@handle_errors
def get_session_en_cours(id_employe: int):
    """Récupère la session en cours d'un employé."""
    session = session_service.get_session_en_cours(id_employe)
    if not session:
        return BaseController.error("Aucune session en cours", 404)
    return BaseController.success(session.to_dict())


@session_bp.route('/aujourdhui', methods=['GET'])
@token_required
@handle_errors
def get_sessions_aujourdhui():
    """Récupère les sessions de présence du jour."""
    sessions = session_service.session_dao.get_par_jour(date.today())

    result = []
    for s in sessions:
        s_dict = s.to_dict()
        try:
            employe = employe_service.get_employe_by_id(s.id_employe)
            s_dict['employe_nom'] = employe.nom_complet
        except:
            s_dict['employe_nom'] = "Inconnu"
        result.append(s_dict)

    return BaseController.success(result)


@session_bp.route('/stats', methods=['GET'])
@token_required
@handle_errors
def get_session_stats():
    """Statistiques de présence."""
    employe_id = BaseController.get_int_param('employe_id')
    debut_str = request.args.get('debut')
    fin_str = request.args.get('fin')

    debut = date.fromisoformat(debut_str) if debut_str else None
    fin = date.fromisoformat(fin_str) if fin_str else None

    stats = session_service.get_statistiques_presence(employe_id, debut, fin)
    return BaseController.success(stats)