# app/controllers/uniforme_controller.py
from flask import Blueprint, request
from app.controllers.base_controller import BaseController, handle_errors
from app.services.uniforme_service import UniformeService
from app.services.employe_service import EmployeService
from app.utils.security import token_required, admin_required
from datetime import date

uniforme_bp = Blueprint('uniformes', __name__, url_prefix='/api/uniformes')
uniforme_service = UniformeService()
employe_service = EmployeService()


@uniforme_bp.route('/', methods=['GET'])
@token_required
@handle_errors
def get_all_uniformes():
    """Récupère tous les uniformes."""
    employe_id = BaseController.get_int_param('employe_id')
    couleur = request.args.get('couleur')
    actif = BaseController.get_bool_param('actif', False)

    if employe_id:
        uniformes = uniforme_service.get_uniformes_employe(employe_id)
    elif couleur:
        uniformes = uniforme_service.get_uniformes_par_couleur(couleur)
    elif actif:
        tous = uniforme_service.uniforme_dao.get_all()
        uniformes = [u for u in tous if u.est_actif]
    else:
        uniformes = uniforme_service.uniforme_dao.get_all()

    result = []
    for u in uniformes:
        u_dict = u.to_dict()
        try:
            employe = employe_service.get_employe_by_id(u.id_employe)
            u_dict['employe_nom'] = employe.nom_complet
        except:
            u_dict['employe_nom'] = "Inconnu"
        result.append(u_dict)

    return BaseController.success(result)


@uniforme_bp.route('/<int:id_uniforme>', methods=['GET'])
@token_required
@handle_errors
def get_uniforme(id_uniforme: int):
    """Récupère un uniforme par son ID."""
    uniforme = uniforme_service.get_uniforme_by_id(id_uniforme)
    u_dict = uniforme.to_dict()
    try:
        employe = employe_service.get_employe_by_id(uniforme.id_employe)
        u_dict['employe_nom'] = employe.nom_complet
    except:
        u_dict['employe_nom'] = "Inconnu"
    return BaseController.success(u_dict)


@uniforme_bp.route('/', methods=['POST'])
@admin_required
@handle_errors
def create_uniforme():
    """Crée un nouvel uniforme."""
    data = BaseController.get_json_or_400()
    uniforme = uniforme_service.create_uniforme(data)
    return BaseController.success(uniforme.to_dict(), "Uniforme créé", 201)


@uniforme_bp.route('/<int:id_uniforme>', methods=['PUT'])
@admin_required
@handle_errors
def update_uniforme(id_uniforme: int):
    """Met à jour un uniforme."""
    data = BaseController.get_json_or_400()
    uniforme = uniforme_service.update_uniforme(id_uniforme, data)
    return BaseController.success(uniforme.to_dict(), "Uniforme mis à jour")


@uniforme_bp.route('/<int:id_uniforme>/terminer', methods=['POST'])
@admin_required
@handle_errors
def terminer_uniforme(id_uniforme: int):
    """Termine l'utilisation d'un uniforme."""
    data = request.get_json() or {}
    date_fin_str = data.get('date_fin')
    date_fin = date.fromisoformat(date_fin_str) if date_fin_str else None

    uniforme = uniforme_service.terminer_uniforme(id_uniforme, date_fin)
    return BaseController.success(uniforme.to_dict(), "Uniforme terminé")


@uniforme_bp.route('/employe/<int:id_employe>', methods=['GET'])
@token_required
@handle_errors
def get_uniformes_employe(id_employe: int):
    """Récupère les uniformes d'un employé."""
    uniformes = uniforme_service.get_uniformes_employe(id_employe)
    return BaseController.success([u.to_dict() for u in uniformes])


@uniforme_bp.route('/employe/<int:id_employe>/actuel', methods=['GET'])
@token_required
@handle_errors
def get_uniforme_actuel(id_employe: int):
    """Récupère l'uniforme actuel d'un employé."""
    uniforme = uniforme_service.get_uniforme_actuel(id_employe)
    if not uniforme:
        return BaseController.error("Aucun uniforme actif trouvé", 404)
    return BaseController.success(uniforme.to_dict())


@uniforme_bp.route('/couleur/<couleur>', methods=['GET'])
@token_required
@handle_errors
def get_uniformes_by_couleur(couleur: str):
    """Récupère les uniformes par couleur."""
    uniformes = uniforme_service.get_uniformes_par_couleur(couleur)
    return BaseController.success([u.to_dict() for u in uniformes])