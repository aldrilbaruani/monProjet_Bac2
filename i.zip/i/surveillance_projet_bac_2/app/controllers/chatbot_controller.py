# app/controllers/chatbot_controller.py
from flask import Blueprint, request
from app.controllers.base_controller import BaseController, handle_errors
from app.services.chatbot_service import ChatbotService
from app.services.employe_service import EmployeService
from app.utils.security import token_required

chatbot_bp = Blueprint('chatbot', __name__, url_prefix='/api/chatbot')
chatbot_service = ChatbotService()
employe_service = EmployeService()


@chatbot_bp.route('/commande', methods=['POST'])
@token_required
@handle_errors
def traiter_commande():
    """Traite une commande envoyée au chatbot."""
    data = BaseController.get_json_or_400()
    commande = data.get('commande')
    id_employe = data.get('id_employe')

    if not commande:
        raise ValueError("La commande est obligatoire")
    if not id_employe:
        raise ValueError("L'ID employé est obligatoire")

    employe = employe_service.get_employe_by_id(id_employe)
    resultat = chatbot_service.traiter_commande(commande, id_employe)
    return BaseController.success(resultat, "Commande traitée")


@chatbot_bp.route('/interactions', methods=['GET'])
@token_required
@handle_errors
def get_all_interactions():
    """Récupère toutes les interactions du chatbot."""
    employe_id = BaseController.get_int_param('employe_id')
    limite = BaseController.get_int_param('limite', 100)

    if employe_id:
        interactions = chatbot_service.get_interactions_employe(employe_id)
    else:
        interactions = chatbot_service.get_interactions_recentes(limite)

    return BaseController.success([i.to_dict() for i in interactions])


@chatbot_bp.route('/interactions/<int:id_interaction>', methods=['GET'])
@token_required
@handle_errors
def get_interaction(id_interaction: int):
    """Récupère une interaction par son ID."""
    interaction = chatbot_service.get_interaction_by_id(id_interaction)
    return BaseController.success(interaction.to_dict())


@chatbot_bp.route('/interactions/employe/<int:id_employe>', methods=['GET'])
@token_required
@handle_errors
def get_interactions_employe(id_employe: int):
    """Récupère l'historique des interactions d'un employé."""
    interactions = chatbot_service.get_interactions_employe(id_employe)
    return BaseController.success([i.to_dict() for i in interactions])


@chatbot_bp.route('/interactions/recentes', methods=['GET'])
@token_required
@handle_errors
def get_interactions_recentes():
    """Récupère les interactions récentes."""
    limite = BaseController.get_int_param('limite', 50)
    interactions = chatbot_service.get_interactions_recentes(limite)
    return BaseController.success([i.to_dict() for i in interactions])


@chatbot_bp.route('/interactions/intention/<intention>', methods=['GET'])
@token_required
@handle_errors
def get_interactions_by_intention(intention: str):
    """Récupère les interactions par intention."""
    interactions = chatbot_service.chatbot_dao.get_par_intention(intention)
    return BaseController.success([i.to_dict() for i in interactions])


@chatbot_bp.route('/aide', methods=['GET'])
@handle_errors
def get_aide():
    """Retourne le message d'aide du chatbot."""
    aide = """🤖 Commandes disponibles:
• "signaler un déplacement" - Ex: "Je vais en zone B pour maintenance"
• "mon statut" - Voir votre statut actuel
• "mes alertes" - Voir vos alertes non lues
• "ma présence" - Voir votre temps de présence
• "aide" - Afficher ce message"""
    return BaseController.success({"aide": aide})


@chatbot_bp.route('/deplacement/auto', methods=['POST'])
@token_required
@handle_errors
def creer_deplacement_auto():
    """Crée automatiquement un déplacement à partir d'une commande simplifiée."""
    data = BaseController.get_json_or_400()
    commande = data.get('commande')
    id_employe = data.get('id_employe')
    zone_id = data.get('zone_id')
    motif = data.get('motif')

    if not commande or not id_employe:
        raise ValueError("Commande et ID employé requis")

    resultat = chatbot_service.traiter_commande_deplacement(commande, id_employe, zone_id, motif)
    return BaseController.success(resultat, "Déplacement créé via chatbot", 201)