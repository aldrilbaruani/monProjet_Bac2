# app/controllers/deplacement_controller.py
from flask import Blueprint, request
from app.controllers.base_controller import BaseController, handle_errors
from app.services.deplacement_service import DeplacementService
from app.services.employe_service import EmployeService
from app.utils.security import token_required, admin_required
from datetime import datetime

deplacement_bp = Blueprint('deplacements', __name__, url_prefix='/api/deplacements')
deplacement_service = DeplacementService()
employe_service = EmployeService()


@deplacement_bp.route('/', methods=['GET'])
@token_required
@handle_errors
def get_all_deplacements():
    """Récupère les déplacements avec filtres."""
    statut = request.args.get('statut')
    employe_id = BaseController.get_int_param('employe_id')
    date_debut = request.args.get('date_debut')
    date_fin = request.args.get('date_fin')
    limite = BaseController.get_int_param('limite', 100)

    if employe_id:
        deplacements = deplacement_service.get_deplacements_employe(employe_id)
    elif date_debut and date_fin:
        debut = datetime.fromisoformat(date_debut)
        fin = datetime.fromisoformat(date_fin)
        deplacements = deplacement_service.deplacement_dao.get_par_periode(debut, fin)
    elif statut == 'en_cours':
        deplacements = deplacement_service.get_deplacements_en_cours()
    elif statut == 'en_retard':
        deplacements = deplacement_service.deplacement_dao.get_en_retard()
    else:
        deplacements = deplacement_service.get_deplacements_en_cours()

    deplacements = deplacements[:limite]

    result = []
    for d in deplacements:
        d_dict = d.to_dict()
        try:
            employe = employe_service.get_employe_by_id(d.id_employe)
            d_dict['employe_nom'] = employe.nom_complet
        except:
            d_dict['employe_nom'] = "Inconnu"
        result.append(d_dict)

    return BaseController.success(result)


@deplacement_bp.route('/<int:id_deplacement>', methods=['GET'])
@token_required
@handle_errors
def get_deplacement(id_deplacement: int):
    """Récupère un déplacement par son ID."""
    deplacement = deplacement_service.get_deplacement_by_id(id_deplacement)
    d_dict = deplacement.to_dict()
    try:
        employe = employe_service.get_employe_by_id(deplacement.id_employe)
        d_dict['employe_nom'] = employe.nom_complet
    except:
        d_dict['employe_nom'] = "Inconnu"
    return BaseController.success(d_dict)


@deplacement_bp.route('/employe/<int:id_employe>', methods=['GET'])
@token_required
@handle_errors
def get_deplacements_employe(id_employe: int):
    """Récupère les déplacements d'un employé."""
    statut = request.args.get('statut')
    deplacements = deplacement_service.get_deplacements_employe(id_employe)

    if statut:
        deplacements = [d for d in deplacements if d.statut == statut]

    return BaseController.success([d.to_dict() for d in deplacements])


@deplacement_bp.route('/en-cours', methods=['GET'])
@token_required
@handle_errors
def get_deplacements_en_cours():
    """Récupère tous les déplacements en cours."""
    deplacements = deplacement_service.get_deplacements_en_cours()

    result = []
    for d in deplacements:
        d_dict = d.to_dict()
        try:
            employe = employe_service.get_employe_by_id(d.id_employe)
            d_dict['employe_nom'] = employe.nom_complet
        except:
            d_dict['employe_nom'] = "Inconnu"
        result.append(d_dict)

    return BaseController.success(result)


@deplacement_bp.route('/en-retard', methods=['GET'])
@token_required
@handle_errors
def get_deplacements_en_retard():
    """Récupère les déplacements en retard."""
    deplacements = deplacement_service.deplacement_dao.get_en_retard()

    result = []
    for d in deplacements:
        d_dict = d.to_dict()
        try:
            employe = employe_service.get_employe_by_id(d.id_employe)
            d_dict['employe_nom'] = employe.nom_complet
        except:
            d_dict['employe_nom'] = "Inconnu"
        result.append(d_dict)

    return BaseController.success(result)


@deplacement_bp.route('/', methods=['POST'])
@admin_required
@handle_errors
def create_deplacement():
    """Crée un nouveau déplacement."""
    data = BaseController.get_json_or_400()
    deplacement = deplacement_service.create_deplacement(data)
    return BaseController.success(deplacement.to_dict(), "Déplacement créé avec succès", 201)


@deplacement_bp.route('/<int:id_deplacement>', methods=['PUT'])
@admin_required
@handle_errors
def update_deplacement(id_deplacement: int):
    """Met à jour un déplacement."""
    data = BaseController.get_json_or_400()
    deplacement = deplacement_service.update_deplacement(id_deplacement, data)
    return BaseController.success(deplacement.to_dict(), "Déplacement mis à jour")


@deplacement_bp.route('/<int:id_deplacement>/terminer', methods=['POST'])
@token_required
@handle_errors
def terminer_deplacement(id_deplacement: int):
    """Termine un déplacement."""
    data = request.get_json() or {}
    date_retour_reel = data.get('date_retour_reel')
    if date_retour_reel:
        date_retour_reel = datetime.fromisoformat(date_retour_reel)

    deplacement = deplacement_service.terminer_deplacement(id_deplacement, date_retour_reel)
    return BaseController.success(deplacement.to_dict(), "Déplacement terminé")


@deplacement_bp.route('/<int:id_deplacement>/annuler', methods=['POST'])
@admin_required
@handle_errors
def annuler_deplacement(id_deplacement: int):
    """Annule un déplacement."""
    data = request.get_json() or {}
    motif = data.get('motif')
    deplacement = deplacement_service.annuler_deplacement(id_deplacement, motif)
    return BaseController.success(deplacement.to_dict(), "Déplacement annulé")


@deplacement_bp.route('/verifier-retards', methods=['POST'])
@admin_required
@handle_errors
def verifier_retards():
    """Déclenche la vérification des retards."""
    retards = deplacement_service.verifier_retards()
    return BaseController.success(retards, f"{len(retards)} déplacements en retard traités")


@deplacement_bp.route('/stats', methods=['GET'])
@admin_required
@handle_errors
def get_deplacement_stats():
    """Statistiques sur les déplacements."""
    stats = deplacement_service.get_statistiques()
    return BaseController.success(stats)


@deplacement_bp.route('/du-jour', methods=['GET'])
@token_required
@handle_errors
def get_deplacements_du_jour():
    """Récupère les déplacements du jour."""
    deplacements = deplacement_service.get_deplacements_du_jour()
    return BaseController.success([d.to_dict() for d in deplacements])


@deplacement_bp.route('/periode', methods=['GET'])
@token_required
@handle_errors
def get_deplacements_periode():
    """Récupère les déplacements sur une période."""
    debut_str = request.args.get('debut')
    fin_str = request.args.get('fin')

    if not debut_str or not fin_str:
        raise ValueError("Les paramètres 'debut' et 'fin' sont requis")

    debut = datetime.fromisoformat(debut_str)
    fin = datetime.fromisoformat(fin_str)

    deplacements = deplacement_service.deplacement_dao.get_par_periode(debut, fin)

    result = []
    for d in deplacements:
        d_dict = d.to_dict()
        try:
            employe = employe_service.get_employe_by_id(d.id_employe)
            d_dict['employe_nom'] = employe.nom_complet
        except:
            d_dict['employe_nom'] = "Inconnu"
        result.append(d_dict)

    return BaseController.success(result)