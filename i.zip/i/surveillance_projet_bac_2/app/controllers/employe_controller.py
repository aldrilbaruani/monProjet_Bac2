# app/controllers/employe_controller.py
from flask import Blueprint, request
from app.controllers.base_controller import BaseController, handle_errors
from app.services.employe_service import EmployeService
from app.services.deplacement_service import DeplacementService
from app.utils.security import token_required, admin_required

employe_bp = Blueprint('employes', __name__, url_prefix='/api/employes')
employe_service = EmployeService()
deplacement_service = DeplacementService()


@employe_bp.route('/', methods=['GET'])
@token_required
@handle_errors
def get_all_employes():
    """Récupère tous les employés."""
    actifs_only = BaseController.get_bool_param('actifs_only', True)
    role = request.args.get('role')
    search_term = request.args.get('search')

    employes = employe_service.get_all_employes(actifs_only)

    if role:
        employes = [e for e in employes if e.role == role]
    if search_term:
        employes = [e for e in employes if
                    search_term.lower() in e.nom.lower() or
                    search_term.lower() in e.prenom.lower() or
                    search_term.lower() in e.email.lower()]

    return BaseController.success([e.to_dict() for e in employes])


@employe_bp.route('/<int:id_employe>', methods=['GET'])
@token_required
@handle_errors
def get_employe(id_employe: int):
    """Récupère un employé par son ID."""
    employe = employe_service.get_employe_by_id(id_employe)
    return BaseController.success(employe.to_dict())


@employe_bp.route('/email/<email>', methods=['GET'])
@token_required
@handle_errors
def get_employe_by_email(email: str):
    """Récupère un employé par son email."""
    employe = employe_service.get_employe_by_email(email)
    if not employe:
        return BaseController.error("Employé non trouvé", 404)
    return BaseController.success(employe.to_dict())


@employe_bp.route('/', methods=['POST'])
@admin_required
@handle_errors
def create_employe():
    """Crée un nouvel employé."""
    data = BaseController.get_json_or_400()
    employe = employe_service.create_employe(data)
    return BaseController.success(employe.to_dict(), "Employé créé avec succès", 201)


@employe_bp.route('/<int:id_employe>', methods=['PUT'])
@admin_required
@handle_errors
def update_employe(id_employe: int):
    """Met à jour un employé."""
    data = BaseController.get_json_or_400()
    employe = employe_service.update_employe(id_employe, data)
    return BaseController.success(employe.to_dict(), "Employé mis à jour avec succès")


@employe_bp.route('/<int:id_employe>', methods=['DELETE'])
@admin_required
@handle_errors
def delete_employe(id_employe: int):
    """Supprime ou désactive un employé."""
    soft_delete = BaseController.get_bool_param('soft_delete', True)
    result = employe_service.delete_employe(id_employe, soft_delete)
    return BaseController.success(result, result['message'])


@employe_bp.route('/search', methods=['GET'])
@token_required
@handle_errors
def search_employes():
    """Recherche des employés par nom, prénom ou email."""
    terme = BaseController.get_str_param('q', '')
    if not terme:
        return BaseController.success([])
    employes = employe_service.search_employes(terme)
    return BaseController.success([e.to_dict() for e in employes])


@employe_bp.route('/<int:id_employe>/deplacements', methods=['GET'])
@token_required
@handle_errors
def get_employe_deplacements(id_employe: int):
    """Récupère les déplacements d'un employé."""
    statut = request.args.get('statut')
    deplacements = deplacement_service.get_deplacements_employe(id_employe)

    if statut:
        deplacements = [d for d in deplacements if d.statut == statut]

    return BaseController.success([d.to_dict() for d in deplacements])


@employe_bp.route('/<int:id_employe>/presence', methods=['GET'])
@token_required
@handle_errors
def get_employe_presence(id_employe: int):
    """Récupère la présence actuelle d'un employé."""
    from app.services.session_presence_service import SessionPresenceService
    presence_service = SessionPresenceService()
    session = presence_service.get_session_en_cours(id_employe)

    if session:
        return BaseController.success(session.to_dict())
    return BaseController.success(None, "Employé non présent")


@employe_bp.route('/stats', methods=['GET'])
@admin_required
@handle_errors
def get_employes_stats():
    """Statistiques sur les employés."""
    stats = employe_service.get_statistiques()
    return BaseController.success(stats)


@employe_bp.route('/by-role/<role>', methods=['GET'])
@token_required
@handle_errors
def get_employes_by_role(role: str):
    """Récupère les employés par rôle."""
    employes = employe_service.get_employes_by_role(role)
    return BaseController.success([e.to_dict() for e in employes])