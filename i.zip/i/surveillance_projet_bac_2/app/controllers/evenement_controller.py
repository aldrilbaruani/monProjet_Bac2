# app/controllers/evenement_controller.py
from flask import Blueprint, request
from app.controllers.base_controller import BaseController, handle_errors
from app.services.evenement_service import EvenementService
from app.services.camera_service import CameraService
from app.utils.security import token_required, admin_required
from datetime import datetime

evenement_bp = Blueprint('evenements', __name__, url_prefix='/api/evenements')
evenement_service = EvenementService()
camera_service = CameraService()


@evenement_bp.route('/', methods=['GET'])
@token_required
@handle_errors
def get_all_evenements():
    """Récupère les événements avec filtres."""
    camera_id = BaseController.get_int_param('camera_id')
    type_evenement = request.args.get('type')
    date_debut = request.args.get('date_debut')
    date_fin = request.args.get('date_fin')
    limite = BaseController.get_int_param('limite', 100)

    if camera_id:
        evenements = evenement_service.get_evenements_par_camera(camera_id, limite)
    elif date_debut and date_fin:
        debut = datetime.fromisoformat(date_debut)
        fin = datetime.fromisoformat(date_fin)
        evenements = evenement_service.get_evenements_par_periode(debut, fin)
    else:
        evenements = evenement_service.get_evenements_recents(limite)

    if type_evenement:
        evenements = [e for e in evenements if e.type_evenement == type_evenement]

    result = []
    for e in evenements:
        e_dict = e.to_dict()
        try:
            camera = camera_service.get_camera_by_id(e.id_camera)
            e_dict['camera_nom'] = camera.nom_camera
        except:
            e_dict['camera_nom'] = "Inconnue"
        result.append(e_dict)

    return BaseController.success(result)


@evenement_bp.route('/<int:id_evenement>', methods=['GET'])
@token_required
@handle_errors
def get_evenement(id_evenement: int):
    """Récupère un événement par son ID."""
    evenement = evenement_service.get_evenement_by_id(id_evenement)
    e_dict = evenement.to_dict()
    try:
        camera = camera_service.get_camera_by_id(evenement.id_camera)
        e_dict['camera_nom'] = camera.nom_camera
    except:
        e_dict['camera_nom'] = "Inconnue"
    return BaseController.success(e_dict)


@evenement_bp.route('/recents', methods=['GET'])
@token_required
@handle_errors
def get_evenements_recents():
    """Récupère les événements récents."""
    limite = BaseController.get_int_param('limite', 100)
    evenements = evenement_service.get_evenements_recents(limite)

    result = []
    for e in evenements:
        e_dict = e.to_dict()
        try:
            camera = camera_service.get_camera_by_id(e.id_camera)
            e_dict['camera_nom'] = camera.nom_camera
        except:
            e_dict['camera_nom'] = "Inconnue"
        result.append(e_dict)

    return BaseController.success(result)


@evenement_bp.route('/camera/<int:id_camera>', methods=['GET'])
@token_required
@handle_errors
def get_evenements_par_camera(id_camera: int):
    """Récupère les événements d'une caméra."""
    limite = BaseController.get_int_param('limite', 100)
    evenements = evenement_service.get_evenements_par_camera(id_camera, limite)

    result = []
    for e in evenements:
        e_dict = e.to_dict()
        try:
            camera = camera_service.get_camera_by_id(e.id_camera)
            e_dict['camera_nom'] = camera.nom_camera
        except:
            e_dict['camera_nom'] = "Inconnue"
        result.append(e_dict)

    return BaseController.success(result)


@evenement_bp.route('/periode', methods=['GET'])
@token_required
@handle_errors
def get_evenements_par_periode():
    """Récupère les événements sur une période."""
    debut_str = request.args.get('debut')
    fin_str = request.args.get('fin')

    if not debut_str or not fin_str:
        raise ValueError("Les paramètres 'debut' et 'fin' sont requis")

    debut = datetime.fromisoformat(debut_str)
    fin = datetime.fromisoformat(fin_str)

    evenements = evenement_service.get_evenements_par_periode(debut, fin)

    result = []
    for e in evenements:
        e_dict = e.to_dict()
        try:
            camera = camera_service.get_camera_by_id(e.id_camera)
            e_dict['camera_nom'] = camera.nom_camera
        except:
            e_dict['camera_nom'] = "Inconnue"
        result.append(e_dict)

    return BaseController.success(result)


@evenement_bp.route('/', methods=['POST'])
@admin_required
@handle_errors
def create_evenement():
    """Crée un nouvel événement."""
    data = BaseController.get_json_or_400()
    evenement = evenement_service.create_evenement(data)
    return BaseController.success(evenement.to_dict(), "Événement créé", 201)


@evenement_bp.route('/batch', methods=['POST'])
@admin_required
@handle_errors
def create_evenements_batch():
    """Crée plusieurs événements en une requête."""
    data = BaseController.get_json_or_400()
    if not isinstance(data, list):
        raise ValueError("Les données doivent être une liste d'événements")

    evenements = evenement_service.create_evenements_batch(data)
    return BaseController.success([e.to_dict() for e in evenements], f"{len(evenements)} événements créés", 201)


@evenement_bp.route('/<int:id_evenement>/analyser', methods=['POST'])
@token_required
@handle_errors
def analyser_evenement(id_evenement: int):
    """Lance l'analyse IA sur un événement."""
    from app.services.analyse_comportementale_service import AnalyseComportementaleService
    analyse_service = AnalyseComportementaleService()
    resultat = analyse_service.analyser_evenement(id_evenement)
    return BaseController.success(resultat, "Analyse terminée")


@evenement_bp.route('/stats/journalieres', methods=['GET'])
@token_required
@handle_errors
def get_stats_journalieres():
    """Statistiques journalières des événements."""
    jours = BaseController.get_int_param('jours', 7)
    stats = evenement_service.get_statistiques_par_jour(jours)
    return BaseController.success(stats)


@evenement_bp.route('/activite/heures', methods=['GET'])
@token_required
@handle_errors
def get_activite_par_heure():
    """Activité des événements par heure (dernières 24h)."""
    activite = evenement_service.get_activite_par_heure()
    return BaseController.success(activite)


@evenement_bp.route('/type/<type_evenement>', methods=['GET'])
@token_required
@handle_errors
def get_evenements_by_type(type_evenement: str):
    """Récupère les événements par type."""
    limite = BaseController.get_int_param('limite', 100)
    evenements = evenement_service.evenement_dao.get_by_type(type_evenement, limite)
    return BaseController.success([e.to_dict() for e in evenements])