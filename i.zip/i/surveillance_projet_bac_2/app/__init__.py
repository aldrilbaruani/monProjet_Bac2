# app/__init__.py
from flask import Flask, send_from_directory
import os
import sys

# Ajouter les chemins
current_dir = os.path.dirname(os.path.abspath(__file__))
parent_dir = os.path.dirname(current_dir)
if parent_dir not in sys.path:
    sys.path.insert(0, parent_dir)
if current_dir not in sys.path:
    sys.path.insert(0, current_dir)


def create_app():
    """Crée et configure l'application Flask."""
    static_folder = os.path.abspath(os.path.join(os.path.dirname(__file__), '../static'))
    app = Flask(__name__, static_folder=static_folder, static_url_path='')

    # Charger la configuration
    app.config.from_object('config.Config')
    print(f"✅ Dossier static configuré: {static_folder}")

    # Route pour la racine
    @app.route('/')
    def index():
        return send_from_directory(static_folder, 'index.html')

    # Route pour servir tous les fichiers statiques
    @app.route('/<path:path>')
    def serve_static(path):
        return send_from_directory(static_folder, path)

    # Route API de test simple
    @app.route('/api/test', methods=['GET'])
    def api_test():
        return {"success": True, "message": "API fonctionnelle !"}

    # Route API de login (simplifiée pour test)
    @app.route('/api/auth/login', methods=['POST'])
    def api_login():
        from flask import request, jsonify

        data = request.get_json() or {}
        email = data.get('email')
        password = data.get('password')

        # Simulation simple pour test
        if email == 'superadmin@securite.com' and password == 'admin123':
            return jsonify({
                "success": True,
                "message": "Connexion réussie",
                "data": {
                    "token": "fake-token-123",
                    "employe": {
                        "id_employe": 1,
                        "nom": "Admin",
                        "prenom": "Super",
                        "email": email,
                        "role": "super_admin"
                    }
                }
            }), 200
        else:
            return jsonify({
                "success": False,
                "message": "Email ou mot de passe incorrect"
            }), 401

    # Essayer d'importer les blueprints réels (optionnel)
    try:
        from app.controllers import register_blueprints
        register_blueprints(app)
        print("✅ Blueprints réels enregistrés")
    except Exception as e:
        print(f"⚠️ Blueprints réels non chargés: {e}")
        print("   Utilisation des routes de test simplifiées")

    return app