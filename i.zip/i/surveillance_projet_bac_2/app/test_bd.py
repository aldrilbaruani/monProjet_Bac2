# test_db.py

import mysql.connector
import sys
import os

# Ajouter le chemin parent
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))

try:
    from config import Config
except ImportError:
    # Configuration par défaut
    class Config:
        DB_HOST = 'localhost'
        DB_USER = 'root'
        DB_PASSWORD = ''
        DB_NAME = 'surveillance_ia_projet'

def test_connection():
    """Teste la connexion à la base."""
    try:
        conn = mysql.connector.connect(
            host=Config.DB_HOST,
            user=Config.DB_USER,
            password=Config.DB_PASSWORD,
            database=Config.DB_NAME
        )
        print(f"✅ Connexion réussie à {Config.DB_NAME}")
        return conn
    except mysql.connector.Error as err:
        print(f"❌ Erreur: {err}")
        return None

if __name__ == '__main__':
    conn = test_connection()
    if conn:
        conn.close()