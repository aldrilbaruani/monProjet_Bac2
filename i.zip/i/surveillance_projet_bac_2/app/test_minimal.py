# test_minimal.py

import sys
import os
import random

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))

from app.dao.employe_dao import EmployeDAO
from app.models.Employe import Employe
from datetime import datetime


def test_minimal():
    dao = EmployeDAO()

    # Générer un email unique
    unique_id = random.randint(10000, 99999)
    email = f"minimal_{unique_id}@test.com"

    # Créer un employé avec tous les champs nécessaires
    employe = Employe(
        nom="Minimal",
        prenom="Test",
        poste="Testeur",
        email=email,  # ← EMAIL UNIQUE
        date_embauche=datetime.now(),
        telephone="0123456789",
        photo_principale=None,
        role="employe",
        actif=True
    )
    employe.set_mot_de_passe("Test123!")

    print(f"🔍 Email: {employe.email}")
    print(f"🔍 Mot de passe hashé: {employe.mot_de_passe is not None}")

    try:
        id_emp = dao.create(employe)
        print(f"✅ ID créé: {id_emp}")

        if id_emp:
            emp = dao.get_by_id(id_emp)
            print(f"✅ Employé trouvé: {emp.nom} {emp.prenom}")
            dao.delete(id_emp)
            print("✅ Suppression OK")
        else:
            print("❌ ID = 0, insertion échouée")
    except Exception as e:
        print(f"❌ Erreur: {e}")


if __name__ == "__main__":
    test_minimal()