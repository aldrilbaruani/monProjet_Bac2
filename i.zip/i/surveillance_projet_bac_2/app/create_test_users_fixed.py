# create_test_users_fixed.py

import sys
import os
import mysql.connector

current_dir = os.path.dirname(os.path.abspath(__file__))
project_root = current_dir  # app/ est la racine
parent_dir = os.path.dirname(current_dir)

# Ajouter les chemins nécessaires
if project_root not in sys.path:
    sys.path.insert(0, project_root)
if parent_dir not in sys.path:
    sys.path.insert(0, parent_dir)

print(f" Dossier courant: {current_dir}")
print(f" Racine projet: {project_root}")
print(f" Dossier parent: {parent_dir}")

# Importer la configuration
try:
    from config import Config

    print(" Config importée")
except ImportError as e:
    print(f" Erreur import config: {e}")


    # Configuration manuelle
    class Config:
        DB_HOST = 'localhost'
        DB_USER = 'root'
        DB_PASSWORD = ''
        DB_NAME = 'surveillance_ia_projet'


    print(" Utilisation configuration par défaut")

# Importer security
try:
    from app.utils.security import hash_password

    print(" Security importée")
except ImportError as e:
    print(f" Erreur import security: {e}")

    # Fonction de hash simple (pour test uniquement)
    import bcrypt


    def hash_password(password):
        salt = bcrypt.gensalt()
        return bcrypt.hashpw(password.encode('utf-8'), salt).decode('utf-8')


    print(" Utilisation fonction de hash directe")


def create_test_users():
    """Crée des utilisateurs de test dans la base."""
    print("\n" + "=" * 60)
    print(" CRÉATION DES UTILISATEURS DE TEST")
    print("=" * 60)

    try:
        conn = mysql.connector.connect(
            host=Config.DB_HOST,
            user=Config.DB_USER,
            password=Config.DB_PASSWORD,
            database=Config.DB_NAME
        )
        cursor = conn.cursor(dictionary=True)
        print(" Connexion à la base établie")
    except mysql.connector.Error as err:
        print(f" Erreur de connexion: {err}")
        return

    test_users = [
        {
            'nom': 'Admin',
            'prenom': 'Super',
            'poste': 'Super Administrateur',
            'email': 'superadmin@securite.com',
            'telephone': '0123456789',
            'date_embauche': '2020-01-01',
            'role': 'super_admin',
            'password': 'admin123'
        },
        {
            'nom': 'Admin',
            'prenom': 'Simple',
            'poste': 'Administrateur',
            'email': 'admin@securite.com',
            'telephone': '0123456788',
            'date_embauche': '2021-01-01',
            'role': 'admin',
            'password': 'admin123'
        },
        {
            'nom': 'Dupont',
            'prenom': 'Jean',
            'poste': 'Agent de sécurité',
            'email': 'jean.dupont@securite.com',
            'telephone': '0123456787',
            'date_embauche': '2022-01-01',
            'role': 'employe',
            'password': 'employe123'
        },
        {
            'nom': 'Martin',
            'prenom': 'Marie',
            'poste': 'Agent de sécurité',
            'email': 'marie.martin@securite.com',
            'telephone': '0123456786',
            'date_embauche': '2022-06-01',
            'role': 'employe',
            'password': 'employe123'
        }
    ]

    created = 0
    for user in test_users:

        cursor.execute("SELECT id_employe FROM employe WHERE email = %s", (user['email'],))
        existing = cursor.fetchone()

        if existing:
            print(f" {user['email']} existe déjà (ID: {existing['id_employe']})")
            continue


        hashed_password = hash_password(user['password'])


        query = """
        INSERT INTO employe 
        (nom, prenom, poste, email, telephone, date_embauche, role, mot_de_passe, actif)
        VALUES (%s, %s, %s, %s, %s, %s, %s, %s, %s)
        """
        values = (
            user['nom'],
            user['prenom'],
            user['poste'],
            user['email'],
            user['telephone'],
            user['date_embauche'],
            user['role'],
            hashed_password,
            True
        )

        cursor.execute(query, values)
        user_id = cursor.lastrowid
        print(f" Utilisateur créé: {user['email']} (ID: {user_id}) - Mot de passe: {user['password']}")
        created += 1

    conn.commit()
    cursor.close()
    conn.close()

    print("\n" + "=" * 60)
    print(f" {created} utilisateurs créés")
    print("=" * 60)

    return created


if __name__ == '__main__':
    create_test_users()