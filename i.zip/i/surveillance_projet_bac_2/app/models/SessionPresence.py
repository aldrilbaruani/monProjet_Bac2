from datetime import datetime
from typing import Optional

class SessionPresence:


    TYPES_SESSION = ['bureau', 'externe', 'teletravail']

    def __init__(
        self,
        debut: datetime,
        id_employe: int,
        fin: Optional[datetime] = None,
        type_session: str = 'bureau',
        id_session: Optional[int] = None
    ):
        if not debut:
            raise ValueError("La date de début est obligatoire")
        if not id_employe:
            raise ValueError("L'ID employé est obligatoire")
        if type_session not in self.TYPES_SESSION:
            raise ValueError(f"Type de session invalide. Choisissez parmi {self.TYPES_SESSION}")

        self._id_session = id_session
        self._debut = debut
        self._fin = fin
        self._id_employe = id_employe
        self._type_session = type_session

    # --- Propriétés ---

    @property
    def id_session(self) -> Optional[int]:
        return self._id_session

    @id_session.setter
    def id_session(self, valeur: int):
        if valeur is not None and valeur <= 0:
            raise ValueError("L'ID session doit être positif")
        self._id_session = valeur

    @property
    def debut(self) -> datetime:
        return self._debut

    @debut.setter
    def debut(self, valeur: datetime):
        if not valeur:
            raise ValueError("La date de début est obligatoire")
        self._debut = valeur

    @property
    def fin(self) -> Optional[datetime]:
        return self._fin

    @fin.setter
    def fin(self, valeur: Optional[datetime]):
        if valeur and self._debut and valeur < self._debut:
            raise ValueError("La date de fin ne peut pas être antérieure au début")
        self._fin = valeur

    @property
    def id_employe(self) -> int:
        return self._id_employe

    @id_employe.setter
    def id_employe(self, valeur: int):
        if not valeur:
            raise ValueError("L'ID employé est obligatoire")
        self._id_employe = valeur

    @property
    def type_session(self) -> str:
        return self._type_session

    @type_session.setter
    def type_session(self, valeur: str):
        if valeur not in self.TYPES_SESSION:
            raise ValueError(f"Type de session invalide. Choisissez parmi {self.TYPES_SESSION}")
        self._type_session = valeur

    # --- Propriétés calculées ---

    @property
    def est_active(self) -> bool:
        return self._fin is None

    @property
    def duree(self) -> Optional[float]:
        fin = self._fin or datetime.now()
        delta = fin - self._debut
        return round(delta.total_seconds() / 3600, 2)

    @property
    def duree_secondes(self) -> Optional[int]:
        fin = self._fin or datetime.now()
        return int((fin - self._debut).total_seconds())

    @property
    def est_longue(self) -> bool:
        return self.duree is not None and self.duree > 8

    def terminer(self):
        self._fin = datetime.now()

    def to_dict(self) -> dict:
        return {
            'id_session': self._id_session,
            'debut': self._debut.isoformat() if self._debut else None,
            'fin': self._fin.isoformat() if self._fin else None,
            'id_employe': self._id_employe,
            'type_session': self._type_session,
            'est_active': self.est_active,
            'duree': self.duree
        }

    def __repr__(self) -> str:
        status = "🟢" if self.est_active else "⚫"
        return f"<Session {self._id_session} {status} Employé {self._id_employe}>"