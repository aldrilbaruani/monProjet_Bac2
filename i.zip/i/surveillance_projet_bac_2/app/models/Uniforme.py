# app/models/Uniforme.py
from datetime import date
from typing import Optional

class Uniforme:
    """ Modèle correspondant à la table 'uniforme'. """

    def __init__(
        self,
        couleur_dominante: str,
        type_tenue: str,
        date_debut: date,
        id_employe: int,
        date_fin: Optional[date] = None,
        id_uniforme: Optional[int] = None
    ):
        if not couleur_dominante:
            raise ValueError("La couleur dominante est obligatoire")
        if not type_tenue:
            raise ValueError("Le type de tenue est obligatoire")
        if not date_debut:
            raise ValueError("La date de début est obligatoire")
        if not id_employe:
            raise ValueError("L'ID employé est obligatoire")

        self._id_uniforme = id_uniforme
        self._couleur_dominante = couleur_dominante
        self._type_tenue = type_tenue
        self._date_debut = date_debut
        self._date_fin = date_fin
        self._id_employe = id_employe

    # ===== PROPRIÉTÉS =====

    @property
    def id_uniforme(self) -> Optional[int]:
        return self._id_uniforme

    @id_uniforme.setter
    def id_uniforme(self, valeur: int):
        if valeur is not None and valeur <= 0:
            raise ValueError("L'ID uniforme doit être positif")
        self._id_uniforme = valeur

    @property
    def couleur_dominante(self) -> str:
        return self._couleur_dominante

    @couleur_dominante.setter
    def couleur_dominante(self, valeur: str):
        if not valeur:
            raise ValueError("La couleur dominante est obligatoire")
        self._couleur_dominante = valeur

    @property
    def type_tenue(self) -> str:
        return self._type_tenue

    @type_tenue.setter
    def type_tenue(self, valeur: str):
        if not valeur:
            raise ValueError("Le type de tenue est obligatoire")
        self._type_tenue = valeur

    @property
    def date_debut(self) -> date:
        return self._date_debut

    @date_debut.setter
    def date_debut(self, valeur: date):
        if not valeur:
            raise ValueError("La date de début est obligatoire")
        self._date_debut = valeur

    @property
    def date_fin(self) -> Optional[date]:
        return self._date_fin

    @date_fin.setter
    def date_fin(self, valeur: Optional[date]):
        if valeur and self._date_debut and valeur < self._date_debut:
            raise ValueError("La date de fin ne peut pas être antérieure à la date de début")
        self._date_fin = valeur

    @property
    def id_employe(self) -> int:
        return self._id_employe

    @id_employe.setter
    def id_employe(self, valeur: int):
        if not valeur:
            raise ValueError("L'ID employé est obligatoire")
        self._id_employe = valeur

    # ===== PROPRIÉTÉS CALCULÉES =====

    @property
    def est_actif(self) -> bool:
        """
        Un uniforme est actif si :
        - date_fin est NULL (toujours utilisé)
        - OU date_fin > aujourd'hui (date de fin dans le futur)
        """
        if self._date_fin is None:
            return True
        # ✅ Si date_fin == aujourd'hui, l'uniforme est terminé → inactif
        return self._date_fin > date.today()

    @property
    def duree_utilisation(self) -> Optional[int]:
        if self._date_debut is None:
            return None
        fin = self._date_fin or date.today()
        return (fin - self._date_debut).days

    # ===== MÉTHODES =====

    def terminer(self):
        """Termine l'utilisation de l'uniforme aujourd'hui."""
        self._date_fin = date.today()

    def to_dict(self) -> dict:
        return {
            'id_uniforme': self._id_uniforme,
            'couleur_dominante': self._couleur_dominante,
            'type_tenue': self._type_tenue,
            'date_debut': self._date_debut.isoformat() if self._date_debut else None,
            'date_fin': self._date_fin.isoformat() if self._date_fin else None,
            'id_employe': self._id_employe,
            'est_actif': self.est_actif,
            'duree_utilisation': self.duree_utilisation
        }

    def __repr__(self) -> str:
        return f"<Uniforme {self._id_uniforme} - {self._type_tenue} ({self._couleur_dominante})>"