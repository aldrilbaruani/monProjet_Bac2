# app/models/Employe.py
from datetime import datetime, date
from typing import Optional

class Employe:
    ROLES_VALIDES = ['super_admin', 'admin', 'employe']

    def __init__(
        self,
        nom: str,
        prenom: str,
        poste: str,
        email: str,
        date_embauche: Optional[datetime] = None,
        telephone: Optional[str] = None,
        photo_principale: Optional[str] = None,
        mot_de_passe: Optional[str] = None,
        role: str = "employe",
        actif: bool = True,
        id_employe: Optional[int] = None,
        date_creation: Optional[datetime] = None,
        date_modification: Optional[datetime] = None
    ):
        # Validations
        if not nom:
            raise ValueError("Le nom est obligatoire")
        if not prenom:
            raise ValueError("Le prénom est obligatoire")
        if not poste:
            raise ValueError("Le poste est obligatoire")
        if not email:
            raise ValueError("L'email est obligatoire")
        if '@' not in email:
            raise ValueError("Format d'email invalide")
        if role not in self.ROLES_VALIDES:
            raise ValueError(f"Rôle invalide. Choisissez parmi {self.ROLES_VALIDES}")

        # Utiliser les setters
        self.id_employe = id_employe
        self.nom = nom
        self.prenom = prenom
        self.poste = poste
        self.email = email
        self.telephone = telephone
        self.date_embauche = date_embauche
        self.photo_principale = photo_principale
        self.mot_de_passe = mot_de_passe
        self.role = role
        self.actif = actif
        self.date_creation = date_creation
        self.date_modification = date_modification

    # ===== PROPRIÉTÉS =====

    @property
    def id_employe(self) -> Optional[int]:
        return self._id_employe

    @id_employe.setter
    def id_employe(self, valeur: int):
        if valeur is not None and valeur <= 0:
            raise ValueError("L'ID employé doit être positif")
        self._id_employe = valeur

    @property
    def nom(self) -> str:
        return self._nom

    @nom.setter
    def nom(self, valeur: str):
        if not valeur or len(valeur.strip()) < 2:
            raise ValueError("Le nom doit contenir au moins 2 caractères")
        self._nom = valeur.strip()

    @property
    def prenom(self) -> str:
        return self._prenom

    @prenom.setter
    def prenom(self, valeur: str):
        if not valeur or len(valeur.strip()) < 2:
            raise ValueError("Le prénom doit contenir au moins 2 caractères")
        self._prenom = valeur.strip()

    @property
    def poste(self) -> str:
        return self._poste

    @poste.setter
    def poste(self, valeur: str):
        if not valeur:
            raise ValueError("Le poste est obligatoire")
        self._poste = valeur

    @property
    def email(self) -> str:
        return self._email

    @email.setter
    def email(self, valeur: str):
        if not valeur or '@' not in valeur:
            raise ValueError("Format d'email invalide")
        self._email = valeur

    @property
    def telephone(self) -> Optional[str]:
        return self._telephone

    @telephone.setter
    def telephone(self, valeur: Optional[str]):
        self._telephone = valeur

    @property
    def date_embauche(self) -> Optional[datetime]:
        return self._date_embauche

    @date_embauche.setter
    def date_embauche(self, valeur):
        """Convertit automatiquement les dates en datetime."""
        if valeur is None:
            self._date_embauche = None
        elif isinstance(valeur, datetime):
            self._date_embauche = valeur
        elif isinstance(valeur, date):
            self._date_embauche = datetime.combine(valeur, datetime.min.time())
        elif isinstance(valeur, str):
            # ✅ Convertir une chaîne ISO en datetime
            try:
                # Essayer avec format ISO complet
                self._date_embauche = datetime.fromisoformat(valeur)
            except ValueError:
                # Essayer avec format date seulement
                try:
                    self._date_embauche = datetime.strptime(valeur, "%Y-%m-%d")
                except ValueError:
                    raise ValueError(f"Format de date invalide: {valeur}")
        else:
            raise ValueError(f"Format de date invalide: {type(valeur)}")

    @property
    def photo_principale(self) -> Optional[str]:
        return self._photo_principale

    @photo_principale.setter
    def photo_principale(self, valeur: Optional[str]):
        self._photo_principale = valeur

    @property
    def mot_de_passe(self) -> Optional[str]:
        return self._mot_de_passe

    @mot_de_passe.setter
    def mot_de_passe(self, valeur: Optional[str]):
        self._mot_de_passe = valeur

    def set_mot_de_passe(self, mot_de_passe_clair: str):
        """Hache et stocke le mot de passe."""
        if not mot_de_passe_clair or len(mot_de_passe_clair) < 6:
            raise ValueError("Le mot de passe doit contenir au moins 6 caractères")
        from app.utils.security import hash_password
        self._mot_de_passe = hash_password(mot_de_passe_clair)

    def verifier_mot_de_passe(self, mot_de_passe_clair: str) -> bool:
        """Vérifie le mot de passe fourni."""
        if not self._mot_de_passe:
            return False
        from app.utils.security import verify_password
        return verify_password(mot_de_passe_clair, self._mot_de_passe)

    @property
    def role(self) -> str:
        return self._role

    @role.setter
    def role(self, valeur: str):
        if valeur not in self.ROLES_VALIDES:
            raise ValueError(f"Rôle invalide. Choisissez parmi {self.ROLES_VALIDES}")
        self._role = valeur

    @property
    def actif(self) -> bool:
        return self._actif

    @actif.setter
    def actif(self, valeur: bool):
        self._actif = valeur

    @property
    def date_creation(self) -> Optional[datetime]:
        return self._date_creation

    @date_creation.setter
    def date_creation(self, valeur: Optional[datetime]):
        self._date_creation = valeur

    @property
    def date_modification(self) -> Optional[datetime]:
        return self._date_modification

    @date_modification.setter
    def date_modification(self, valeur: Optional[datetime]):
        self._date_modification = valeur

    # ===== PROPRIÉTÉS CALCULÉES =====

    @property
    def nom_complet(self) -> str:
        return f"{self._prenom} {self._nom}".strip()

    @property
    def anciennete(self) -> Optional[int]:
        if not self._date_embauche:
            return None
        return (datetime.now() - self._date_embauche).days // 365

    @property
    def est_super_admin(self) -> bool:
        return self._role == 'super_admin'

    @property
    def est_admin(self) -> bool:
        return self._role in ('super_admin', 'admin')

    # ===== MÉTHODES =====

    def to_dict(self) -> dict:
        return {
            'id_employe': self._id_employe,
            'nom': self._nom,
            'prenom': self._prenom,
            'nom_complet': self.nom_complet,
            'poste': self._poste,
            'email': self._email,
            'telephone': self._telephone,
            'date_embauche': self._date_embauche.isoformat() if self._date_embauche else None,
            'photo_principale': self._photo_principale,
            'role': self._role,
            'actif': self._actif,
            'anciennete': self.anciennete,
            'date_creation': self._date_creation.isoformat() if self._date_creation else None,
            'date_modification': self._date_modification.isoformat() if self._date_modification else None
        }

    def __repr__(self) -> str:
        return f"<Employe {self.nom_complet} ({self._role})>"