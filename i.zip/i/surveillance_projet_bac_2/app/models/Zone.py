# app/models/Zone.py

from typing import Optional, Any
from datetime import datetime

class Zone:
    """
    Modèle correspondant à la table 'zone'.
    """

    TYPES_VALIDES = ['publique', 'restreinte', 'sensible', 'interdite']

    def __init__(
        self,
        nom_zone: str,
        type_zone: str,
        description: Optional[str] = None,
        niveau_acces: int = 1,
        coordonnees: Optional[dict] = None,
        id_zone: Optional[int] = None,
        date_creation: Optional[datetime] = None
    ):
        if not nom_zone:
            raise ValueError("Le nom de la zone est obligatoire")
        if type_zone not in self.TYPES_VALIDES:
            raise ValueError(f"Type de zone invalide. Choisissez parmi {self.TYPES_VALIDES}")
        if niveau_acces < 1 or niveau_acces > 5:
            raise ValueError("Le niveau d'accès doit être entre 1 et 5")

        self._id_zone = id_zone
        self._nom_zone = nom_zone
        self._type_zone = type_zone
        self._description = description
        self._niveau_acces = niveau_acces
        self._coordonnees = coordonnees or {}
        self._date_creation = date_creation

    # --- Propriétés ---

    @property
    def id_zone(self) -> Optional[int]:
        return self._id_zone

    @id_zone.setter
    def id_zone(self, valeur: int):
        if valeur is not None and valeur <= 0:
            raise ValueError("L'ID zone doit être positif")
        self._id_zone = valeur

    @property
    def nom_zone(self) -> str:
        return self._nom_zone

    @nom_zone.setter
    def nom_zone(self, valeur: str):
        if not valeur:
            raise ValueError("Le nom de la zone est obligatoire")
        self._nom_zone = valeur.strip()

    @property
    def type_zone(self) -> str:
        return self._type_zone

    @type_zone.setter
    def type_zone(self, valeur: str):
        if valeur not in self.TYPES_VALIDES:
            raise ValueError(f"Type de zone invalide. Choisissez parmi {self.TYPES_VALIDES}")
        self._type_zone = valeur

    @property
    def description(self) -> Optional[str]:
        return self._description

    @description.setter
    def description(self, valeur: Optional[str]):
        self._description = valeur

    @property
    def niveau_acces(self) -> int:
        return self._niveau_acces

    @niveau_acces.setter
    def niveau_acces(self, valeur: int):
        if valeur < 1 or valeur > 5:
            raise ValueError("Le niveau d'accès doit être entre 1 et 5")
        self._niveau_acces = valeur

    @property
    def coordonnees(self) -> dict:
        return self._coordonnees

    @coordonnees.setter
    def coordonnees(self, valeur: Optional[dict]):
        self._coordonnees = valeur or {}

    @property
    def date_creation(self) -> Optional[datetime]:
        return self._date_creation

    @date_creation.setter
    def date_creation(self, valeur: Optional[datetime]):
        self._date_creation = valeur

    # --- Propriétés calculées ---

    @property
    def est_sensible(self) -> bool:
        return self._type_zone in ('sensible', 'interdite')

    @property
    def necessite_autorisation(self) -> bool:
        return self._niveau_acces > 2

    def to_dict(self) -> dict:
        return {
            'id_zone': self._id_zone,
            'nom_zone': self._nom_zone,
            'type_zone': self._type_zone,
            'description': self._description,
            'niveau_acces': self._niveau_acces,
            'coordonnees': self._coordonnees,
            'est_sensible': self.est_sensible,
            'date_creation': self._date_creation.isoformat() if self._date_creation else None
        }

    def __repr__(self) -> str:
        return f"<Zone {self._nom_zone} ({self._type_zone})>"