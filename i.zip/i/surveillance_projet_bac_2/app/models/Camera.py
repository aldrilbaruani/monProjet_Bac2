# app/models/Camera.py

from datetime import datetime
from typing import Optional, Any

class Camera:
    """
    Modèle correspondant à la table 'camera'.
    """

    def __init__(
        self,
        nom_camera: str,
        emplacement: str,
        flux_url: str,
        id_zone: int,
        est_active: bool = True,
        configuration: Optional[dict] = None,
        id_camera: Optional[int] = None,
        date_installation: Optional[datetime] = None,
        derniere_connexion: Optional[datetime] = None
    ):
        # ✅ Utilisation des setters pour appliquer les validations
        self.nom_camera = nom_camera          # appelle le setter
        self.emplacement = emplacement        # appelle le setter
        self.flux_url = flux_url              # appelle le setter
        self.id_zone = id_zone                # appelle le setter
        self.est_active = est_active          # appelle le setter
        self.configuration = configuration or {}
        self.id_camera = id_camera
        self.date_installation = date_installation or datetime.now()
        self.derniere_connexion = derniere_connexion

    # --- Propriétés avec validation ---

    @property
    def id_camera(self) -> Optional[int]:
        return self._id_camera

    @id_camera.setter
    def id_camera(self, valeur: int):
        if valeur is not None and valeur <= 0:
            raise ValueError("L'ID caméra doit être positif")
        self._id_camera = valeur

    @property
    def nom_camera(self) -> str:
        return self._nom_camera

    @nom_camera.setter
    def nom_camera(self, valeur: str):
        if not valeur:
            raise ValueError("Le nom de la caméra est obligatoire")
        self._nom_camera = valeur.strip()

    @property
    def emplacement(self) -> str:
        return self._emplacement

    @emplacement.setter
    def emplacement(self, valeur: str):
        if not valeur:
            raise ValueError("L'emplacement est obligatoire")
        self._emplacement = valeur

    @property
    def flux_url(self) -> str:
        return self._flux_url

    @flux_url.setter
    def flux_url(self, valeur: str):
        if not valeur:
            raise ValueError("L'URL du flux est obligatoire")
        if not valeur.startswith(('http://', 'https://', 'rtsp://')):
            raise ValueError("URL de flux invalide")
        self._flux_url = valeur

    @property
    def est_active(self) -> bool:
        return self._est_active

    @est_active.setter
    def est_active(self, valeur: bool):
        self._est_active = valeur

    @property
    def configuration(self) -> dict:
        return self._configuration

    @configuration.setter
    def configuration(self, valeur: Optional[dict]):
        self._configuration = valeur or {}

    @property
    def id_zone(self) -> int:
        return self._id_zone

    @id_zone.setter
    def id_zone(self, valeur: int):
        if not valeur:
            raise ValueError("L'ID zone est obligatoire")
        self._id_zone = valeur

    @property
    def date_installation(self) -> datetime:
        return self._date_installation

    @date_installation.setter
    def date_installation(self, valeur: datetime):
        self._date_installation = valeur or datetime.now()

    @property
    def derniere_connexion(self) -> Optional[datetime]:
        return self._derniere_connexion

    @derniere_connexion.setter
    def derniere_connexion(self, valeur: Optional[datetime]):
        self._derniere_connexion = valeur

    # --- Propriétés calculées ---

    @property
    def est_en_ligne(self) -> bool:
        """Vérifie si la caméra est en ligne (connectée dans les 5 dernières minutes)."""
        if not self._est_active:
            return False
        if not self._derniere_connexion:
            return False
        return (datetime.now() - self._derniere_connexion).seconds < 300

    def to_dict(self) -> dict:
        """Convertit l'objet en dictionnaire pour l'API."""
        return {
            'id_camera': self._id_camera,
            'nom_camera': self._nom_camera,
            'emplacement': self._emplacement,
            'flux_url': self._flux_url,
            'est_active': self._est_active,
            'est_en_ligne': self.est_en_ligne,
            'configuration': self._configuration,
            'id_zone': self._id_zone,
            'date_installation': self._date_installation.isoformat() if self._date_installation else None,
            'derniere_connexion': self._derniere_connexion.isoformat() if self._derniere_connexion else None
        }

    def __repr__(self) -> str:
        status = "🟢" if self.est_en_ligne else "🔴" if self._est_active else "⚫"
        return f"<Camera {status} {self._nom_camera}>"