from datetime import datetime
from typing import Optional

class Alerte:

    TYPES_VALIDES = ['intrusion', 'retard', 'absence', 'zone_interdite']
    STATUTS_VALIDES = ['envoyee', 'traitee', 'ignoree']

    def __init__(
        self,
        type_alerte: str,
        message: str,
        niveau_urgence: int,
        id_employe_concerne: Optional[int] = None,
        id_evenement: Optional[int] = None,
        id_deplacement: Optional[int] = None,
        traitee_par: Optional[int] = None,
        commentaire: Optional[str] = None,
        id_alerte: Optional[int] = None,
        date_generation: Optional[datetime] = None,
        date_traitement: Optional[datetime] = None,
        statut: str = "envoyee"
    ):
        if type_alerte not in self.TYPES_VALIDES:
            raise ValueError(f"Type d'alerte invalide. Choisissez parmi {self.TYPES_VALIDES}")
        if not message:
            raise ValueError("Le message est obligatoire")
        if niveau_urgence is None or niveau_urgence < 1 or niveau_urgence > 5:
            raise ValueError("Le niveau d'urgence doit être entre 1 et 5")
        if statut not in self.STATUTS_VALIDES:
            raise ValueError(f"Statut invalide. Choisissez parmi {self.STATUTS_VALIDES}")

        self._id_alerte = id_alerte
        self._type_alerte = type_alerte
        self._message = message
        self._date_generation = date_generation or datetime.now()
        self._date_traitement = date_traitement
        self._niveau_urgence = niveau_urgence
        self._statut = statut
        self._id_employe_concerne = id_employe_concerne
        self._id_evenement = id_evenement
        self._id_deplacement = id_deplacement
        self._traitee_par = traitee_par
        self._commentaire = commentaire


    @property
    def id_alerte(self) -> Optional[int]:
        return self._id_alerte

    @id_alerte.setter
    def id_alerte(self, valeur: int):
        if valeur is not None and valeur <= 0:
            raise ValueError("L'ID alerte doit être positif")
        self._id_alerte = valeur

    @property
    def type_alerte(self) -> str:
        return self._type_alerte

    @type_alerte.setter
    def type_alerte(self, valeur: str):
        if valeur not in self.TYPES_VALIDES:
            raise ValueError(f"Type d'alerte invalide. Choisissez parmi {self.TYPES_VALIDES}")
        self._type_alerte = valeur

    @property
    def message(self) -> str:
        return self._message

    @message.setter
    def message(self, valeur: str):
        if not valeur:
            raise ValueError("Le message est obligatoire")
        self._message = valeur

    @property
    def date_generation(self) -> datetime:
        return self._date_generation

    @date_generation.setter
    def date_generation(self, valeur: datetime):
        self._date_generation = valeur or datetime.now()

    @property
    def date_traitement(self) -> Optional[datetime]:
        return self._date_traitement

    @date_traitement.setter
    def date_traitement(self, valeur: Optional[datetime]):
        self._date_traitement = valeur

    @property
    def niveau_urgence(self) -> int:
        return self._niveau_urgence

    @niveau_urgence.setter
    def niveau_urgence(self, valeur: int):
        if valeur < 1 or valeur > 5:
            raise ValueError("Le niveau d'urgence doit être entre 1 et 5")
        self._niveau_urgence = valeur

    @property
    def statut(self) -> str:
        return self._statut

    @statut.setter
    def statut(self, valeur: str):
        if valeur not in self.STATUTS_VALIDES:
            raise ValueError(f"Statut invalide. Choisissez parmi {self.STATUTS_VALIDES}")
        self._statut = valeur

    @property
    def id_employe_concerne(self) -> Optional[int]:
        return self._id_employe_concerne

    @id_employe_concerne.setter
    def id_employe_concerne(self, valeur: Optional[int]):
        self._id_employe_concerne = valeur

    @property
    def id_evenement(self) -> Optional[int]:
        return self._id_evenement

    @id_evenement.setter
    def id_evenement(self, valeur: Optional[int]):
        self._id_evenement = valeur

    @property
    def id_deplacement(self) -> Optional[int]:
        return self._id_deplacement

    @id_deplacement.setter
    def id_deplacement(self, valeur: Optional[int]):
        self._id_deplacement = valeur

    @property
    def traitee_par(self) -> Optional[int]:
        return self._traitee_par

    @traitee_par.setter
    def traitee_par(self, valeur: Optional[int]):
        self._traitee_par = valeur

    @property
    def commentaire(self) -> Optional[str]:
        return self._commentaire

    @commentaire.setter
    def commentaire(self, valeur: Optional[str]):
        self._commentaire = valeur

    @property
    def est_critique(self) -> bool:
        return self._niveau_urgence >= 4

    @property
    def est_traitee(self) -> bool:
        return self._statut in ('traitee', 'ignoree')

    @property
    def temps_avant_traitement(self) -> Optional[float]:
        if self._date_traitement and self._date_generation:
            delta = self._date_traitement - self._date_generation
            return round(delta.total_seconds() / 3600, 2)
        return None

    def traiter(self, utilisateur_id: int, commentaire: Optional[str] = None):
        self._statut = 'traitee'
        self._date_traitement = datetime.now()
        self._traitee_par = utilisateur_id
        if commentaire:
            self._commentaire = commentaire

    def ignorer(self, utilisateur_id: int, raison: Optional[str] = None):
        self._statut = 'ignoree'
        self._date_traitement = datetime.now()
        self._traitee_par = utilisateur_id
        if raison:
            self._commentaire = f"IGNORÉ: {raison}"

    def to_dict(self) -> dict:
        return {
            'id_alerte': self._id_alerte,
            'type_alerte': self._type_alerte,
            'message': self._message,
            'date_generation': self._date_generation.isoformat() if self._date_generation else None,
            'date_traitement': self._date_traitement.isoformat() if self._date_traitement else None,
            'niveau_urgence': self._niveau_urgence,
            'statut': self._statut,
            'id_employe_concerne': self._id_employe_concerne,
            'id_evenement': self._id_evenement,
            'id_deplacement': self._id_deplacement,
            'est_critique': self.est_critique
        }

    def __repr__(self) -> str:
        return f"<Alerte {self._id_alerte} - {self._type_alerte} [{self._statut}]>"