from datetime import datetime
from typing import Optional

class ChatbotInteraction:
    """
    Modèle correspondant à la table 'chatbot_interaction'.
    """

    def __init__(
        self,
        commande: str,
        reponse: str,
        id_employe: int,
        date_interaction: Optional[datetime] = None,
        id_deplacement: Optional[int] = None,
        intention: Optional[str] = None,
        score_confiance: Optional[float] = None,
        temps_reponse_ms: Optional[int] = None,
        id_interaction: Optional[int] = None
    ):
        if not commande:
            raise ValueError("La commande est obligatoire")
        if not reponse:
            raise ValueError("La réponse est obligatoire")
        if not id_employe:
            raise ValueError("L'ID employé est obligatoire")

        self._id_interaction = id_interaction
        self._date_interaction = date_interaction or datetime.now()
        self._commande = commande
        self._reponse = reponse
        self._id_employe = id_employe
        self._id_deplacement = id_deplacement
        self._intention = intention
        self._score_confiance = score_confiance
        self._temps_reponse_ms = temps_reponse_ms

    # --- Propriétés ---

    @property
    def id_interaction(self) -> Optional[int]:
        return self._id_interaction

    @id_interaction.setter
    def id_interaction(self, valeur: int):
        if valeur is not None and valeur <= 0:
            raise ValueError("L'ID interaction doit être positif")
        self._id_interaction = valeur

    @property
    def date_interaction(self) -> datetime:
        return self._date_interaction

    @date_interaction.setter
    def date_interaction(self, valeur: datetime):
        self._date_interaction = valeur or datetime.now()

    @property
    def commande(self) -> str:
        return self._commande

    @commande.setter
    def commande(self, valeur: str):
        if not valeur:
            raise ValueError("La commande est obligatoire")
        self._commande = valeur

    @property
    def reponse(self) -> str:
        return self._reponse

    @reponse.setter
    def reponse(self, valeur: str):
        if not valeur:
            raise ValueError("La réponse est obligatoire")
        self._reponse = valeur

    @property
    def id_employe(self) -> int:
        return self._id_employe

    @id_employe.setter
    def id_employe(self, valeur: int):
        if not valeur:
            raise ValueError("L'ID employé est obligatoire")
        self._id_employe = valeur

    @property
    def id_deplacement(self) -> Optional[int]:
        return self._id_deplacement

    @id_deplacement.setter
    def id_deplacement(self, valeur: Optional[int]):
        self._id_deplacement = valeur

    @property
    def intention(self) -> Optional[str]:
        return self._intention

    @intention.setter
    def intention(self, valeur: Optional[str]):
        self._intention = valeur

    @property
    def score_confiance(self) -> Optional[float]:
        return self._score_confiance

    @score_confiance.setter
    def score_confiance(self, valeur: Optional[float]):
        if valeur is not None and (valeur < 0 or valeur > 1):
            raise ValueError("Le score de confiance doit être entre 0 et 1")
        self._score_confiance = valeur

    @property
    def temps_reponse_ms(self) -> Optional[int]:
        return self._temps_reponse_ms

    @temps_reponse_ms.setter
    def temps_reponse_ms(self, valeur: Optional[int]):
        if valeur is not None and valeur < 0:
            raise ValueError("Le temps de réponse doit être positif")
        self._temps_reponse_ms = valeur

    # --- Propriétés calculées ---

    @property
    def temps_reponse_secondes(self) -> Optional[float]:
        if self._temps_reponse_ms is None:
            return None
        return round(self._temps_reponse_ms / 1000, 2)

    @property
    def a_cree_deplacement(self) -> bool:
        return self._id_deplacement is not None

    def to_dict(self) -> dict:
        return {
            'id_interaction': self._id_interaction,
            'date_interaction': self._date_interaction.isoformat() if self._date_interaction else None,
            'commande': self._commande,
            'reponse': self._reponse,
            'id_employe': self._id_employe,
            'id_deplacement': self._id_deplacement,
            'intention': self._intention,
            'score_confiance': self._score_confiance,
            'temps_reponse_ms': self._temps_reponse_ms
        }

    def __repr__(self) -> str:
        return f"<Chatbot {self._id_interaction} - Employé {self._id_employe}>"