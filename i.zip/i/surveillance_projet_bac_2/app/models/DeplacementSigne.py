from datetime import datetime
from typing import Optional

class DeplacementSigne:

    STATUTS_VALIDES = ['en_cours', 'termine', 'en_retard', 'annule']

    def __init__(
        self,
        date_depart: datetime,
        motif: str,
        id_employe: int,
        id_zone_destination: int,
        date_retour_prevue: Optional[datetime] = None,
        date_retour_reel: Optional[datetime] = None,
        date_signalement: Optional[datetime] = None,
        statut: str = 'en_cours',
        notes: Optional[str] = None,
        id_deplacement: Optional[int] = None
    ):
        if not date_depart:
            raise ValueError("La date de départ est obligatoire")
        if not motif:
            raise ValueError("Le motif est obligatoire")
        if not id_employe:
            raise ValueError("L'ID employé est obligatoire")
        if not id_zone_destination:
            raise ValueError("La zone de destination est obligatoire")
        if statut not in self.STATUTS_VALIDES:
            raise ValueError(f"Statut invalide. Choisissez parmi {self.STATUTS_VALIDES}")

        self._id_deplacement = id_deplacement
        self._date_depart = date_depart
        self._date_retour_prevue = date_retour_prevue
        self._date_retour_reel = date_retour_reel
        self._motif = motif
        self._date_signalement = date_signalement or datetime.now()
        self._statut = statut
        self._id_employe = id_employe
        self._id_zone_destination = id_zone_destination
        self._notes = notes

    # --- Propriétés ---

    @property
    def id_deplacement(self) -> Optional[int]:
        return self._id_deplacement

    @id_deplacement.setter
    def id_deplacement(self, valeur: int):
        if valeur is not None and valeur <= 0:
            raise ValueError("L'ID déplacement doit être positif")
        self._id_deplacement = valeur

    @property
    def date_depart(self) -> datetime:
        return self._date_depart

    @date_depart.setter
    def date_depart(self, valeur: datetime):
        if not valeur:
            raise ValueError("La date de départ est obligatoire")
        self._date_depart = valeur

    @property
    def date_retour_prevue(self) -> Optional[datetime]:
        return self._date_retour_prevue

    @date_retour_prevue.setter
    def date_retour_prevue(self, valeur: Optional[datetime]):
        if valeur and self._date_depart and valeur <= self._date_depart:
            raise ValueError("La date de retour prévue doit être postérieure à la date de départ")
        self._date_retour_prevue = valeur

    @property
    def date_retour_reel(self) -> Optional[datetime]:
        return self._date_retour_reel

    @date_retour_reel.setter
    def date_retour_reel(self, valeur: Optional[datetime]):
        if valeur and self._date_depart and valeur < self._date_depart:
            raise ValueError("La date de retour réel ne peut pas être antérieure au départ")
        self._date_retour_reel = valeur

    @property
    def motif(self) -> str:
        return self._motif

    @motif.setter
    def motif(self, valeur: str):
        if not valeur:
            raise ValueError("Le motif est obligatoire")
        self._motif = valeur

    @property
    def date_signalement(self) -> datetime:
        return self._date_signalement

    @date_signalement.setter
    def date_signalement(self, valeur: datetime):
        self._date_signalement = valeur or datetime.now()

    @property
    def statut(self) -> str:
        return self._statut

    @statut.setter
    def statut(self, valeur: str):
        if valeur not in self.STATUTS_VALIDES:
            raise ValueError(f"Statut invalide. Choisissez parmi {self.STATUTS_VALIDES}")
        self._statut = valeur

    @property
    def id_employe(self) -> int:
        return self._id_employe

    @id_employe.setter
    def id_employe(self, valeur: int):
        if not valeur:
            raise ValueError("L'ID employé est obligatoire")
        self._id_employe = valeur

    @property
    def id_zone_destination(self) -> int:
        return self._id_zone_destination

    @id_zone_destination.setter
    def id_zone_destination(self, valeur: int):
        if not valeur:
            raise ValueError("La zone de destination est obligatoire")
        self._id_zone_destination = valeur

    @property
    def notes(self) -> Optional[str]:
        return self._notes

    @notes.setter
    def notes(self, valeur: Optional[str]):
        self._notes = valeur

    # --- Propriétés calculées ---

    @property
    def est_en_cours(self) -> bool:
        return self._statut == 'en_cours'

    @property
    def est_termine(self) -> bool:
        return self._statut == 'termine'

    @property
    def est_en_retard(self) -> bool:
        if self._statut != 'en_cours' or not self._date_retour_prevue:
            return False
        return datetime.now() > self._date_retour_prevue

    @property
    def duree_estimee(self) -> Optional[float]:
        if self._date_depart and self._date_retour_prevue:
            delta = self._date_retour_prevue - self._date_depart
            return round(delta.total_seconds() / 3600, 2)
        return None

    @property
    def duree_reelle(self) -> Optional[float]:
        if self._date_depart and self._date_retour_reel:
            delta = self._date_retour_reel - self._date_depart
            return round(delta.total_seconds() / 3600, 2)
        return None

    @property
    def retard_minutes(self) -> Optional[int]:
        if not self.est_en_retard:
            return 0
        delta = datetime.now() - self._date_retour_prevue
        return int(delta.total_seconds() / 60)

    def terminer(self, date_retour: Optional[datetime] = None):
        self._statut = 'termine'
        self._date_retour_reel = date_retour or datetime.now()

    def annuler(self):
        self._statut = 'annule'

    def to_dict(self) -> dict:
        return {
            'id_deplacement': self._id_deplacement,
            'date_depart': self._date_depart.isoformat() if self._date_depart else None,
            'date_retour_prevue': self._date_retour_prevue.isoformat() if self._date_retour_prevue else None,
            'date_retour_reel': self._date_retour_reel.isoformat() if self._date_retour_reel else None,
            'motif': self._motif,
            'date_signalement': self._date_signalement.isoformat() if self._date_signalement else None,
            'statut': self._statut,
            'id_employe': self._id_employe,
            'id_zone_destination': self._id_zone_destination,
            'est_en_retard': self.est_en_retard,
            'duree_estimee': self.duree_estimee,
            'retard_minutes': self.retard_minutes
        }

    def __repr__(self) -> str:
        return f"<Deplacement {self._id_deplacement} - {self._statut}>"