from datetime import datetime
from typing import Optional


class Notification:



    def __init__(
            self,
            id_notification: Optional[int] = None,
            canal: Optional[str] = None,
            destinataire: Optional[str] = None,
            contenu: Optional[str] = None,
            date_envoi: Optional[datetime] = None,
            statut_envoi: str = "envoye",
            id_alerte: Optional[int] = None,
            date_lecture: Optional[datetime] = None,
            tentative: int = 0,
            erreur: Optional[str] = None
    ):from datetime import datetime
from typing import Optional

class Notification:


    CANAUX_VALIDES = ['SMS', 'EMAIL', 'PUSH', 'TELEGRAM']
    STATUTS_VALIDES = ['envoye', 'echec', 'lu', 'ignore']

    def __init__(
        self,
        canal: str,
        destinataire: str,
        contenu: str,
        id_alerte: int,
        date_envoi: Optional[datetime] = None,
        statut_envoi: str = 'envoye',
        date_lecture: Optional[datetime] = None,
        tentative: int = 0,
        erreur: Optional[str] = None,
        id_notification: Optional[int] = None
    ):
        if not canal or canal.upper() not in self.CANAUX_VALIDES:
            raise ValueError(f"Canal invalide. Choisissez parmi {self.CANAUX_VALIDES}")
        if not destinataire:
            raise ValueError("Le destinataire est obligatoire")
        if not contenu:
            raise ValueError("Le contenu est obligatoire")
        if not id_alerte:
            raise ValueError("L'ID alerte est obligatoire")
        if statut_envoi not in self.STATUTS_VALIDES:
            raise ValueError(f"Statut invalide. Choisissez parmi {self.STATUTS_VALIDES}")

        self._id_notification = id_notification
        self._canal = canal.upper()
        self._destinataire = destinataire
        self._contenu = contenu
        self._date_envoi = date_envoi or datetime.now()
        self._statut_envoi = statut_envoi
        self._id_alerte = id_alerte
        self._date_lecture = date_lecture
        self._tentative = tentative
        self._erreur = erreur


    @property
    def id_notification(self) -> Optional[int]:
        return self._id_notification

    @id_notification.setter
    def id_notification(self, valeur: int):
        if valeur is not None and valeur <= 0:
            raise ValueError("L'ID notification doit être positif")
        self._id_notification = valeur

    @property
    def canal(self) -> str:
        return self._canal

    @canal.setter
    def canal(self, valeur: str):
        if not valeur or valeur.upper() not in self.CANAUX_VALIDES:
            raise ValueError(f"Canal invalide. Choisissez parmi {self.CANAUX_VALIDES}")
        self._canal = valeur.upper()

    @property
    def destinataire(self) -> str:
        return self._destinataire

    @destinataire.setter
    def destinataire(self, valeur: str):
        if not valeur:
            raise ValueError("Le destinataire est obligatoire")
        self._destinataire = valeur

    @property
    def contenu(self) -> str:
        return self._contenu

    @contenu.setter
    def contenu(self, valeur: str):
        if not valeur:
            raise ValueError("Le contenu est obligatoire")
        self._contenu = valeur

    @property
    def date_envoi(self) -> datetime:
        return self._date_envoi

    @date_envoi.setter
    def date_envoi(self, valeur: datetime):
        self._date_envoi = valeur or datetime.now()

    @property
    def statut_envoi(self) -> str:
        return self._statut_envoi

    @statut_envoi.setter
    def statut_envoi(self, valeur: str):
        if valeur not in self.STATUTS_VALIDES:
            raise ValueError(f"Statut invalide. Choisissez parmi {self.STATUTS_VALIDES}")
        self._statut_envoi = valeur

    @property
    def id_alerte(self) -> int:
        return self._id_alerte

    @id_alerte.setter
    def id_alerte(self, valeur: int):
        if not valeur:
            raise ValueError("L'ID alerte est obligatoire")
        self._id_alerte = valeur

    @property
    def date_lecture(self) -> Optional[datetime]:
        return self._date_lecture

    @date_lecture.setter
    def date_lecture(self, valeur: Optional[datetime]):
        self._date_lecture = valeur

    @property
    def tentative(self) -> int:
        return self._tentative

    @tentative.setter
    def tentative(self, valeur: int):
        if valeur < 0:
            raise ValueError("Le nombre de tentatives doit être positif")
        self._tentative = valeur

    @property
    def erreur(self) -> Optional[str]:
        return self._erreur

    @erreur.setter
    def erreur(self, valeur: Optional[str]):
        self._erreur = valeur

    # --- Propriétés calculées ---

    @property
    def est_envoye(self) -> bool:
        return self._statut_envoi == 'envoye'

    @property
    def est_lu(self) -> bool:
        return self._statut_envoi == 'lu' or self._date_lecture is not None

    @property
    def a_echoue(self) -> bool:
        return self._statut_envoi == 'echec'

    @property
    def temps_avant_lecture(self) -> Optional[float]:
        if self._date_lecture and self._date_envoi:
            delta = self._date_lecture - self._date_envoi
            return round(delta.total_seconds() / 60, 2)
        return None

    def marquer_lu(self):
        self._statut_envoi = 'lu'
        self._date_lecture = datetime.now()

    def incrementer_tentative(self):
        self._tentative += 1

    def to_dict(self) -> dict:
        return {
            'id_notification': self._id_notification,
            'canal': self._canal,
            'destinataire': self._destinataire,
            'contenu': self._contenu,
            'date_envoi': self._date_envoi.isoformat() if self._date_envoi else None,
            'statut_envoi': self._statut_envoi,
            'id_alerte': self._id_alerte,
            'date_lecture': self._date_lecture.isoformat() if self._date_lecture else None,
            'tentative': self._tentative
        }

    def __repr__(self) -> str:
        return f"<Notification {self._id_notification} - {self._canal} [{self._statut_envoi}]>"

        self._id_notification = id_notification
        self._canal = canal
        self._destinataire = destinataire
        self._contenu = contenu
        self._date_envoi = date_envoi or datetime.now()
        self._statut_envoi = statut_envoi
        self._id_alerte = id_alerte
        self._date_lecture = date_lecture
        self._tentative = tentative
        self._erreur = erreur



    @property
    def id_notification(self) -> Optional[int]:
        return self._id_notification

    @id_notification.setter
    def id_notification(self, valeur: int):
        if valeur and valeur <= 0:
            raise ValueError("L'ID notification doit être positif")
        self._id_notification = valeur

    @property
    def canal(self) -> Optional[str]:
        return self._canal

    @canal.setter
    def canal(self, valeur: str):
        canaux_valides = ['SMS', 'EMAIL', 'PUSH', 'TELEGRAM']
        if valeur and valeur.upper() not in canaux_valides:
            raise ValueError(f"Canal invalide. Choisissez parmi {canaux_valides}")
        self._canal = valeur.upper() if valeur else None

    @property
    def destinataire(self) -> Optional[str]:
        return self._destinataire

    @destinataire.setter
    def destinataire(self, valeur: str):
        if not valeur:
            raise ValueError("Le destinataire est obligatoire")
        self._destinataire = valeur

    @property
    def contenu(self) -> Optional[str]:
        return self._contenu

    @contenu.setter
    def contenu(self, valeur: str):
        if not valeur:
            raise ValueError("Le contenu est obligatoire")
        self._contenu = valeur

    @property
    def date_envoi(self) -> datetime:
        return self._date_envoi

    @date_envoi.setter
    def date_envoi(self, valeur: datetime):
        self._date_envoi = valeur or datetime.now()

    @property
    def statut_envoi(self) -> str:
        return self._statut_envoi

    @statut_envoi.setter
    def statut_envoi(self, valeur: str):
        statuts_valides = ['envoye', 'echec', 'lu', 'ignore']
        if valeur not in statuts_valides:
            raise ValueError(f"Statut invalide. Choisissez parmi {statuts_valides}")
        self._statut_envoi = valeur

    @property
    def id_alerte(self) -> Optional[int]:
        return self._id_alerte

    @id_alerte.setter
    def id_alerte(self, valeur: int):
        self._id_alerte = valeur

    @property
    def date_lecture(self) -> Optional[datetime]:
        return self._date_lecture

    @date_lecture.setter
    def date_lecture(self, valeur: datetime):
        self._date_lecture = valeur

    @property
    def tentative(self) -> int:
        return self._tentative

    @tentative.setter
    def tentative(self, valeur: int):
        if valeur < 0:
            raise ValueError("Le nombre de tentatives doit être positif")
        self._tentative = valeur

    @property
    def erreur(self) -> Optional[str]:
        return self._erreur

    @erreur.setter
    def erreur(self, valeur: str):
        self._erreur = valeur



    @property
    def est_envoye(self) -> bool:
        return self._statut_envoi == 'envoye'

    @property
    def est_lu(self) -> bool:
        return self._statut_envoi == 'lu' or self._date_lecture is not None

    @property
    def a_echoue(self) -> bool:
        return self._statut_envoi == 'echec'

    @property
    def temps_avant_lecture(self) -> Optional[float]:

        if self._date_lecture and self._date_envoi:
            delta = self._date_lecture - self._date_envoi
            return round(delta.total_seconds() / 60, 2)
        return None


    def marquer_lu(self):

        self._statut_envoi = 'lu'
        self._date_lecture = datetime.now()

    def incrementer_tentative(self):

        self._tentative += 1

    def to_dict(self) -> dict:
        return {
            'id_notification': self._id_notification,
            'canal': self._canal,
            'destinataire': self._destinataire,
            'contenu': self._contenu,
            'date_envoi': self._date_envoi.isoformat() if self._date_envoi else None,
            'statut_envoi': self._statut_envoi,
            'id_alerte': self._id_alerte,
            'date_lecture': self._date_lecture.isoformat() if self._date_lecture else None,
            'tentative': self._tentative
        }

    def __repr__(self) -> str:
        return f"<Notification {self._id_notification} - {self._canal} [{self._statut_envoi}]>"