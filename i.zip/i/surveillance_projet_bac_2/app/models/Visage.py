from datetime import datetime
from typing import Optional, Any
import json

class Visage:


    ANGLES_VALIDES = ['face', 'profil', '3_4', 'haut', 'bas']

    def __init__(
        self,
        encodage: dict,
        id_employe: int,
        angle: Optional[str] = None,
        date_enregistrement: Optional[datetime] = None,
        qualite: Optional[float] = None,
        source: Optional[str] = None,
        id_visage: Optional[int] = None
    ):
        if not encodage:
            raise ValueError("L'encodage est obligatoire")
        if not id_employe:
            raise ValueError("L'ID employé est obligatoire")
        if angle is not None and angle not in self.ANGLES_VALIDES:
            raise ValueError(f"Angle invalide. Choisissez parmi {self.ANGLES_VALIDES}")

        self._id_visage = id_visage
        self._encodage = encodage
        self._angle = angle
        self._date_enregistrement = date_enregistrement or datetime.now()
        self._id_employe = id_employe
        self._qualite = qualite
        self._source = source

    # --- Propriétés ---

    @property
    def id_visage(self) -> Optional[int]:
        return self._id_visage

    @id_visage.setter
    def id_visage(self, valeur: int):
        if valeur is not None and valeur <= 0:
            raise ValueError("L'ID visage doit être positif")
        self._id_visage = valeur

    @property
    def encodage(self) -> dict:
        return self._encodage

    @encodage.setter
    def encodage(self, valeur: dict):
        if not valeur:
            raise ValueError("L'encodage est obligatoire")
        self._encodage = valeur

    @property
    def angle(self) -> Optional[str]:
        return self._angle

    @angle.setter
    def angle(self, valeur: Optional[str]):
        if valeur is not None and valeur not in self.ANGLES_VALIDES:
            raise ValueError(f"Angle invalide. Choisissez parmi {self.ANGLES_VALIDES}")
        self._angle = valeur

    @property
    def date_enregistrement(self) -> datetime:
        return self._date_enregistrement

    @date_enregistrement.setter
    def date_enregistrement(self, valeur: datetime):
        self._date_enregistrement = valeur or datetime.now()

    @property
    def id_employe(self) -> int:
        return self._id_employe

    @id_employe.setter
    def id_employe(self, valeur: int):
        if not valeur:
            raise ValueError("L'ID employé est obligatoire")
        self._id_employe = valeur

    @property
    def qualite(self) -> Optional[float]:
        return self._qualite

    @qualite.setter
    def qualite(self, valeur: Optional[float]):
        if valeur is not None and (valeur < 0 or valeur > 1):
            raise ValueError("La qualité doit être entre 0 et 1")
        self._qualite = valeur

    @property
    def source(self) -> Optional[str]:
        return self._source

    @source.setter
    def source(self, valeur: Optional[str]):
        self._source = valeur

    # --- Propriétés calculées ---

    @property
    def est_de_face(self) -> bool:
        return self._angle == 'face'

    @property
    def est_de_bonne_qualite(self) -> bool:
        return self._qualite is not None and self._qualite > 0.7

    def to_dict(self) -> dict:
        return {
            'id_visage': self._id_visage,
            'encodage': self._encodage,
            'angle': self._angle,
            'date_enregistrement': self._date_enregistrement.isoformat() if self._date_enregistrement else None,
            'id_employe': self._id_employe,
            'qualite': self._qualite,
            'source': self._source,
            'est_de_face': self.est_de_face,
            'est_de_bonne_qualite': self.est_de_bonne_qualite
        }

    def to_json(self) -> str:
        return json.dumps(self.to_dict(), default=str)

    def __repr__(self) -> str:
        return f"<Visage {self._id_visage} - Employé {self._id_employe} ({self._angle})>"