from datetime import datetime
from typing import Optional

class Reconnaissance:


    METHODES_VALIDES = ['faciale', 'tenue', 'inconnu']

    def __init__(
        self,
        methode: str,
        score_confiance: float,
        id_evenement: int,
        date_analyse: Optional[datetime] = None,
        id_employe: Optional[int] = None,
        temps_traitement_ms: Optional[int] = None,
        id_reconnaissance: Optional[int] = None,
        date_creation: Optional[datetime] = None

    ):

        if methode not in self.METHODES_VALIDES:
            raise ValueError(f"Méthode invalide. Choisissez parmi {self.METHODES_VALIDES}")
        if score_confiance is None or score_confiance < 0 or score_confiance > 1:
            raise ValueError("Le score de confiance doit être entre 0 et 1")
        if not id_evenement:
            raise ValueError("L'ID événement est obligatoire")

        self._id_reconnaissance = id_reconnaissance
        self._methode = methode
        self._score_confiance = score_confiance
        self._date_analyse = date_analyse or datetime.now()
        self._id_evenement = id_evenement
        self._id_employe = id_employe
        self._temps_traitement_ms = temps_traitement_ms
        self._date_creation = date_creation



    # --- Propriétés ---

    @property
    def id_reconnaissance(self) -> Optional[int]:
        return self._id_reconnaissance

    @id_reconnaissance.setter
    def id_reconnaissance(self, valeur: int):
        if valeur is not None and valeur <= 0:
            raise ValueError("L'ID reconnaissance doit être positif")
        self._id_reconnaissance = valeur

    @property
    def methode(self) -> str:
        return self._methode

    @methode.setter
    def methode(self, valeur: str):
        if valeur not in self.METHODES_VALIDES:
            raise ValueError(f"Méthode invalide. Choisissez parmi {self.METHODES_VALIDES}")
        self._methode = valeur

    @property
    def score_confiance(self) -> float:
        return self._score_confiance

    @score_confiance.setter
    def score_confiance(self, valeur: float):
        if valeur is None or valeur < 0 or valeur > 1:
            raise ValueError("Le score de confiance doit être entre 0 et 1")
        self._score_confiance = valeur

    @property
    def date_analyse(self) -> datetime:
        return self._date_analyse

    @date_analyse.setter
    def date_analyse(self, valeur: datetime):
        self._date_analyse = valeur or datetime.now()

    @property
    def id_evenement(self) -> int:
        return self._id_evenement

    @id_evenement.setter
    def id_evenement(self, valeur: int):
        if not valeur:
            raise ValueError("L'ID événement est obligatoire")
        self._id_evenement = valeur

    @property
    def id_employe(self) -> Optional[int]:
        return self._id_employe

    @id_employe.setter
    def id_employe(self, valeur: Optional[int]):
        self._id_employe = valeur

    @property
    def temps_traitement_ms(self) -> Optional[int]:
        return self._temps_traitement_ms

    @temps_traitement_ms.setter
    def temps_traitement_ms(self, valeur: Optional[int]):
        if valeur is not None and valeur < 0:
            raise ValueError("Le temps de traitement doit être positif")
        self._temps_traitement_ms = valeur

    # --- Propriétés calculées ---

    @property
    def est_fiable(self) -> bool:
        return self._score_confiance > 0.8

    @property
    def est_identifie(self) -> bool:
        return self._id_employe is not None

    @property
    def est_faciale(self) -> bool:
        return self._methode == 'faciale'

    @property
    def temps_traitement_secondes(self) -> Optional[float]:
        if self._temps_traitement_ms is None:
            return None
        return round(self._temps_traitement_ms / 1000, 3)

    @property
    def date_creation(self) -> Optional[datetime]:
        return self._date_creation

    @date_creation.setter
    def date_creation(self, valeur: Optional[datetime]):
        self._date_creation = valeur

    def to_dict(self) -> dict:
        return {
            'id_reconnaissance': self._id_reconnaissance,
            'methode': self._methode,
            'score_confiance': self._score_confiance,
            'date_analyse': self._date_analyse.isoformat() if self._date_analyse else None,
            'id_evenement': self._id_evenement,
            'id_employe': self._id_employe,
            'est_fiable': self.est_fiable,
            'temps_traitement_ms': self._temps_traitement_ms
        }

    def __repr__(self) -> str:
        if self._id_employe:
            return f"<Reconnaissance {self._methode} - Employé {self._id_employe} ({self._score_confiance:.2f})>"
        return f"<Reconnaissance {self._methode} - INCONNU ({self._score_confiance:.2f})>"