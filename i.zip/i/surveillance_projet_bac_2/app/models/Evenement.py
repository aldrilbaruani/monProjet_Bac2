# app/models/Evenement.py

from datetime import datetime
from typing import Optional, Any
import json

class Evenement:
    """
    Modèle correspondant à la table 'evenement'.
    """

    def __init__(
        self,
        date_heure: datetime,
        type_evenement: str,
        confiance: float,
        metadata: dict,
        id_camera: int,
        id_session: Optional[int] = None,
        id_evenement: Optional[int] = None,
        date_creation: Optional[datetime] = None
    ):
        if not date_heure:
            raise ValueError("La date/heure est obligatoire")
        if not type_evenement:
            raise ValueError("Le type d'événement est obligatoire")
        if confiance is None or confiance < 0 or confiance > 1:
            raise ValueError("La confiance doit être comprise entre 0 et 1")
        if not metadata:
            raise ValueError("Les métadonnées sont obligatoires")
        if not id_camera:
            raise ValueError("L'ID caméra est obligatoire")

        self._id_evenement = id_evenement
        self._date_heure = date_heure or datetime.now()
        self._type_evenement = type_evenement
        self._confiance = confiance
        self._metadata = metadata
        self._id_camera = id_camera
        self._id_session = id_session
        self._date_creation = date_creation

    # --- Propriétés ---

    @property
    def id_evenement(self) -> Optional[int]:
        return self._id_evenement

    @id_evenement.setter
    def id_evenement(self, valeur: int):
        if valeur is not None and valeur <= 0:
            raise ValueError("L'ID événement doit être positif")
        self._id_evenement = valeur

    @property
    def date_heure(self) -> datetime:
        return self._date_heure

    @date_heure.setter
    def date_heure(self, valeur: datetime):
        if not valeur:
            raise ValueError("La date/heure est obligatoire")
        self._date_heure = valeur

    @property
    def type_evenement(self) -> str:
        return self._type_evenement

    @type_evenement.setter
    def type_evenement(self, valeur: str):
        if not valeur:
            raise ValueError("Le type d'événement est obligatoire")
        self._type_evenement = valeur

    @property
    def confiance(self) -> float:
        return self._confiance

    @confiance.setter
    def confiance(self, valeur: float):
        if valeur is None or valeur < 0 or valeur > 1:
            raise ValueError("La confiance doit être comprise entre 0 et 1")
        self._confiance = valeur

    @property
    def metadata(self) -> dict:
        return self._metadata

    @metadata.setter
    def metadata(self, valeur: dict):
        if not valeur:
            raise ValueError("Les métadonnées sont obligatoires")
        self._metadata = valeur

    @property
    def id_camera(self) -> int:
        return self._id_camera

    @id_camera.setter
    def id_camera(self, valeur: int):
        if not valeur:
            raise ValueError("L'ID caméra est obligatoire")
        self._id_camera = valeur

    @property
    def id_session(self) -> Optional[int]:
        return self._id_session

    @id_session.setter
    def id_session(self, valeur: Optional[int]):
        self._id_session = valeur

    @property
    def date_creation(self) -> Optional[datetime]:
        return self._date_creation

    @date_creation.setter
    def date_creation(self, valeur: Optional[datetime]):
        self._date_creation = valeur

    # --- Propriétés calculées ---

    @property
    def est_fiable(self) -> bool:
        return self._confiance > 0.7

    @property
    def a_personne_detectee(self) -> bool:
        return self._metadata.get('type_detection') == 'personne' or 'bbox' in self._metadata

    @property
    def coordonnees_bbox(self) -> Optional[dict]:
        return self._metadata.get('bbox')

    @property
    def couleur_tenue(self) -> Optional[str]:
        return self._metadata.get('couleur_dominante')

    def ajouter_metadata(self, cle: str, valeur: Any):
        self._metadata[cle] = valeur

    def to_dict(self) -> dict:
        return {
            'id_evenement': self._id_evenement,
            'date_heure': self._date_heure.isoformat() if self._date_heure else None,
            'type_evenement': self._type_evenement,
            'confiance': self._confiance,
            'metadata': self._metadata,
            'id_camera': self._id_camera,
            'id_session': self._id_session,
            'est_fiable': self.est_fiable,
            'date_creation': self._date_creation.isoformat() if self._date_creation else None
        }

    def to_json(self) -> str:
        return json.dumps(self.to_dict(), default=str)

    def __repr__(self) -> str:
        return f"<Evenement {self._id_evenement} - {self._type_evenement} ({self._confiance:.2f})>"