// static/js/superadmin.js

import { stats, cameras, alertes, deplacements } from './api.js';
import { createLineChart, createDonutChart } from './charts.js';

export async function loadDashboardData() {
    try {
        // Charger les statistiques
        const statsData = await stats.getSuperAdmin();
        updateStats(statsData.data);

        // Charger les caméras
        const camerasData = await cameras.getAll(true);
        renderCameraGrid(camerasData.data);

        // Charger les alertes
        const alertesData = await alertes.getNonTraitees();
        updateAlertes(alertesData.data);

        // Charger les déplacements
        const deplacementsData = await deplacements.getEnCours();
        updateDeplacements(deplacementsData.data);

    } catch (error) {
        console.error('Erreur chargement dashboard:', error);
        showNotification('Erreur de chargement', 'error');
    }
}

function updateStats(stats) {
    // Mettre à jour les cartes
    const elements = {
        'totalEmployes': stats.employes?.total || 0,
        'camerasActives': stats.cameras?.actives || 0,
        'alertesNonTraitees': stats.alertes?.non_traitees || 0,
        'deplacementsEnCours': stats.deplacements?.total_en_cours || 0
    };

    Object.entries(elements).forEach(([id, value]) => {
        const el = document.getElementById(id);
        if (el) el.textContent = value;
    });
}

function renderCameraGrid(cameras) {
    const grid = document.getElementById('cameraGrid');
    if (!grid) return;

    grid.innerHTML = '';

    cameras.forEach(cam => {
        const feed = document.createElement('div');
        feed.className = 'camera-feed';
        feed.innerHTML = `
            <img src="/assets/camera-placeholder.jpg" alt="${cam.nom_camera}">
            <div class="feed-overlay">
                <div class="feed-tag">${cam.nom_camera}</div>
                <div class="feed-status ${cam.est_active ? 'live' : 'offline'}">
                    ${cam.est_active ? 'LIVE' : 'OFFLINE'}
                </div>
            </div>
        `;
        grid.appendChild(feed);
    });
}

function showNotification(message, type) {
    console.log(`[${type}] ${message}`);
    // Implémenter un système de notification si désiré
}