// static/js/api.js
const API_BASE_URL = 'http://localhost:5001/api';

// ===== GESTION DU TOKEN =====
function getToken() {
    return localStorage.getItem('token');
}

function setToken(token) {
    console.log('🔑 Stockage du token:', token ? token.substring(0, 30) + '...' : 'null');
    if (token) {
        localStorage.setItem('token', token);
    }
}

function removeToken() {
    console.log('🗑️ Suppression du token');
    localStorage.removeItem('token');
    localStorage.removeItem('user');
}

function getAuthHeaders() {
    const token = getToken();
    const headers = {
        'Content-Type': 'application/json'
    };
    if (token) {
        headers['Authorization'] = `Bearer ${token}`;
        console.log('🔐 Headers avec token présent');
    } else {
        console.warn('⚠️ Pas de token disponible');
    }
    return headers;
}

// ===== GESTION DES ERREURS =====
async function handleResponse(response) {
    console.log(`📡 Réponse: ${response.status} ${response.statusText}`);

    if (!response.ok) {
        if (response.status === 401) {
            console.error('❌ Token invalide ou expiré');
            removeToken();
            if (!window.location.pathname.includes('/index.html') && window.location.pathname !== '/') {
                window.location.href = '/';
            }
            throw new Error('Session expirée');
        }
        const error = await response.json().catch(() => ({}));
        throw new Error(error.message || `Erreur ${response.status}`);
    }
    return response.json();
}

// ===== REQUÊTE GÉNÉRIQUE =====
async function apiCall(endpoint, method = 'GET', data = null) {
    const url = `${API_BASE_URL}${endpoint}`;
    console.log(`🌐 ${method} ${url}`);

    const options = {
        method,
        headers: getAuthHeaders()
    };

    if (data) {
        options.body = JSON.stringify(data);
        console.log(`📦 Body:`, data);
    }

    try {
        const response = await fetch(url, options);
        return await handleResponse(response);
    } catch (error) {
        console.error(`❌ API Error:`, error);
        throw error;
    }
}

// ===== AUTH =====
export const auth = {
    async login(email, password) {
        console.log(`🔐 Tentative de connexion: ${email}`);
        const response = await apiCall('/auth/login', 'POST', { email, password });
        console.log('📥 Réponse login:', response);

        if (response.success && response.data?.token) {
            setToken(response.data.token);
            localStorage.setItem('user', JSON.stringify(response.data.employe));
            console.log('✅ Connexion réussie pour:', response.data.employe.email);
            console.log('👤 Rôle:', response.data.employe.role);
        }
        return response;
    },

    async getCurrentUser() {
        console.log('👤 Récupération utilisateur courant');
        return apiCall('/auth/me');
    },

    logout() {
        console.log('🚪 Déconnexion');
        removeToken();
        window.location.href = '/';
    },

    isAuthenticated() {
        const token = getToken();
        const user = localStorage.getItem('user');
        const isValid = !!token && !!user;
        console.log(`🔍 Authentifié: ${isValid}`);
        return isValid;
    },

    getUser() {
        const userStr = localStorage.getItem('user');
        return userStr ? JSON.parse(userStr) : null;
    }
};

// ===== EMPLOYES =====
export const employes = {
    getAll(actifsOnly = true) {
        return apiCall(`/employes/?actifs_only=${actifsOnly}`);
    },
    getById(id) {
        return apiCall(`/employes/${id}`);
    },
    create(data) {
        return apiCall('/employes/', 'POST', data);
    },
    update(id, data) {
        return apiCall(`/employes/${id}`, 'PUT', data);
    },
    delete(id, softDelete = true) {
        return apiCall(`/employes/${id}?soft_delete=${softDelete}`, 'DELETE');
    },
    getStats() {
        return apiCall('/employes/stats');
    }
};

// ===== DEPLACEMENTS =====
export const deplacements = {
    getEnCours() {
        return apiCall('/deplacements/en-cours');
    },
    getByEmploye(id) {
        return apiCall(`/deplacements/employe/${id}`);
    },
    create(data) {
        return apiCall('/deplacements/', 'POST', data);
    },
    terminer(id) {
        return apiCall(`/deplacements/${id}/terminer`, 'POST');
    }
};

// ===== ALERTES =====
export const alertes = {
    getNonTraitees() {
        return apiCall('/alertes/non-traitees');
    },
    getByEmploye(id) {
        return apiCall(`/alertes/employe/${id}`);
    },
    traiter(id, commentaire) {
        return apiCall(`/alertes/${id}/traiter`, 'POST', { commentaire });
    }
};

// ===== STATISTIQUES =====
export const stats = {
    getDashboard() {
        return apiCall('/stats/dashboard');
    },
    getSuperAdmin() {
        return apiCall('/stats/superadmin');
    },
    getTempsReel() {
        return apiCall('/stats/temps-reel');
    }
};

// ===== ZONES =====
export const zones = {
    getAll() {
        return apiCall('/zones/');
    }
};

// ===== CAMERAS =====
export const cameras = {
    getAll(activesOnly = false) {
        return apiCall(`/cameras/?actives_only=${activesOnly}`);
    }
};

// Export par défaut
export default { auth, employes, deplacements, alertes, stats, zones, cameras };