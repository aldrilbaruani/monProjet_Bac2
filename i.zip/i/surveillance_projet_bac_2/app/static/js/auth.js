// static/js/auth.js
import { auth as authApi } from './api.js';

const roleRedirects = {
    'super_admin': '/superadmin/dashboard.html',
    'admin': '/admin/dashboard.html',
    'employe': '/employe/dashboard.html'
};

export async function checkAuth() {
    const token = localStorage.getItem('token');
    const user = localStorage.getItem('user');

    console.log('🔍 Vérification auth:', { token: !!token, user: !!user });

    if (!token) {
        console.log('❌ Pas de token');
        window.location.href = '/';
        return null;
    }

    try {
        console.log('🔄 Vérification token auprès du serveur...');
        const response = await authApi.getCurrentUser();
        console.log('📥 Réponse /me:', response);

        if (response.success && response.data) {
            localStorage.setItem('user', JSON.stringify(response.data));
            console.log('✅ Token valide pour:', response.data.email);
            return response.data;
        } else {
            console.log('❌ Token invalide');
            authApi.logout();
            return null;
        }
    } catch (error) {
        console.error('❌ Erreur vérification:', error);
        authApi.logout();
        return null;
    }
}

export async function initAuth() {
    console.log('🚀 Initialisation de l\'auth');
    const user = await checkAuth();

    if (user) {
        console.log('👤 Utilisateur connecté:', user.email, 'Rôle:', user.role);
        updateUserUI(user);
        checkPageAccess(user.role);
        return user;
    }

    console.log('⛔ Non connecté');
    return null;
}

function updateUserUI(user) {
    console.log('🎨 Mise à jour UI avec:', user);

    document.querySelectorAll('.user-name').forEach(el => {
        el.textContent = `${user.prenom} ${user.nom}`;
    });

    document.querySelectorAll('.user-role').forEach(el => {
        const roleMap = {
            'super_admin': 'SUPER ADMIN',
            'admin': 'ADMINISTRATEUR',
            'employe': 'EMPLOYÉ'
        };
        el.textContent = roleMap[user.role] || user.role;
    });

    document.querySelectorAll('.user-email').forEach(el => {
        el.textContent = user.email;
    });
}

function checkPageAccess(userRole) {
    const currentPath = window.location.pathname;
    console.log(`📍 Page: ${currentPath}, Rôle: ${userRole}`);

    if (currentPath.includes('/superadmin/') && userRole !== 'super_admin') {
        console.log('⛔ Accès superadmin non autorisé');
        window.location.href = '/';
    } else if (currentPath.includes('/admin/') && !['super_admin', 'admin'].includes(userRole)) {
        console.log('⛔ Accès admin non autorisé');
        window.location.href = '/';
    } else if (currentPath.includes('/employe/') && userRole !== 'employe') {
        console.log('⛔ Accès employé non autorisé');
        window.location.href = '/';
    }
}

export function logout() {
    console.log('🚪 Déconnexion');
    authApi.logout();
}

document.addEventListener('DOMContentLoaded', () => {
    console.log('📄 DOM chargé');
    const logoutBtn = document.getElementById('logout-btn');
    if (logoutBtn) {
        logoutBtn.addEventListener('click', (e) => {
            e.preventDefault();
            logout();
        });
    }
});