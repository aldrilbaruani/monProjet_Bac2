// =====================================================
// CONFIGURATION DES GRAPHIQUES CYBERPUNK
// =====================================================

// Thème cyberpunk pour Chart.js
const cyberTheme = {
    background: 'rgba(0, 240, 255, 0.1)',
    border: '#00f0ff',
    pointBackground: '#ff00ea',
    pointBorder: '#ffffff',
    gridColor: 'rgba(0, 240, 255, 0.1)',
    textColor: '#ffffff'
};

// Configuration commune
Chart.defaults.font.family = "'Space Grotesk', sans-serif";
Chart.defaults.color = cyberTheme.textColor;

// ===== GRAPHIQUE EN LIGNES =====
export function createLineChart(ctx, labels, data, label = 'Valeur') {
    return new Chart(ctx, {
        type: 'line',
        data: {
            labels: labels,
            datasets: [{
                label: label,
                data: data,
                borderColor: cyberTheme.border,
                backgroundColor: cyberTheme.background,
                borderWidth: 2,
                pointBackgroundColor: cyberTheme.pointBackground,
                pointBorderColor: cyberTheme.pointBorder,
                pointBorderWidth: 2,
                pointRadius: 4,
                pointHoverRadius: 6,
                tension: 0.1,
                fill: true
            }]
        },
        options: {
            responsive: true,
            maintainAspectRatio: false,
            plugins: {
                legend: {
                    labels: { color: cyberTheme.textColor }
                },
                tooltip: {
                    backgroundColor: 'rgba(5, 5, 10, 0.9)',
                    titleColor: cyberTheme.border,
                    bodyColor: '#ffffff',
                    borderColor: cyberTheme.border,
                    borderWidth: 1
                }
            },
            scales: {
                y: {
                    grid: { color: cyberTheme.gridColor },
                    ticks: { color: cyberTheme.textColor }
                },
                x: {
                    grid: { display: false },
                    ticks: { color: cyberTheme.textColor }
                }
            }
        }
    });
}

// ===== GRAPHIQUE EN BARRES =====
export function createBarChart(ctx, labels, data, label = 'Valeur') {
    return new Chart(ctx, {
        type: 'bar',
        data: {
            labels: labels,
            datasets: [{
                label: label,
                data: data,
                backgroundColor: cyberTheme.background,
                borderColor: cyberTheme.border,
                borderWidth: 2,
                hoverBackgroundColor: 'rgba(255, 0, 234, 0.2)',
                hoverBorderColor: cyberTheme.pointBackground
            }]
        },
        options: {
            responsive: true,
            maintainAspectRatio: false,
            plugins: {
                legend: { labels: { color: cyberTheme.textColor } },
                tooltip: {
                    backgroundColor: 'rgba(5, 5, 10, 0.9)',
                    titleColor: cyberTheme.border,
                    bodyColor: '#ffffff',
                    borderColor: cyberTheme.border
                }
            },
            scales: {
                y: {
                    grid: { color: cyberTheme.gridColor },
                    ticks: { color: cyberTheme.textColor }
                },
                x: {
                    grid: { display: false },
                    ticks: { color: cyberTheme.textColor }
                }
            }
        }
    });
}

// ===== GRAPHIQUE EN DONUT =====
export function createDonutChart(ctx, labels, data) {
    return new Chart(ctx, {
        type: 'doughnut',
        data: {
            labels: labels,
            datasets: [{
                data: data,
                backgroundColor: [
                    '#00f0ff',
                    '#ff00ea',
                    '#ffaa00',
                    '#00ff9d',
                    '#ff003c'
                ],
                borderColor: '#0a0a0f',
                borderWidth: 2,
                hoverOffset: 10
            }]
        },
        options: {
            responsive: true,
            maintainAspectRatio: false,
            plugins: {
                legend: {
                    position: 'bottom',
                    labels: { color: cyberTheme.textColor }
                },
                tooltip: {
                    backgroundColor: 'rgba(5, 5, 10, 0.9)',
                    titleColor: cyberTheme.border,
                    bodyColor: '#ffffff',
                    borderColor: cyberTheme.border
                }
            },
            cutout: '60%'
        }
    });
}

// ===== GRAPHIQUE EN JAUGE =====
export function createGaugeChart(ctx, value, max = 100, label = '') {
    const percentage = (value / max) * 100;
    let color = '#00ff9d';

    if (percentage > 80) color = '#ff003c';
    else if (percentage > 60) color = '#ffaa00';

    return new Chart(ctx, {
        type: 'doughnut',
        data: {
            datasets: [{
                data: [value, max - value],
                backgroundColor: [color, 'rgba(255,255,255,0.1)'],
                borderColor: 'transparent',
                circumference: 180,
                rotation: 270
            }]
        },
        options: {
            responsive: true,
            maintainAspectRatio: false,
            cutout: '70%',
            plugins: {
                legend: { display: false },
                tooltip: { enabled: false },
                title: {
                    display: true,
                    text: `${label}: ${value}/${max}`,
                    color: cyberTheme.textColor,
                    font: { size: 14, family: "'Space Grotesk', sans-serif" }
                }
            }
        }
    });
}