# launch.py
import sys
import os
import subprocess
import time
import webbrowser
import threading


# Couleurs pour l'affichage
class Colors:
    HEADER = '\033[95m'
    OKBLUE = '\033[94m'
    OKCYAN = '\033[96m'
    OKGREEN = '\033[92m'
    WARNING = '\033[93m'
    FAIL = '\033[91m'
    ENDC = '\033[0m'
    BOLD = '\033[1m'


def print_colored(text, color=Colors.OKGREEN):
    """Affiche du texte coloré."""
    print(f"{color}{text}{Colors.ENDC}")


def print_header(title):
    """Affiche un en-tête."""
    print("\n" + "=" * 70)
    print_colored(f"🚀 {title}", Colors.BOLD + Colors.OKCYAN)
    print("=" * 70)


def check_dependencies():
    """Vérifie les dépendances."""
    print_header("VÉRIFICATION DES DÉPENDANCES")

    try:
        import flask
        print_colored("✅ Flask", Colors.OKGREEN)
    except ImportError:
        print_colored("❌ Flask non installé", Colors.FAIL)
        return False

    try:
        import mysql.connector
        print_colored("✅ MySQL Connector", Colors.OKGREEN)
    except ImportError:
        print_colored("❌ MySQL Connector non installé", Colors.FAIL)
        return False

    try:
        import bcrypt
        print_colored("✅ bcrypt", Colors.OKGREEN)
    except ImportError:
        print_colored("❌ bcrypt non installé", Colors.FAIL)
        return False

    try:
        import dotenv
        print_colored("✅ python-dotenv", Colors.OKGREEN)
    except ImportError:
        print_colored("❌ python-dotenv non installé", Colors.FAIL)
        return False

    return True


def check_database():
    """Vérifie la connexion à la base de données."""
    print_header("VÉRIFICATION DE LA BASE DE DONNÉES")

    try:
        import mysql.connector
        from config import Config

        conn = mysql.connector.connect(
            host=Config.DB_HOST,
            user=Config.DB_USER,
            password=Config.DB_PASSWORD,
            database=Config.DB_NAME
        )
        conn.close()
        print_colored(f"✅ Connexion à {Config.DB_NAME} réussie", Colors.OKGREEN)
        return True

    except mysql.connector.Error as err:
        print_colored(f"❌ Erreur: {err}", Colors.FAIL)
        return False
    except ImportError:
        print_colored("❌ Configuration introuvable", Colors.FAIL)
        return False


def start_server():
    """Démarre le serveur Flask."""
    print_header("DÉMARRAGE DU SERVEUR")

    try:
        # Démarrer le serveur
        process = subprocess.Popen(
            [sys.executable, "run.py"],
            cwd=os.path.dirname(os.path.abspath(__file__)),
            stdout=subprocess.PIPE,
            stderr=subprocess.STDOUT,
            text=True,
            bufsize=1
        )

        # Attendre que le serveur soit prêt
        time.sleep(3)

        # Ouvrir le navigateur
        webbrowser.open("http://localhost:5001")
        print_colored("\n🌐 Navigateur ouvert sur http://localhost:5001", Colors.OKGREEN)

        # Afficher les logs
        print_colored("\n📋 Logs du serveur (Ctrl+C pour arrêter):", Colors.OKBLUE)
        print("-" * 70)

        for line in process.stdout:
            print(line, end='')

    except KeyboardInterrupt:
        print_colored("\n\n👋 Arrêt du serveur demandé", Colors.WARNING)
        process.terminate()
    except Exception as e:
        print_colored(f"\n❌ Erreur: {e}", Colors.FAIL)


def run_tests():
    """Exécute les tests de l'application."""
    print_header("EXÉCUTION DES TESTS")

    try:
        result = subprocess.run(
            [sys.executable, "test_app.py"],
            cwd=os.path.dirname(os.path.abspath(__file__)),
            timeout=30
        )

        if result.returncode == 0:
            print_colored("\n✅ Tests réussis !", Colors.OKGREEN)
            return True
        else:
            print_colored("\n❌ Tests échoués !", Colors.FAIL)
            return False

    except subprocess.TimeoutExpired:
        print_colored("\n⏰ Tests trop longs", Colors.WARNING)
        return False
    except Exception as e:
        print_colored(f"\n❌ Erreur: {e}", Colors.FAIL)
        return False


def main():
    """Fonction principale."""
    print_header("SURVEILLANCE IA - LANCEMENT")

    # Vérifier les dépendances
    if not check_dependencies():
        print_colored("\n💡 Installez les dépendances avec:", Colors.WARNING)
        print("   pip install -r requirements.txt")
        return

    # Vérifier la base de données
    if not check_database():
        print_colored("\n💡 Vérifiez la configuration de la base de données dans config.py", Colors.WARNING)
        return

    # Menu
    print("\n1. Démarrer le serveur")
    print("2. Exécuter les tests")
    print("3. Tout faire (tests + serveur)")
    print("4. Quitter")

    choice = input("\n👉 Votre choix (1-4): ").strip()

    if choice == "1":
        start_server()
    elif choice == "2":
        run_tests()
    elif choice == "3":
        if run_tests():
            start_server()
        else:
            print_colored("\n❌ Tests échoués, serveur non démarré", Colors.FAIL)
    else:
        print_colored("👋 Au revoir !", Colors.OKBLUE)


if __name__ == "__main__":
    main()