# diagnostic_complet.py

import sys
import os

def main():
    print("=" * 60)
    print("🔍 DIAGNOSTIC COMPLET DU PROJET")
    print("=" * 60)

    # 1. Informations Python
    print(f"\n📌 Python version: {sys.version}")
    print(f"📌 Python executable: {sys.executable}")
    print(f"📌 Current working directory: {os.getcwd()}")

    # 2. Structure du projet
    project_root = os.path.dirname(os.path.abspath(__file__))
    print(f"\n📌 Racine du projet: {project_root}")

    # 3. Vérifier les dossiers importants
    dossiers = ['app', 'app/dao', 'app/models', 'app/utils', 'app/services']
    print("\n📌 Vérification des dossiers:")
    for dossier in dossiers:
        path = os.path.join(project_root, dossier)
        if os.path.exists(path):
            print(f"   ✅ {dossier} existe")
            fichiers = [f for f in os.listdir(path) if f.endswith('.py')]
            if fichiers:
                print(f"      Fichiers: {', '.join(fichiers[:5])}")
        else:
            print(f"   ❌ {dossier} manquant!")

    # 4. Vérifier les fichiers __init__.py
    print("\n📌 Vérification des fichiers __init__.py:")
    init_files = [
        'app/__init__.py',
        'app/dao/__init__.py',
        'app/models/__init__.py',
        'app/utils/__init__.py',
        'app/services/__init__.py'
    ]
    for init_file in init_files:
        path = os.path.join(project_root, init_file)
        if os.path.exists(path):
            print(f"   ✅ {init_file} existe")
        else:
            print(f"   ❌ {init_file} manquant!")

    # 5. PYTHONPATH
    print(f"\n📌 PYTHONPATH actuel:")
    for i, path in enumerate(sys.path):
        if 'surveillance' in path.lower() or project_root in path:
            print(f"   {i}: {path}")

    # 6. Test d'import
    print("\n📌 Test d'imports:")
    try:
        sys.path.insert(0, project_root)
        print(f"   ✅ Chemin {project_root} ajouté au PYTHONPATH")

        from app.dao import EmployeDAO

        print(f"   ✅ from app.dao import EmployeDAO réussi")
    except ImportError as e:
        print(f"   ❌ Erreur: {e}")

        # Afficher le contenu du dossier dao
        dao_path = os.path.join(project_root, 'app', 'dao')
        if os.path.exists(dao_path):
            print(f"\n   📂 Contenu de {dao_path}:")
            for f in os.listdir(dao_path):
                if f.endswith('.py'):
                    print(f"      - {f}")

    print("\n" + "=" * 60)
if __name__ == '__main__':
    main()