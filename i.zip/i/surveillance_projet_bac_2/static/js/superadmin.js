
import { stats, cameras, alertes, deplacements, employes } from './api.js';
import { createLineChart, createDonutChart } from './charts.js';
import { updateStats, showNotification } from './dashboard.js';

export async function loadSuperAdminData() {
    try {

        const statsData = await stats.getSuperAdmin();
        if (statsData.success) {
            updateSuperAdminStats(statsData.data);
        }


        const camerasData = await cameras.getAll(true);
        if (camerasData.success) {
            renderCameraGrid(camerasData.data);
            document.getElementById('activeNodes').textContent = camerasData.data.length;
        }


        const alertesData = await alertes.getNonTraitees();
        if (alertesData.success) {
            updateThreats(alertesData.data);
        }


        const deplacementsData = await deplacements.getEnCours();
        if (deplacementsData.success) {
            updateDeplacements(deplacementsData.data);
        }


        const employesStats = await employes.getStats();
        if (employesStats.success) {
            updateEmployesStats(employesStats.data);
        }

    } catch (error) {
        console.error('Erreur chargement dashboard super admin:', error);
        showNotification('Erreur de chargement des données', 'error');
    }
}

function updateSuperAdminStats(stats) {
    const elements = {
        'totalEmployes': stats.employes?.actifs || 0,
        'totalCameras': stats.cameras?.actives || 0,
        'alertesNonTraitees': stats.alertes?.non_traitees || 0,
        'deplacementsEnCours': stats.deplacements?.total_en_cours || 0,
        'cpuLoad': stats.system?.cpu || '78%',
        'gpuLoad': stats.system?.gpu || '52%',
        'memory': stats.system?.memory || '14.2/64 GB',
        'threatLevel': stats.alertes?.critiques > 0 ? 'CRITICAL' : 'ELEVATED'
    };

    updateStats(elements);


    document.getElementById('cpuBar').style.width = elements.cpuLoad;
    document.getElementById('gpuBar').style.width = elements.gpuLoad;
}

function updateEmployesStats(stats) {
    const statsContainer = document.getElementById('statsContainer');
    if (!statsContainer) return;

    statsContainer.innerHTML = `
        <div class="stat-card">
            <div class="stat-icon"></div>
            <div class="stat-value">${stats.actifs || 0}</div>
            <div class="stat-label">EMPLOYÉS ACTIFS</div>
            <div class="stat-trend trend-up">+${stats.nouveaux || 0} cette semaine</div>
        </div>
        <div class="stat-card">
            <div class="stat-icon"></div>
            <div class="stat-value">${stats.par_role?.super_admin || 0}</div>
            <div class="stat-label">SUPER ADMINS</div>
        </div>
        <div class="stat-card">
            <div class="stat-icon"></div>
            <div class="stat-value">${stats.par_role?.admin || 0}</div>
            <div class="stat-label">ADMINS</div>
        </div>
        <div class="stat-card">
            <div class="stat-icon"></div>
            <div class="stat-value">${stats.par_role?.employe || 0}</div>
            <div class="stat-label">EMPLOYÉS</div>
        </div>
    `;
}

function renderCameraGrid(cameras) {
    const grid = document.getElementById('cameraGrid');
    if (!grid) return;

    grid.innerHTML = '';

    cameras.forEach(cam => {
        const feed = document.createElement('div');
        feed.className = `camera-feed ${cam.est_active ? '' : 'offline'}`;
        feed.innerHTML = `
            <img src="/assets/camera-placeholder.jpg" alt="${cam.nom_camera}">
            <div class="feed-overlay">
                <div class="feed-header">
                    <div class="feed-tag">${cam.nom_camera}</div>
                    <div class="feed-status ${cam.est_active ? 'live' : 'offline'}">
                        ${cam.est_active ? 'LIVE' : 'OFFLINE'}
                    </div>
                </div>
                <div class="feed-stats">
                    <div class="feed-stat">${cam.emplacement || 'N/A'}</div>
                </div>
            </div>
        `;
        grid.appendChild(feed);
    });
}

function updateThreats(alertes) {
    const threatsList = document.getElementById('threatsList');
    if (!threatsList) return;

    if (!alertes || alertes.length === 0) {
        threatsList.innerHTML = '<div class="text-dim">Aucune menace active</div>';
        return;
    }

    threatsList.innerHTML = alertes.slice(0, 5).map(a => `
        <div class="threat-item" style="margin-bottom: 10px; padding: 10px; background: rgba(255,0,60,0.1); border-left: 3px solid var(--alert);">
            <div style="display: flex; justify-content: space-between;">
                <span style="color: var(--alert); font-weight: 600;">${a.type_alerte}</span>
                <span style="color: var(--text-dim); font-size: 0.7rem;">${new Date(a.date_generation).toLocaleTimeString()}</span>
            </div>
            <div style="font-size: 0.8rem;">${a.message}</div>
        </div>
    `).join('');
}

function updateDeplacements(deplacements) {
    const tbody = document.getElementById('deplacementsTableBody');
    if (!tbody) return;

    if (!deplacements || deplacements.length === 0) {
        tbody.innerHTML = '<tr><td colspan="5" class="text-center">Aucun déplacement en cours</td></tr>';
        return;
    }

    tbody.innerHTML = deplacements.slice(0, 5).map(d => `
        <tr>
            <td>${d.employe_nom || 'N/A'}</td>
            <td>${new Date(d.date_depart).toLocaleTimeString()}</td>
            <td>${d.date_retour_prevue ? new Date(d.date_retour_prevue).toLocaleTimeString() : 'N/A'}</td>
            <td>Zone ${d.id_zone_destination}</td>
            <td>
                <span class="status-badge ${d.statut === 'en_retard' ? 'critical' : 'warning'}">
                    ${d.statut}
                </span>
            </td>
        </tr>
    `).join('');
}