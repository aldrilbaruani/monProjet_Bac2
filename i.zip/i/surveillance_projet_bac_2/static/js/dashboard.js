
export function updateStats(elements, data) {
    Object.entries(elements).forEach(([id, value]) => {
        const el = document.getElementById(id);
        if (el) el.textContent = value;
    });
}

export function showNotification(message, type = 'info') {
    console.log(`[${type}] ${message}`);

}