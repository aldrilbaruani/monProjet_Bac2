import { stats, deplacements, alertes, cameras } from './api.js';
import { createLineChart } from './charts.js';
import { updateStats, showNotification } from './dashboard.js';

export async function loadAdminData() {
    try {

        const statsData = await stats.getDashboard();
        if (statsData.success) {
            updateAdminStats(statsData.data);
        }


        const deplacementsData = await deplacements.getEnCours();
        if (deplacementsData.success) {
            renderDeplacementsTable(deplacementsData.data);
        }


        const alertesData = await alertes.getNonTraitees();
        if (alertesData.success) {
            renderAlertesList(alertesData.data);
        }

        await loadSystemStats();

    } catch (error) {
        console.error('Erreur chargement dashboard admin:', error);
        showNotification('Erreur de chargement', 'error');
    }
}

function updateAdminStats(stats) {
    document.getElementById('totalEmployes').textContent = stats.employes?.actifs || 24;
    document.getElementById('enDeplacement').textContent = stats.deplacements?.en_cours || 6;
    document.getElementById('alertesNonTraitees').textContent = stats.alertes?.non_traitees || 5;
    document.getElementById('enRetard').textContent = stats.deplacements?.en_retard || 2;
}

async function loadSystemStats() {
    try {
        const camerasData = await cameras.getAll(true);
        document.getElementById('camerasActives').textContent = `${camerasData.data?.length || 12}/12`;
        document.getElementById('employesPresent').textContent = '18/24';

        const deplacementsData = await deplacements.getEnCours();
        renderProchainsRetours(deplacementsData.data);

    } catch (error) {
        console.error('Erreur chargement stats système:', error);
    }
}

function renderDeplacementsTable(deplacements) {
    const tbody = document.getElementById('deplacementsTableBody');
    if (!tbody) return;

    if (!deplacements || deplacements.length === 0) {
        tbody.innerHTML = '<tr><td colspan="6" class="text-center">Aucun déplacement en cours</td></tr>';
        return;
    }

    tbody.innerHTML = deplacements.slice(0, 5).map(d => `
        <tr>
            <td>${d.employe_nom || 'N/A'}</td>
            <td>${new Date(d.date_depart).toLocaleTimeString()}</td>
            <td>${d.date_retour_prevue ? new Date(d.date_retour_prevue).toLocaleTimeString() : 'N/A'}</td>
            <td>Zone ${d.id_zone_destination}</td>
            <td>
                <span class="status-badge ${d.statut === 'en_retard' ? 'critical' : 'warning'}">
                    ${d.statut}
                </span>
            </td>
            <td>
                <button class="cyber-button small" onclick="window.location.href='deplacements.html'">
                    <span class="material-symbols-outlined">visibility</span>
                </button>
            </td>
        </tr>
    `).join('');
}

function renderAlertesList(alertes) {
    const container = document.getElementById('recentAlertes');
    if (!container) return;

    if (!alertes || alertes.length === 0) {
        container.innerHTML = '<div class="text-dim">Aucune alerte récente</div>';
        return;
    }

    container.innerHTML = alertes.slice(0, 3).map(a => `
        <div class="alerte-item" style="margin-bottom: 10px; padding: 10px; background: rgba(255,0,60,0.1); border-left: 3px solid var(--alert);">
            <div style="display: flex; justify-content: space-between;">
                <span style="color: var(--alert); font-weight: 600;">${a.type_alerte}</span>
                <span style="color: var(--text-dim); font-size: 0.7rem;">${new Date(a.date_generation).toLocaleTimeString()}</span>
            </div>
            <div style="font-size: 0.8rem;">${a.message}</div>
        </div>
    `).join('');
}

function renderProchainsRetours(deplacements) {
    const container = document.getElementById('prochainsRetours');
    if (!container) return;

    if (!deplacements || deplacements.length === 0) {
        container.innerHTML = '<div class="text-dim">Aucun retour prévu</div>';
        return;
    }

    container.innerHTML = deplacements.slice(0, 3).map(d => `
        <div style="margin-bottom: 10px; padding: 8px; background: rgba(0,240,255,0.1); border-radius: 4px;">
            <div style="display: flex; justify-content: space-between;">
                <span>${d.employe_nom || 'N/A'}</span>
                <span class="text-primary">${d.date_retour_prevue ? new Date(d.date_retour_prevue).toLocaleTimeString() : 'N/A'}</span>
            </div>
            <div style="font-size: 0.7rem; color: var(--text-dim);">Zone ${d.id_zone_destination}</div>
        </div>
    `).join('');
}


export function initAdminChart() {
    const ctx = document.getElementById('activiteChart')?.getContext('2d');
    if (ctx) {
        createLineChart(ctx,
            ['Lun', 'Mar', 'Mer', 'Jeu', 'Ven', 'Sam', 'Dim'],
            [5, 7, 4, 8, 6, 3, 9],
            'Déplacements'
        );
    }
}