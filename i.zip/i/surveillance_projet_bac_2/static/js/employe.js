import { deplacements, alertes } from './api.js';
import { showNotification } from './dashboard.js';

export async function loadEmployeData(employeId) {
    try {

        const deplacementsData = await deplacements.getByEmploye(employeId);
        if (deplacementsData.success) {
            updateEmployeDeplacements(deplacementsData.data);
        }


        const alertesData = await alertes.getByEmploye(employeId);
        if (alertesData.success) {
            updateEmployeAlertes(alertesData.data);
        }


        await checkCurrentStatus(employeId);

    } catch (error) {
        console.error('Erreur chargement données employé:', error);
        showNotification('Erreur de chargement', 'error');
    }
}

function updateEmployeDeplacements(deplacements) {

    const enCours = deplacements.find(d => d.statut === 'en_cours');

    const container = document.querySelector('.deplacement-en-cours');
    if (container && enCours) {
        container.innerHTML = `
            <div class="cyber-card">
                <div class="card-header">
                    <h3>DÉPLACEMENT EN COURS</h3>
                    <span class="badge status-warning">ACTIF</span>
                </div>
                <div style="padding: 15px;">
                    <div style="display: flex; justify-content: space-between; margin-bottom: 15px;">
                        <span style="color: var(--text-dim);">Destination:</span>
                        <span style="color: var(--primary); font-weight: 600;">Zone ${enCours.id_zone_destination}</span>
                    </div>
                    <div style="display: flex; justify-content: space-between; margin-bottom: 15px;">
                        <span style="color: var(--text-dim);">Départ:</span>
                        <span>${new Date(enCours.date_depart).toLocaleTimeString()}</span>
                    </div>
                    <div style="display: flex; justify-content: space-between; margin-bottom: 15px;">
                        <span style="color: var(--text-dim);">Retour prévu:</span>
                        <span>${enCours.date_retour_prevue ? new Date(enCours.date_retour_prevue).toLocaleTimeString() : 'N/A'}</span>
                    </div>
                    <div style="display: flex; justify-content: space-between; margin-bottom: 15px;">
                        <span style="color: var(--text-dim);">Motif:</span>
                        <span>${enCours.motif}</span>
                    </div>
                    <button class="cyber-button w-full" onclick="terminerDeplacement(${enCours.id_deplacement})">
                        SIGNALER LE RETOUR
                    </button>
                </div>
            </div>
        `;
    }
}

function updateEmployeAlertes(alertes) {
    const container = document.querySelector('.alertes-list');
    if (!container) return;

    const nonLues = alertes.filter(a => a.statut === 'envoyee');

    if (nonLues.length === 0) {
        container.innerHTML = '<div class="text-dim">Aucune alerte non lue</div>';
        return;
    }

    container.innerHTML = nonLues.map(a => `
        <div class="cyber-card" style="margin-bottom: 15px; border-left: 4px solid ${a.niveau_urgence >= 4 ? 'var(--alert)' : 'var(--warning)'};">
            <div style="display: flex; justify-content: space-between; align-items: start; padding: 15px;">
                <div style="display: flex; gap: 15px;">
                    <span class="material-symbols-outlined" style="color: ${a.niveau_urgence >= 4 ? 'var(--alert)' : 'var(--warning)'};">
                        ${a.niveau_urgence >= 4 ? 'warning' : 'info'}
                    </span>
                    <div>
                        <div style="font-weight: 600; margin-bottom: 5px;">${a.type_alerte.toUpperCase()}</div>
                        <p style="color: var(--text-secondary); margin-bottom: 10px;">${a.message}</p>
                        <div style="display: flex; gap: 15px; color: var(--text-dim); font-size: 0.8rem;">
                            <span>${new Date(a.date_generation).toLocaleString()}</span>
                            <span>•</span>
                            <span>Niveau ${a.niveau_urgence}</span>
                        </div>
                    </div>
                </div>
                <button class="cyber-button small" onclick="marquerAlerteLue(${a.id_alerte})">
                    <span class="material-symbols-outlined">mark_email_read</span>
                </button>
            </div>
        </div>
    `).join('');
}

async function checkCurrentStatus(employeId) {
    try {
        const deplacementsData = await deplacements.getByEmploye(employeId);
        const enCours = deplacementsData.data?.find(d => d.statut === 'en_cours');

        const statusBadge = document.querySelector('.status-badge');
        if (statusBadge) {
            if (enCours) {
                statusBadge.className = 'status-badge warning';
                statusBadge.textContent = 'EN DÉPLACEMENT';
            } else {
                statusBadge.className = 'status-badge success';
                statusBadge.textContent = 'PRÉSENT';
            }
        }
    } catch (error) {
        console.error('Erreur vérification statut:', error);
    }
}

window.terminerDeplacement = async (id) => {
    if (confirm('Confirmer votre retour ?')) {
        try {
            await deplacements.terminer(id);
            alert('Retour enregistré !');
            window.location.reload();
        } catch (error) {
            alert('Erreur: ' + error.message);
        }
    }
};

window.marquerAlerteLue = async (id) => {
    try {
        await alertes.traiter(id, 'Lu par employé');
        window.location.reload();
    } catch (error) {
        alert('Erreur: ' + error.message);
    }
};