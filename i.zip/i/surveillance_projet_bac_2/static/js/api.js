// static/js/api.js

const API_BASE_URL = 'http://localhost:5001/api'; // ← Notez le port 5001, pas 5000

// ===== GESTION DU TOKEN =====
function getToken() {
    return localStorage.getItem('token');
}

function setToken(token) {
    localStorage.setItem('token', token);
}

function removeToken() {
    localStorage.removeItem('token');
    localStorage.removeItem('user');
}

function getAuthHeaders() {
    const token = getToken();
    return {
        'Content-Type': 'application/json',
        'Authorization': token ? `Bearer ${token}` : ''
    };
}

// ===== GESTION DES ERREURS =====
async function handleResponse(response) {
    if (!response.ok) {
        if (response.status === 401) {
            removeToken();
            window.location.href = '/';
            throw new Error('Session expirée');
        }
        const error = await response.json().catch(() => ({}));
        throw new Error(error.message || `Erreur ${response.status}`);
    }
    return response.json();
}

// ===== REQUÊTE GÉNÉRIQUE =====
async function apiCall(endpoint, method = 'GET', data = null) {
    const url = `${API_BASE_URL}${endpoint}`;
    console.log(`🌐 ${method} ${url}`, data);

    const options = {
        method,
        headers: getAuthHeaders()
    };

    if (data) {
        options.body = JSON.stringify(data);
    }

    try {
        const response = await fetch(url, options);
        return await handleResponse(response);
    } catch (error) {
        console.error(`❌ API Error:`, error);
        throw error;
    }
}

// ===== AUTH =====
export const auth = {
    async login(email, password) {
        const response = await apiCall('/auth/login', 'POST', { email, password });
        if (response.success && response.data?.token) {
            setToken(response.data.token);
            localStorage.setItem('user', JSON.stringify(response.data.employe));
        }
        return response;
    },

    async register(userData) {
        console.log('📝 Tentative d\'inscription:', userData.email);
        const response = await apiCall('/auth/register', 'POST', userData);
        if (response.success) {
            console.log('✅ Inscription réussie');
        }
        return response;
    },

    async getCurrentUser() {
        return apiCall('/auth/me');
    },

    logout() {
        removeToken();
        window.location.href = '/';
    },

    isAuthenticated() {
        return !!getToken();
    },

    getUser() {
        const userStr = localStorage.getItem('user');
        return userStr ? JSON.parse(userStr) : null;
    }
};

// ===== EMPLOYES =====
export const employes = {
    getAll(actifsOnly = true) {
        return apiCall(`/employes/?actifs_only=${actifsOnly}`);
    },
    getById(id) {
        return apiCall(`/employes/${id}`);
    },
    create(data) {
        return apiCall('/employes/', 'POST', data);
    },
    update(id, data) {
        return apiCall(`/employes/${id}`, 'PUT', data);
    },
    delete(id, softDelete = true) {
        return apiCall(`/employes/${id}?soft_delete=${softDelete}`, 'DELETE');
    },
    getStats() {
        return apiCall('/employes/stats');
    }
};

// ===== ZONES =====
export const zones = {
    getAll() {
        return apiCall('/zones/');
    },
    getById(id) {
        return apiCall(`/zones/${id}`);
    },
    create(data) {
        return apiCall('/zones/', 'POST', data);
    },
    update(id, data) {
        return apiCall(`/zones/${id}`, 'PUT', data);
    },
    delete(id) {
        return apiCall(`/zones/${id}`, 'DELETE');
    }
};

// ===== CAMERAS =====
export const cameras = {
    getAll(activesOnly = false) {
        return apiCall(`/cameras/?actives_only=${activesOnly}`);
    },
    getById(id) {
        return apiCall(`/cameras/${id}`);
    },
    getByZone(idZone) {
        return apiCall(`/cameras/zone/${idZone}`);
    },
    create(data) {
        return apiCall('/cameras/', 'POST', data);
    },
    update(id, data) {
        return apiCall(`/cameras/${id}`, 'PUT', data);
    },
    delete(id) {
        return apiCall(`/cameras/${id}`, 'DELETE');
    },
    activer(id) {
        return apiCall(`/cameras/${id}/activer`, 'POST');
    },
    desactiver(id) {
        return apiCall(`/cameras/${id}/desactiver`, 'POST');
    },
    getStats() {
        return apiCall('/cameras/stats');
    }
};

// ===== DEPLACEMENTS =====
export const deplacements = {
    getById(id) {
        return apiCall(`/deplacements/${id}`);
    },
    getByEmploye(idEmploye) {
        return apiCall(`/deplacements/employe/${idEmploye}`);
    },
    getEnCours() {
        return apiCall('/deplacements/en-cours');
    },
    create(data) {
        return apiCall('/deplacements/', 'POST', data);
    },
    terminer(id) {
        return apiCall(`/deplacements/${id}/terminer`, 'POST');
    },
    annuler(id, motif) {
        return apiCall(`/deplacements/${id}/annuler`, 'POST', { motif });
    },
    verifierRetards() {
        return apiCall('/deplacements/verifier-retards', 'POST');
    },
    getStats() {
        return apiCall('/deplacements/stats');
    },
    getDuJour() {
        return apiCall('/deplacements/du-jour');
    }
};

// ===== ALERTES =====
export const alertes = {
    getNonTraitees() {
        return apiCall('/alertes/non-traitees');
    },
    getCritiques() {
        return apiCall('/alertes/critiques');
    },
    getByEmploye(idEmploye) {
        return apiCall(`/alertes/employe/${idEmploye}`);
    },
    traiter(id, commentaire) {
        return apiCall(`/alertes/${id}/traiter`, 'POST', { commentaire });
    },
    ignorer(id, raison) {
        return apiCall(`/alertes/${id}/ignorer`, 'POST', { raison });
    },
    getStats() {
        return apiCall('/alertes/stats');
    }
};

// ===== STATISTIQUES =====
export const stats = {
    getDashboard() {
        return apiCall('/stats/dashboard');
    },
    getSuperAdmin() {
        return apiCall('/stats/superadmin');
    },
    getTempsReel() {
        return apiCall('/stats/temps-reel');
    }
};

// Export par défaut
export default {
    auth,
    employes,
    zones,
    cameras,
    deplacements,
    alertes,
    stats
};