
import { auth as authApi } from './api.js';

const roleRedirects = {
    'super_admin': '/superadmin/dashboard.html',
    'admin': '/admin/dashboard.html',
    'employe': '/employe/dashboard.html'
};


export function getCurrentUser() {
    const userStr = localStorage.getItem('user');
    return userStr ? JSON.parse(userStr) : null;
}

export async function checkAuth() {
    const token = localStorage.getItem('token');
    const user = getCurrentUser();

    console.log('🔍 Vérification auth:', {
        token: !!token,
        user: user ? `${user.prenom} ${user.nom}` : null
    });

    if (!token) {
        console.log(' Pas de token');
        window.location.href = '/';
        return null;
    }

    try {
        const response = await authApi.getCurrentUser();

        if (response.success && response.data) {

            localStorage.setItem('user', JSON.stringify(response.data));
            console.log(' Token valide pour:', response.data.role);
            return response.data;
        } else {
            console.log(' Token invalide');
            authApi.logout();
            return null;
        }
    } catch (error) {
        console.error(' Erreur vérification:', error);
        authApi.logout();
        return null;
    }
}


export async function initAuth() {
    const user = await checkAuth();

    if (user) {
        updateUserUI(user);
        checkPageAccess(user.role);
        return user;
    }
    return null;
}


function updateUserUI(user) {
    // Nom complet
    document.querySelectorAll('.user-name').forEach(el => {
        el.textContent = `${user.prenom} ${user.nom}`;
    });

    document.querySelectorAll('.user-role').forEach(el => {
        const roleMap = {
            'super_admin': 'SUPER ADMIN',
            'admin': 'ADMINISTRATEUR',
            'employe': 'EMPLOYÉ'
        };
        el.textContent = roleMap[user.role] || user.role;
    });


    document.querySelectorAll('.user-email').forEach(el => {
        el.textContent = user.email;
    });
}


function checkPageAccess(userRole) {
    const currentPath = window.location.pathname;

    if (currentPath.includes('/superadmin/') && userRole !== 'super_admin') {
        console.log(' Accès superadmin non autorisé');
        window.location.href = '/';
    } else if (currentPath.includes('/admin/') && !['super_admin', 'admin'].includes(userRole)) {
        console.log(' Accès admin non autorisé');
        window.location.href = '/';
    } else if (currentPath.includes('/employe/') && userRole !== 'employe') {
        console.log(' Accès employé non autorisé');
        window.location.href = '/';
    }
}


export function logout() {
    console.log(' Déconnexion');
    authApi.logout();
}

document.addEventListener('DOMContentLoaded', () => {
    const logoutBtn = document.getElementById('logout-btn');
    if (logoutBtn) {
        logoutBtn.addEventListener('click', (e) => {
            e.preventDefault();
            logout();
        });
    }

    startClock();
});

function startClock() {
    function update() {
        const now = new Date();
        document.querySelectorAll('#currentTime, .time').forEach(el => {
            if (el.id === 'currentTime' || el.classList.contains('time')) {
                el.textContent = now.toLocaleTimeString('fr-FR', { hour12: false });
            }
        });
        document.querySelectorAll('#currentDate, .date').forEach(el => {
            if (el.id === 'currentDate' || el.classList.contains('date')) {
                el.textContent = now.toLocaleDateString('fr-FR').replace(/\//g, '.');
            }
        });
    }
    update();
    setInterval(update, 1000);
}