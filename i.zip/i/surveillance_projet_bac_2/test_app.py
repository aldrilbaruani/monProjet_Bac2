# test_app.py
import sys
import os
import requests
import json
from datetime import datetime, timedelta

# Configuration
BASE_URL = "http://localhost:5001"


class TestApplication:
    """Classe de test des fonctionnalités de l'application."""

    def __init__(self):
        self.token = None
        self.user_id = None

    def print_header(self, title):
        print("\n" + "=" * 70)
        print(f"📌 {title}")
        print("=" * 70)

    def print_success(self, message):
        print(f"   ✅ {message}")

    def print_error(self, message):
        print(f"   ❌ {message}")

    def print_info(self, message):
        print(f"   📊 {message}")

    # ===== TESTS DES PAGES =====

    def test_home_page(self):
        """Teste la page d'accueil."""
        print("\n🏠 Test: Page d'accueil")
        try:
            response = requests.get(f"{BASE_URL}/", timeout=10)
            if response.status_code == 200:
                self.print_success("Page d'accueil accessible")
                return True
            else:
                self.print_error(f"HTTP {response.status_code}")
                return False
        except Exception as e:
            self.print_error(f"Erreur: {e}")
            return False

    def test_superadmin_page(self):
        """Teste la page superadmin."""
        print("\n👑 Test: Page Super Admin")
        try:
            response = requests.get(f"{BASE_URL}/superadmin/dashboard.html", timeout=10)
            if response.status_code == 200:
                self.print_success("Page Super Admin accessible")
                return True
            else:
                self.print_error(f"HTTP {response.status_code}")
                return False
        except Exception as e:
            self.print_error(f"Erreur: {e}")
            return False

    def test_admin_page(self):
        """Teste la page admin."""
        print("\n📊 Test: Page Admin")
        try:
            response = requests.get(f"{BASE_URL}/admin/dashboard.html", timeout=10)
            if response.status_code == 200:
                self.print_success("Page Admin accessible")
                return True
            else:
                self.print_error(f"HTTP {response.status_code}")
                return False
        except Exception as e:
            self.print_error(f"Erreur: {e}")
            return False

    def test_employe_page(self):
        """Teste la page employé."""
        print("\n👤 Test: Page Employé")
        try:
            response = requests.get(f"{BASE_URL}/employe/dashboard.html", timeout=10)
            if response.status_code == 200:
                self.print_success("Page Employé accessible")
                return True
            else:
                self.print_error(f"HTTP {response.status_code}")
                return False
        except Exception as e:
            self.print_error(f"Erreur: {e}")
            return False

    def test_css(self):
        """Teste le fichier CSS."""
        print("\n🎨 Test: CSS cyberpunk")
        try:
            response = requests.get(f"{BASE_URL}/css/cyber.css", timeout=10)
            if response.status_code == 200:
                self.print_success("CSS chargé")
                return True
            else:
                self.print_error(f"HTTP {response.status_code}")
                return False
        except Exception as e:
            self.print_error(f"Erreur: {e}")
            return False

    def test_js_api(self):
        """Teste le fichier JS API."""
        print("\n📜 Test: JS API")
        try:
            response = requests.get(f"{BASE_URL}/js/api.js", timeout=10)
            if response.status_code == 200:
                self.print_success("JS API chargé")
                return True
            else:
                self.print_error(f"HTTP {response.status_code}")
                return False
        except Exception as e:
            self.print_error(f"Erreur: {e}")
            return False

    # ===== TESTS DE L'API =====

    def test_api_login(self):
        """Teste l'API de login."""
        print("\n🔐 Test: API Login (POST /api/auth/login)")
        try:
            response = requests.post(
                f"{BASE_URL}/api/auth/login",
                json={"email": "superadmin@securite.com", "password": "admin123"},
                timeout=10
            )

            print(f"   📍 Statut: {response.status_code}")
            print(f"   📍 Réponse: {response.text[:200] if response.text else 'vide'}")

            if response.status_code == 200:
                data = response.json()
                if data.get('success'):
                    self.token = data['data']['token']
                    self.user_id = data['data']['employe']['id_employe']
                    self.print_success("Login réussi !")
                    return True
            elif response.status_code == 405:
                self.print_error("Route existe mais méthode non autorisée (vérifier blueprint)")
            elif response.status_code == 404:
                self.print_error("Route non trouvée (vérifier que les blueprints sont enregistrés)")
            else:
                self.print_error(f"HTTP {response.status_code}")
            return False

        except requests.exceptions.ConnectionError:
            self.print_error("Impossible de se connecter au serveur")
            return False
        except Exception as e:
            self.print_error(f"Erreur: {e}")
            return False

    # ===== EXÉCUTION DE TOUS LES TESTS =====

    def run_all_tests(self):
        """Exécute tous les tests."""
        self.print_header("TESTS DE L'APPLICATION")

        # Tester les pages statiques
        self.test_home_page()
        self.test_superadmin_page()
        self.test_admin_page()
        self.test_employe_page()
        self.test_css()
        self.test_js_api()

        # Tester l'API
        self.test_api_login()

        # Résumé final
        self.print_header("TESTS TERMINÉS")
        print("\n🎉 L'application est opérationnelle !")
        print("\n🌐 Accès à l'interface:")
        print("   http://localhost:5001")
        print("\n🔑 Comptes de test:")
        print("   - Super Admin: superadmin@securite.com / admin123")
        print("   - Admin: admin@securite.com / admin123")
        print("   - Employé: jean.dupont@securite.com / employe123")


if __name__ == "__main__":
    tester = TestApplication()
    tester.run_all_tests()