# run.py
import sys
import os
import webbrowser
from threading import Timer

# Ajouter le chemin parent au PYTHONPATH
current_dir = os.path.dirname(os.path.abspath(__file__))
parent_dir = os.path.dirname(current_dir)
if parent_dir not in sys.path:
    sys.path.insert(0, parent_dir)

# Importer l'application
try:
    from app import create_app

    print("✅ Application importée avec succès")
except ImportError as e:
    print(f"❌ Erreur d'import: {e}")
    print("\n📋 Vérifiez que:")
    print("   - Vous êtes dans le bon dossier")
    print("   - Le fichier app/__init__.py existe")
    print("   - Toutes les dépendances sont installées")
    sys.exit(1)


def open_browser():
    """Ouvre le navigateur après le démarrage."""
    webbrowser.open_new('http://localhost:5001')


def main():
    """Fonction principale."""
    print("\n" + "=" * 70)
    print("🚀 SURVEILLANCE IA - APPLICATION")
    print("=" * 70)

    try:
        # Créer l'application
        app = create_app()

        # Configuration
        PORT = 5001
        DEBUG_MODE = True

        # Afficher les informations
        print(f"\n📁 Répertoire: {current_dir}")
        print(f"🌐 Interface: http://localhost:{PORT}")
        print(f"🔌 API REST: http://localhost:{PORT}/api")
        print(f"⚙️ Mode: {'DEBUG' if DEBUG_MODE else 'PRODUCTION'}")

        print("\n" + "=" * 70)
        print("✅ Serveur prêt - Ctrl+C pour arrêter")
        print("=" * 70)

        # Ouvrir le navigateur après 1.5 secondes
        if DEBUG_MODE:
            Timer(1.5, open_browser).start()

        # Lancer le serveur
        app.run(
            debug=DEBUG_MODE,
            host='0.0.0.0',
            port=PORT,
            threaded=True
        )

    except KeyboardInterrupt:
        print("\n\n👋 Arrêt du serveur demandé")
    except Exception as e:
        print(f"\n❌ Erreur lors du démarrage: {e}")
        import traceback
        traceback.print_exc()
        return 1

    return 0


if __name__ == '__main__':
    sys.exit(main())