# app/__init__.py

from flask import Flask, send_from_directory
import os
from surveillance_projet_bac_2.app.utils.config import DevelopmentConfig


def create_app(config_class=DevelopmentConfig):
    # Déterminer le chemin absolu du dossier static
    static_folder = os.path.abspath(os.path.join(os.path.dirname(__file__), '../static'))

    app = Flask(__name__,
                static_folder=static_folder,
                static_url_path='')

    # Charger la configuration
    app.config.from_object(config_class)

    # Configuration JWT
    app.config['JWT_SECRET_KEY'] = app.config['SECRET_KEY']

    print(f"✅ Dossier static configuré: {static_folder}")
    print(f"✅ Mode DEBUG: {app.config['DEBUG']}")

    # Route pour la racine
    @app.route('/')
    def index():
        return send_from_directory(static_folder, 'index.html')

    # Route pour servir tous les fichiers statiques
    @app.route('/<path:path>')
    def serve_static(path):
        return send_from_directory(static_folder, path)

    # Enregistrer les blueprints
    from app.controllers import register_blueprints
    register_blueprints(app)

    return app