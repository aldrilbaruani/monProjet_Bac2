# config.py

import os
from dotenv import load_dotenv

load_dotenv()


class Config:
    """Configuration de base."""

    # Clé secrète pour JWT
    SECRET_KEY = os.environ.get('SECRET_KEY', 'dev-key-change-in-production')

    # Configuration JWT
    JWT_ALGORITHM = 'HS256'
    JWT_EXPIRATION_HOURS = 24

    # Base de données
    DB_HOST = os.environ.get('DB_HOST', 'localhost')
    DB_USER = os.environ.get('DB_USER', 'root')
    DB_PASSWORD = os.environ.get('DB_PASSWORD', '')
    DB_NAME = os.environ.get('DB_NAME', 'surveillance_ia_projet')

    # Environnement
    DEBUG = os.environ.get('DEBUG', 'True').lower() == 'true'
    TESTING = False


class DevelopmentConfig(Config):
    """Configuration de développement."""
    DEBUG = True


class ProductionConfig(Config):
    """Configuration de production."""
    DEBUG = False
    SECRET_KEY = os.environ.get('SECRET_KEY')  # Doit être défini en prod


class TestingConfig(Config):
    """Configuration de test."""
    TESTING = True
    DEBUG = True
    DB_NAME = 'surveillance_ia_projet_test'