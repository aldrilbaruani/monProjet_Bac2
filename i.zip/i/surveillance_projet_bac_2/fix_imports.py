# fix_imports.py
import os
import re

controllers_dir = "app/controllers"

# Liste des fichiers à corriger
for filename in os.listdir(controllers_dir):
    if filename.endswith('.py') and filename != '__init__.py':
        filepath = os.path.join(controllers_dir, filename)

        with open(filepath, 'r', encoding='utf-8') as f:
            content = f.read()

        # Remplacer les imports
        # from services.xxx → from app.services.xxx
        # from models.xxx → from app.models.xxx
        # from dao.xxx → from app.dao.xxx
        # from utils.xxx → from app.utils.xxx

        content = re.sub(r'from services\.', 'from app.services.', content)
        content = re.sub(r'from models\.', 'from app.models.', content)
        content = re.sub(r'from dao\.', 'from app.dao.', content)
        content = re.sub(r'from utils\.', 'from app.utils.', content)
        content = re.sub(r'import services\.', 'import app.services.', content)
        content = re.sub(r'import models\.', 'import app.models.', content)
        content = re.sub(r'import dao\.', 'import app.dao.', content)
        content = re.sub(r'import utils\.', 'import app.utils.', content)

        with open(filepath, 'w', encoding='utf-8') as f:
            f.write(content)

        print(f"✅ Corrigé: {filename}")

print("\n✅ Tous les imports ont été corrigés !")