# rename_dao_files.py

import os
import re


def rename_dao_files():
    """Renomme les fichiers DAO au format snake_case."""
    dao_dir = os.path.join('app', 'dao')

    if not os.path.exists(dao_dir):
        print(f"❌ Dossier {dao_dir} introuvable")
        return

    # Mapping des anciens noms vers nouveaux noms
    rename_map = {
        'AlerteDao.py': 'alerte_dao.py',
        'CameraDao.py': 'camera_dao.py',
        'ChatbotInteractionDao.py': 'chatbot_interaction_dao.py',
        'DeplacementDao.py': 'deplacement_dao.py',
        'EmployeDao.py': 'employe_dao.py',
        'EvenementDao.py': 'evenement_dao.py',
        'NotificationDao.py': 'notification_dao.py',
        'ReconnaissanceDao.py': 'reconnaissance_dao.py',
        'SessionPresenceDao.py': 'session_presence_dao.py',
        'UniformeDao.py': 'uniforme_dao.py',
        'VisageDao.py': 'visage_dao.py',
        'ZoneDao.py': 'zone_dao.py'
    }

    print("🔍 Renommage des fichiers DAO...")

    for old_name, new_name in rename_map.items():
        old_path = os.path.join(dao_dir, old_name)
        new_path = os.path.join(dao_dir, new_name)

        if os.path.exists(old_path):
            os.rename(old_path, new_path)
            print(f"✅ {old_name} → {new_name}")
        else:
            print(f"⚠️ {old_name} non trouvé")

    print("\n✨ Renommage terminé !")


if __name__ == '__main__':
    rename_dao_files()